# 反馈复核附件

先读 `LLM_Pilot_Audit_ZH.md`。原始实验未改写；本包不是新的实验数据，也不是论文最终结果。

## 附件

- `audit_results/audit_metrics.json`：清单、源代码、请求账本、逐请求重建和独立评分检查。
- `audit_results/recheck_recomputed.csv`：128条重新评分的记录；包含真实语义新鲜性，而非仅字段类型。
- `audit_results/repair_readiness_recomputed.csv`：12条修订记录、调用数、费用和延迟。
- `audit_results/call_audit.csv`：295次完整调用的元数据、usage和配置价格；不含API密钥或模型思考文本。
- `audit_results/tariff_recalculation.csv`：按运行日空闲时段重新估计的USD及CNY费用；不是实际发票。
- `audit_results/error_examples.json`：两个失败案例的最小证据与实际真值。
- `audit_results/policy_sensitivity.json`：对称价格仍可出现策略差异的离线反例；不是新增LLM结果。
- `audit_results/original_tests.log`：原始工具包42项测试的本地复核。
- `reproduce_audit.py` / `audit_feedback.py`：重新读取原始ZIP并离线重算的脚本，不调用任何模型。

## 独立复算

需要Python与numpy。使用原实验的虚拟环境即可。保留收到的反馈ZIP与最初LLM工具ZIP：

```bash
python reproduce_audit.py --feedback 8a80ceb7-3588-4ffe-a4b2-4d6c9943b2d5.zip --kit LLM_Pilot_Kit_v0.1.zip --out audit_rerun
```

必须使用新目录。脚本会验证运行快照与原工具源代码相同后，用已记录模型输出重建公开请求与本地执行；结果写入新目录，不接入API。这个脚本仅针对当前v0.1数据结构，不是通用安全审计工具。

当前脚本复算核心账本、请求和结果。价格重估与策略参数扫描的冻结结果另存于CSV/JSON；其公式及参数在报告中披露，不将官网未来价格自动应用到历史记录。

## 解释边界

程序检查通过不能代替论文科学审核。尤其是同策略相同输入、仅4条流、一个过期记忆错误、readiness不是主算法以及中断批次缺失，均需保留。
