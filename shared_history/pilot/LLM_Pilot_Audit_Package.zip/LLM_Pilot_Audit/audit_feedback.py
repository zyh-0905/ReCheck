"""Read-only audit of the original three exports, with offline request/SQL replay.
No supplied reviewer is executed. No model requests are made.
"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib,json,csv,sys,math,copy,shutil,os
import numpy as np
BASE=Path(os.environ.get('PILOT_AUDIT_BASE',Path(__file__).resolve().parent)).resolve()
ORIGINAL=BASE/'original/LLM_Pilot_Kit'
OUT=BASE/'audit_results';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ORIGINAL))
from pilot.common import digest,canonical,strict_json_object,request_payload
from pilot import recheck,readiness
from vendor.recheck_core import solve_refresh_dp,mismatch_probability

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def num(v):return type(v) in (int,float) and math.isfinite(v)
def artifact_gold(rule,sources):
 n=rule['base']+rule['multiplier']*sources[rule['source']]
 return {'metric':n,'flag':'high' if n>=rule['threshold'] else 'low'}
def artifact_ok(x,g):return isinstance(x,dict) and set(x)=={'metric','flag'} and num(x['metric']) and abs(x['metric']-g['metric'])<=1e-8 and x['flag']==g['flag']
def rc_score(row,case):
 a=row.get('answer');p=row.get('plan');t=case['tasks'][row['step']];q=t['type']
 plan_ok=isinstance(p,dict) and set(p)=={'amount_divisor','time_bound'}
 if plan_ok:
  plan_ok= (num(p['amount_divisor']) and p['amount_divisor'] in (1,100)) if q in (0,2) else p['amount_divisor'] is None
 if plan_ok:
  plan_ok=(type(p['time_bound']) is int and t['cutoff']-1<=p['time_bound']<=t['cutoff']+2) if q in (1,2) else p['time_bound'] is None
 aok=isinstance(a,dict) and set(a)=={'total','count'}
 if aok:
  aok=(num(a['total']) and abs(a['total']-sum(case['cents'])/100)<=1e-6) if q in (0,2) else a['total'] is None
 if aok:
  ct=len(case['cents']) if q==3 else sum(i<=t['cutoff'] for i in range(len(case['cents'])))
  aok=(num(a['count']) and a['count']==ct) if q in (1,2,3) else a['count'] is None
 return bool(plan_ok and aok),bool(plan_ok)

class ReplayClient:
 def __init__(self,calls,cfg):self.calls=calls;self.cfg=cfg;self.used=[];self.mismatches=[]
 def complete(self,lid,messages,meta=None):
  r=self.calls[lid];p=request_payload(self.cfg,messages)
  if p!=r['payload']:self.mismatches.append({'logical_id':lid,'type':'payload'})
  if meta!=r['metadata']:self.mismatches.append({'logical_id':lid,'type':'metadata'})
  self.used.append(lid);return copy.deepcopy(r)

def compare_records(a,b):
 excluded={'planning_seconds','probe_seconds','tool_seconds'}
 return {k:(a.get(k),b.get(k)) for k in set(a)|set(b) if k not in excluded and a.get(k)!=b.get(k)}

allmetrics={};calltable=[];rctable=[];rltable=[];examples=[]
for root in sorted((BASE/'runs').iterdir()):
 manifest=load(root/'manifest.json');study=manifest['study'];spec=manifest['spec'];cfg=manifest['config']
 actual_files={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 export=load(root/'EXPORT_MANIFEST.json')['sha256']
 hash_bad=[k for k,v in export.items() if not (root/k).exists() or sha(root/k)!=v]
 missing=set(export)-actual_files;extra=actual_files-set(export)-{'EXPORT_MANIFEST.json'}
 source_bad=[]
 for k,v in manifest['source_hashes'].items():
  if sha(root/'code_snapshot'/k)!=v or sha(ORIGINAL/k)!=v:source_bad.append(k)
 assert not source_bad,source_bad # only execute matched original code
 contract={k:manifest[k] for k in ['version','config','study','spec','source_hashes']}
 calls0=[load(p) for p in (root/'calls').glob('*.json')];calls={c['logical_id']:c for c in calls0}
 starts=[load(p) for p in sorted((root/'attempts').glob('*_start.json'))];results=[load(p) for p in sorted((root/'attempts').glob('*_result.json'))]
 ids=[r['attempt'] for r in results];ledger_bad=[];request_bad=[];parse_bad=[];usage_bad=[];time_bad=[]
 cost=0.;tokens=Counter();fp=Counter();models=Counter();phases=defaultdict(lambda:Counter())
 endpoint='https://api.deepseek.com/v1'
 endpoint_hash=digest(endpoint)
 for r in results:
  idx=r['attempt'];st=starts[idx-1]
  if any(r.get(k)!=v for k,v in st.items()):ledger_bad.append([idx,'start/result'])
  if r['status']=='ok' and calls.get(r['logical_id'])!=r:ledger_bad.append([idx,'call/result'])
  if digest({'endpoint':endpoint,'payload':r['payload']})!=r['request_sha256']:request_bad.append(idx)
  if r['status']!='ok':continue
  body=r['response'];usage=body['usage'];ch=body['choices'][0];text=ch['message']['content']
  if text!=r['text']:ledger_bad.append([idx,'content/text'])
  try:strict_json_object(text)
  except Exception:parse_bad.append(r['logical_id'])
  pi=usage['prompt_tokens'];co=usage['completion_tokens'];ca=usage.get('prompt_cache_hit_tokens',0)
  re=usage.get('completion_tokens_details',{}).get('reasoning_tokens',0)
  if pi+co!=usage['total_tokens'] or ca!=usage.get('prompt_tokens_details',{}).get('cached_tokens',0) or not 0<=re<=co:usage_bad.append(idx)
  expected=((pi-ca)*cfg['prices']['input_per_million']+ca*cfg['prices']['cached_input_per_million']+co*cfg['prices']['output_per_million'])/1e6
  if abs(expected-r['estimated_cost'])>1e-12:ledger_bad.append([idx,'estimated_cost'])
  cost+=expected;tokens.update(prompt=pi,completion=co,reasoning=re,cached=ca,visible_by_difference=co-re)
  fp[body.get('system_fingerprint')]+=1;models[body['model']]+=1
  start=datetime.fromisoformat(r['started_utc']);end=datetime.fromisoformat(r['ended_utc']);created=datetime.fromtimestamp(body['created'],timezone.utc)
  if not start.timestamp()-2<=created.timestamp()<=end.timestamp()+2:time_bad.append(idx)
  ph=r['metadata'].get('phase','unknown');phases[ph].update(n=1,prompt=pi,completion=co,reasoning=re,latency=r['latency_seconds'],estimated_usd=expected)
  calltable.append({'study':study,'logical_id':r['logical_id'],'attempt':idx,'phase':ph,'method':r['metadata'].get('method','shared_or_smoke'),'started_utc':r['started_utc'],'ended_utc':r['ended_utc'],'response_created_utc':created.isoformat(),'weekday':created.strftime('%A'),'returned_model':body['model'],'finish_reason':ch['finish_reason'],'prompt_tokens':pi,'cached_tokens':ca,'completion_tokens':co,'reasoning_tokens':re,'peak_config_usd':expected,'latency_s':r['latency_seconds']})
 common={'file_entries':len(actual_files),'export_hashed_files':len(export),'export_hash_mismatches':hash_bad,'export_missing':sorted(missing),'export_unlisted':sorted(extra),'source_files':len(manifest['source_hashes']),'source_mismatches_vs_original':source_bad,'contract_hash_ok':digest(contract)==manifest['fingerprint'],'endpoint_hash_ok':endpoint_hash==cfg['base_url_sha256'],'attempt_starts':len(starts),'attempt_results':len(results),'call_files':len(calls0),'unique_logical_calls':len(calls),'attempt_indices_contiguous':ids==list(range(1,len(ids)+1)),'ledger_mismatches':ledger_bad,'request_hash_mismatches':request_bad,'json_parse_errors':parse_bad,'usage_errors':usage_bad,'timestamps_outside_call_window':time_bad,'finish_reasons':dict(Counter(r['response']['choices'][0]['finish_reason'] for r in results if r['status']=='ok')),'request_statuses':dict(Counter(r['status'] for r in results)),'returned_models':dict(models),'system_fingerprints':dict(fp),'peak_config_usd':cost,'tokens':dict(tokens),'phases':{k:dict(v) for k,v in phases.items()},'max_reasoning':max((r['response']['usage']['completion_tokens_details']['reasoning_tokens'],r['logical_id']) for r in calls0),'start_utc':min(r['started_utc'] for r in starts),'end_utc':max(r['ended_utc'] for r in results)}
 if study=='smoke':
  common['json_ok']=strict_json_object(calls0[0]['text'])=={'ok':True};allmetrics[study]=common;continue
 # Regenerate all public prompts and actual tool results with original code offline.
 rerun=BASE/'offline_replay'/study
 if rerun.exists():shutil.rmtree(rerun)
 rc=ReplayClient(calls,cfg)
 module=recheck if study=='recheck' else readiness
 module.run(rc,cfg,rerun,spec)
 common['offline_replay_calls']=len(rc.used);common['offline_payload_mismatches']=rc.mismatches
 common['offline_record_mismatches']=[]
 for p in (root/'records').glob('*.json'):
  d=compare_records(load(p),load(rerun/'records'/p.name))
  if d:common['offline_record_mismatches'].append({'record':p.name,'diff':d})
 common['offline_private_and_prefix_mismatches']=[]
 for sub in ['private','prefixes']:
  for p in (root/sub).glob('*.json'):
   if load(p)!=load(rerun/sub/p.name):common['offline_private_and_prefix_mismatches'].append(sub+'/'+p.name)
 methods=defaultdict(lambda:Counter())
 submitted=list(csv.DictReader((root/'per_task.csv').open(encoding='utf-8-sig')))
 summary_bad=[]
 if study=='recheck':
  cases={c['stream']:c for c in load(root/'private/recheck_cases.json')}
  rows={p.stem:load(p) for p in (root/'records').glob('*.json')}
  equality=Counter()
  for rowid,r in sorted(rows.items()):
   case=cases[r['stream']];task=case['tasks'][r['step']];mode=task['modes'];q=task['type'];memory=r['worker_view']['memory']
   correct,plan_valid=rc_score(r,case)
   stale_amount=memory['amount_divisor']!=(100 if mode[0] else 1);stale_endpoint=memory['endpoint_inclusive']!=bool(mode[1])
   stale_needed=(q in (0,2) and stale_amount) or (q in (1,2) and stale_endpoint)
   owncalls=[calls[x] for x in r['logical_calls']];cst=sum(x['estimated_cost'] for x in owncalls);lat=sum(x['latency_seconds'] for x in owncalls)
   row={'record_id':rowid,'stream':r['stream'],'step':r['step'],'method':r['method'],'regime':case['regime'],'task_type':q,'correct':int(correct),'plan_valid':int(plan_valid),'stale_amount':int(stale_amount),'stale_endpoint':int(stale_endpoint),'stale_needed':int(stale_needed),'probes':r['probe_count'],'probe_proxy_not_currency':r['model_probe_cost'],'peak_config_usd':cst,'latency_s':lat,'prompt_tokens':sum(x['response']['usage']['prompt_tokens'] for x in owncalls),'completion_tokens':sum(x['response']['usage']['completion_tokens'] for x in owncalls)}
   rctable.append(row);methods[r['method']].update(n=1,correct=correct,plan_invalid=not plan_valid,stale_needed=stale_needed,probes=r['probe_count'],proxy=r['model_probe_cost'],peak_config_usd=cst,latency_s=lat)
   orig=next(x for x in submitted if int(x['unit'])==r['stream'] and int(x['step'])==r['step'] and x['method']==r['method'])
   if int(orig['correct'])!=correct or int(orig['plan_valid'])!=plan_valid:summary_bad.append(rowid)
   if not correct or stale_needed:
    examples.append({'record_id':rowid,'classification':('stale_evidence_error' if stale_needed and not correct else 'stale_evidence_correct' if stale_needed else 'fresh_evidence_error'),'row':r,'gold_total':sum(case['cents'])/100,'gold_count':len(case['cents']) if q==3 else sum(i<=task['cutoff'] for i in range(len(case['cents']))),'true_modes':mode})
  for s in cases:
   for t in range(spec['steps']):
    a=rows[f'rc_{s:03d}_{t:03d}_recheck'];b=rows[f'rc_{s:03d}_{t:03d}_myopic']
    for key in ['ages_before','probed_channels','worker_view','plan','answer']:
     equality[key]+=a[key]==b[key]
    for phase in ['plan','answer']:
     equality['payload_'+phase]+=calls[f'rc/{s}/{t}/recheck/{phase}']['payload']==calls[f'rc/{s}/{t}/myopic/{phase}']['payload']
  common['recheck_myopic_equal_pairs']=dict(equality)
  common['world_trajectories']={s:{'regime':c['regime'],'initial_modes':c['initial_modes'],'task_types':[t['type'] for t in c['tasks']],'modes':[t['modes'] for t in c['tasks']],'mode_changes':sum(sum(a!=b for a,b in zip(prev,t['modes'])) for prev,t in zip([c['initial_modes']]+[x['modes'] for x in c['tasks'][:-1]],c['tasks']))} for s,c in cases.items()}
 else:
  cases={c['case']:c for c in load(root/'private/readiness_cases.json')}
  for p in sorted((root/'records').glob('*.json')):
   r=load(p);c=cases[r['case']]
   old={s['id']:artifact_gold(ru,c['old_sources']) for s,ru in zip(c['specs'],c['evaluator_rules'])};new={s['id']:artifact_gold(ru,c['new_sources']) for s,ru in zip(c['specs'],c['evaluator_rules'])}
   ok=all(artifact_ok(r['final_artifacts'].get(k),v) for k,v in new.items()) and r['selection_error'] is None
   affected=[k for k in old if old[k]!=new[k]];owncalls=[calls[x] for x in r['logical_calls']]
   row={'case':r['case'],'method':r['method'],'correct':int(ok),'affected':','.join(affected),'selected':','.join(sorted(r['selected_artifacts'])),'call_count':len(owncalls),'peak_config_usd':sum(x['estimated_cost'] for x in owncalls),'latency_s':sum(x['latency_seconds'] for x in owncalls),'prompt_tokens':sum(x['response']['usage']['prompt_tokens'] for x in owncalls),'completion_tokens':sum(x['response']['usage']['completion_tokens'] for x in owncalls),'missed':len(set(affected)-set(r['selected_artifacts'])),'unneeded_selected':len(set(r['selected_artifacts'])-set(affected))}
   rltable.append(row);methods[r['method']].update(n=1,correct=ok,calls=row['call_count'],peak_config_usd=row['peak_config_usd'],latency_s=row['latency_s'],missed=row['missed'])
   orig=next(x for x in submitted if int(x['unit'])==r['case'] and x['method']==r['method'])
   if int(orig['correct'])!=ok:summary_bad.append(p.stem)
 common['independent_score_mismatches']=summary_bad;common['methods']={k:dict(v) for k,v in methods.items()}
 allmetrics[study]=common

save('audit_metrics.json',allmetrics);save('error_examples.json',examples)
for filename,rows in [('call_audit.csv',calltable),('recheck_recomputed.csv',rctable),('repair_readiness_recomputed.csv',rltable)]:
 with (OUT/filename).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(allmetrics,ensure_ascii=False,indent=2))
