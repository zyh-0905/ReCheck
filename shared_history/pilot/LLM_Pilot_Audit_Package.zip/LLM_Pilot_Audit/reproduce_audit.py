#!/usr/bin/env python3
"""Recompute this audit from the submitted bundle and original kit. No API calls."""
import argparse,json,os,stat,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath

def unpack(src,dst):
    with zipfile.ZipFile(src) as z:
        items=z.infolist()
        if sum(i.file_size for i in items)>150_000_000:
            raise ValueError('Archive exceeds this audit size bound')
        names=set()
        for i in items:
            p=PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or i.filename in names or stat.S_ISLNK(i.external_attr>>16):
                raise ValueError('Unsafe or duplicate archive member')
            names.add(i.filename)
        z.extractall(dst)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--feedback',type=Path,required=True)
    ap.add_argument('--kit',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    out=args.out.resolve()
    if out.exists():raise ValueError('Use a new output directory; no evidence is overwritten')
    out.mkdir(parents=True)
    unpack(args.feedback,out/'submitted');unpack(args.kit,out/'original')
    packs=list((out/'submitted').rglob('上传包/*.zip'))
    if len(packs)!=3:raise ValueError('This audit expects the submitted three complete run exports')
    for pack in packs:unpack(pack,out/'runs'/pack.stem)
    script=Path(__file__).resolve().with_name('audit_feedback.py')
    with (out/'audit_stdout.json').open('w',encoding='utf-8') as f:
        subprocess.run([sys.executable,str(script)],env={**os.environ,'PILOT_AUDIT_BASE':str(out)},stdout=f,check=True)
    metrics=json.loads((out/'audit_results/audit_metrics.json').read_text())
    checked=('export_hash_mismatches','export_missing','export_unlisted','source_mismatches_vs_original',
        'ledger_mismatches','request_hash_mismatches','json_parse_errors','usage_errors','timestamps_outside_call_window',
        'offline_payload_mismatches','offline_record_mismatches','offline_private_and_prefix_mismatches','independent_score_mismatches')
    failures={s:{k:m.get(k) for k in checked if m.get(k)}for s,m in metrics.items()}
    failures={k:v for k,v in failures.items()if v}
    if failures:raise RuntimeError(json.dumps(failures,ensure_ascii=False))
    print('Artifact consistency and independent rescoring checks passed; see audit_results/.')
    print('This does NOT certify backend identity, invoice charges, or manuscript-level scientific validity.')

if __name__=='__main__':main()
