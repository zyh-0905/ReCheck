#!/usr/bin/env python3
"""Read-only R6 audit. All generated outputs go to a new directory.
Requires Python 3.11+ and numpy for paired bootstrap only. No provider calls.
"""
from pathlib import Path, PurePosixPath
from collections import Counter,defaultdict
from contextlib import contextmanager
import argparse,copy,csv,hashlib,json,math,random,socket,stat,tempfile,zipfile,time
import numpy as np
from independent import (bits,expected,gold,strict_equal,compare_trajectory,
                        canonical_cell,cost_units,predicted,purchased_table,all_cells,single_cells)

LEARNERS=('single','full','random','occupancy','decision')

def load(p):
    def bad(s):raise ValueError('nonfinite JSON constant '+s)
    return json.loads(Path(p).read_text(encoding='utf-8'),parse_constant=bad)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x):return hashlib.sha256(canonical(x)).hexdigest()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvout(p,rows):
    if not rows:return
    with Path(p).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def csvread(p):
    with Path(p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def check(ok,message):
    if not ok:raise AssertionError(message)

def safe_extract(zpath,out):
    with zipfile.ZipFile(zpath) as z:
        names=z.namelist();check(len(set(names))==len(names),'duplicate zip entries')
        check(len(names)<40000 and sum(i.file_size for i in z.infolist())<=400_000_000,'zip expansion limit')
        for i in z.infolist():
            n=i.filename;p=PurePosixPath(n)
            check(not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n,'unsafe zip path')
            check(not stat.S_ISLNK(i.external_attr>>16) and not (i.flag_bits&1),'links/encryption disallowed')
            if n.startswith('__MACOSX/') or i.is_dir():continue
            dest=out/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(i))

def bundle_check(root):
    meta=load(root/'BUNDLE_MANIFEST.json');actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    check(actual==set(meta['files'])|{'BUNDLE_MANIFEST.json'},'bundle membership')
    for name,v in meta['files'].items():
        p=root/name;check(p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],'bundle hash '+name)
    return len(meta['files'])

def own_rows(seed,profile='standard',size=23):
    r=random.Random(seed);out=[]
    for i in range(size):out.append({'sku':f'SKU-{i:03d}','physical':r.randint(0,25),'reserved':r.randint(0,12),'category':r.choice(['A','B','C']),'active':bool(r.getrandbits(1))})
    if profile=='reservation_free_clustered':
        for row in out:row['reserved']=0
        out.sort(key=lambda row:(row['category'],row['sku']))
    return out

def own_task(q,rows,seed):
    r=random.Random(seed)
    return {'type':q if q<2 else 2,'category':r.choice(['A','B','C']),'minimum':(3,12,22)[q-2] if q>=2 else 3,'skus':sorted(r.sample([v['sku'] for v in rows],5))}

def own_cases(p):
    out=[];n=p['streams_per_condition'];rho=p['persistence']
    P=[[rho if i==j else (1-rho)/4 for j in range(5)] for i in range(5)]
    for panel in range(p['calibration_panels']):
        for ci,condition in enumerate(p['conditions']):
            for rep in range(n):
                sid=(panel*len(p['conditions'])+ci)*n+rep
                seeds={k:v+sid for k,v in p['evaluation_seeds'].items()};rows=own_rows(seeds['data'],condition['data_profile'],p['catalog_size'])
                task_rng=random.Random(seeds['tasks']);mode_rng=random.Random(seeds['modes']);m=mode_rng.randrange(8);initial=m;q=rep%5;steps=[]
                for t in range(p['steps']):
                    if t:q=task_rng.choices(range(5),P[q])[0]
                    for j in range(3):
                        if mode_rng.random()<condition['actual_hazard']:m^=1<<j
                    steps.append({'q':q,'task':own_task(q,rows,seeds['tasks']*1000+t),'true_mode':m})
                out.append({'id':sid,'panel':panel,'condition':condition['name'],'profile':condition['data_profile'],'seeds':seeds,'initial_mode':initial,'rows':rows,'steps':steps})
    return out

def memory(m):
    b=bits(m);return {'first_page':b[0],'active_code':1-b[1],'stock_semantics':'gross' if b[2] else 'net'}
def own_plan(task,m):
    typ=task['type'];req={'workflow':('catalog_ids','stock_sum','available_ids')[typ]}
    if typ in (0,2):req.update(category=task['category'],page_size=3)
    if typ==1:req['skus']=task['skus']
    if typ==2:req['minimum_available']=task['minimum']
    keys=(('first_page','active_code'),('stock_semantics',),('first_page','active_code','stock_semantics'))[typ]
    ev={k:memory(m)[k] for k in keys};return req,ev,{**req,**ev}
def packets(menu):
    out={f's{j}':([j],2) for j in range(3)}
    if menu=='shared':out.update(p01=([0,1],3),p12=([1,2],3))
    return out

def receipt(name,cover,cost,z):
    b=bits(z);obs=[]
    for j in cover:
        if j==0:obs.append({'channel':0,'fixture':'known first item CAL-A then CAL-B','page0':{'error':'PAGE_BEFORE_FIRST'} if b[0] else {'first_sku':'CAL-A'},'page1':{'first_sku':'CAL-A' if b[0] else 'CAL-B'}})
        elif j==1:obs.append({'channel':1,'fixture':'known active CANARY-A and inactive CANARY-I','active_example_code':1-b[1],'inactive_example_code':b[1]})
        else:obs.append({'channel':2,'fixture':'known physical=10 reserved=4','physical':10,'reserved':4,'stock_value':10 if b[2] else 6})
    return {'packet_id':name,'credit_cost':cost,'observations':obs}

def probability_compare(x,y,limit=1e-12):
    return type(x) is type(y) and (x is None or (type(x) is float and math.isfinite(x) and math.isfinite(y) and abs(x-y)<=limit))

def verify_calibration(run,reference,p,output):
    models={};event_n=0;references=0;label_n=0;cp_n=0;costs=[];selection_rows=[];ref_tolerance=[]
    cells=all_cells();singles=single_cells();check(len(cells)==182 and len(singles)==82,'cell domain')
    for panel in range(4):
        seeds=list(range(p['calibration_seed']+panel*1000,p['calibration_seed']+panel*1000+16))
        catalogs={s:own_rows(s) for s in seeds};tasks={(s,q):own_task(q,catalogs[s],s*100+q) for s in seeds for q in range(5)}
        for learner in LEARNERS:
            name=f'panel_{panel:03d}_{learner}.json';res=load(run/'calibration'/name);ref=load(reference/'calibration'/name)
            check(res['training_seeds']==seeds,'training split')
            state={};ref_seen=set();label_seen=defaultdict(list);keys_order=[];expected_event=0
            for i,e in enumerate(res['ledger']):
                check(e['sequence']==i,'event order');check(e['seed'] in seeds,'bad training seed')
                task=tasks[e['seed'],e['q']];ans,trace=expected(catalogs[e['seed']],task,e['m'],e['z'])
                check(strict_equal(e['answer'],ans) and strict_equal(e['trace'],trace),'calibration execution/trace')
                if e['kind']=='reference':
                    check((e['seed'],e['q']) not in ref_seen and e['m']==e['z']==0,'reference duplication/type')
                    check(strict_equal(ans,gold(catalogs[e['seed']],task)),'reference value');ref_seen.add((e['seed'],e['q']));references+=1
                else:
                    c=(e['q'],e['m'],e['z']);check(c==canonical_cell(*c) and c in cells,'invalid purchased cell')
                    check((e['seed'],e['q']) in ref_seen,'reference not yet paid')
                    check(e['reference_key']==f'{e["seed"]}:{e["q"]}','wrong reference key')
                    check(type(e['failure']) is int and e['failure']==int(ans!=gold(catalogs[e['seed']],task)),'calibration label')
                    if c not in label_seen:keys_order.append(c)
                    label_seen[c].append((e['seed'],e['failure'],i));label_n+=1
                re=ref['ledger'][i];x={k:v for k,v in e.items() if k!='workflow_seconds'};y={k:v for k,v in re.items() if k!='workflow_seconds'}
                check(strict_equal(x,y),'calibration vs reference')
                event_n+=1
            check(len(res['ledger'])==len(ref['ledger'])==res['total_physical_workflows'],'ledger count')
            check(len(ref_seen)==80 and len(keys_order)*16==res['label_workflows'],'cost count')
            check(keys_order[:82]==singles,'initial single-cell ordering')
            for c,arr in label_seen.items():check([s for s,_,_ in arr]==seeds,'atom seed duplication')
            bought=set(singles)
            def obs(keys):
                return {':'.join(map(str,c)):{'cell':list(c),'n':16,'failures':sum(v for _,v,_ in label_seen[c]),'labels':[v for _,v,_ in label_seen[c]],'mean':sum(v for _,v,_ in label_seen[c])/16} for c in sorted(keys)}
            previous=obs(bought)
            for i,e in enumerate(res['selection']):
                c=tuple(e['cell']);check(c not in bought and c in cells and (c[1]^c[2]).bit_count()>=2,'invalid acquisition')
                check(c==keys_order[82+i],'selection vs paid label order');check(e['index']==i,'selector index')
                check(e['observed_keys_before_sha256']==digest(sorted(':'.join(map(str,k)) for k in bought)),'selector information prefix')
                check(e['workflow_count_before']==1392+16*i and e['workflow_count_after']==1392+16*(i+1),'acquisition marginal cost')
                check(e['label_n']==16 and e['label_failures']==sum(v for _,v,_ in label_seen[c]),'selected label')
                tab=purchased_table(previous);prior=tab[c[0]][c[1]][c[2]];actual=e['label_failures']/16
                selection_rows.append({'panel':panel,'learner':learner,'purchase_index':i+1,'cell':':'.join(map(str,c)),'q':c[0],'before_prediction':prior,'observed_mean':actual,'absolute_update':abs(prior-actual),'no_model_update':int(prior==actual),'selector_score':e['score']})
                re=ref['selection'][i]
                check(strict_equal({k:v for k,v in e.items() if k not in ('score','selection_seconds')},{k:v for k,v in re.items() if k not in ('score','selection_seconds')}),'choice vs reference')
                check(probability_compare(e['score'],re['score']),'selector score')
                if e['score'] is not None and e['score']!=re['score']:ref_tolerance.append(abs(e['score']-re['score']))
                bought.add(c);previous=obs(bought)
            if learner=='random':
                order=[c for c in cells if c not in singles];random.Random(p['selector_seed']+panel*1000+LEARNERS.index(learner)).shuffle(order)
                check([tuple(e['cell']) for e in res['selection']]==order[:32],'random order')
            for k,cp in res['checkpoints'].items():
                selected=keys_order[82:82+int(k)];chosen=singles+selected;measured=obs(chosen)
                check(strict_equal(cp['observed'],measured),'checkpoint includes future/unpaid label')
                check(cp['selected_cells']==[list(c) for c in selected],'checkpoint selection')
                check(strict_equal(cp['table'],purchased_table(measured)),'checkpoint table')
                check(cp['oracle_event_count']==1392+int(k)*16 and cp['selection_event_count']==int(k),'checkpoint prefix size')
                check(cp['model_fingerprint']==digest({'observed':measured,'training_seeds':seeds}),'model fingerprint')
                method='single_only' if learner=='single' else 'full_joint' if learner=='full' else learner+'_'+k
                m=load(run/f'models/panel_{panel:03d}_{method}.json');check(strict_equal({x:m[x] for x in cp},cp),'model/checkpoint binding')
                check(m['panel']==panel,'model panel');models[panel,method]=m;cost=cp['cost']
                prefix=res['ledger'][:cp['oracle_event_count']]
                check(cost['tool_calls']==sum(len(e['trace']) for e in prefix),'checkpoint tool cost')
                check(cost['reference_executions']==80 and cost['label_executions']==16*len(chosen) and cost['total_workflows']==len(prefix),'checkpoint totals')
                costs.append({'panel':panel,'method':method,'label_executions':cost['label_executions'],'reference_executions':cost['reference_executions'],'total_workflows':cost['total_workflows'],'tool_calls':cost['tool_calls'],'selector_seconds':cp['selector_seconds'],'acquisition_elapsed_seconds':cp['acquisition_elapsed_seconds'],'design_build_seconds':cp['design_build_seconds'],'standalone_with_design_seconds':cp['acquisition_elapsed_seconds']+cp['design_build_seconds'],'label_execution_seconds':cost['label_execution_seconds'],'reference_execution_seconds':cost['reference_execution_seconds']})
                cp_n+=1
        for method in ['any_exact','never']:
            m=load(run/f'models/panel_{panel:03d}_{method}.json');tab=[[[float(canonical_cell(q,mm,z)[1]!=canonical_cell(q,mm,z)[2]) for z in range(8)] for mm in range(8)] for q in range(5)]
            check(m['table']==tab and m['cost']['total_workflows']==0 and not m['observed'],'untrained model');models[panel,method]=m
    csvout(output/'calibration_recomputed.csv',costs);csvout(output/'selection_effects.csv',selection_rows)
    return models,{'workflow_events_checked':event_n,'references':references,'labels':label_n,'checkpoints_checked':cp_n,'diagnostic_score_differences':len(ref_tolerance),'maximum_score_delta':max(ref_tolerance,default=0.)},costs,selection_rows

def verify_trajectories(run,reference,p,models,output):
    cases=load(run/'private/cases.json');check(strict_equal(cases,own_cases(p)),'test cases regenerate')
    check(len({c['seeds']['data'] for c in cases})==128,'test catalog duplicates')
    tids={s for panel in range(4) for s in range(p['calibration_seed']+1000*panel,p['calibration_seed']+1000*panel+16)}
    check(not tids&{c['seeds']['data'] for c in cases},'training/test overlap')
    tasks=[];streams=[];data_by_key={};pred_d=[];reference_pred_d=[];raw_science_equal=0
    for case in cases:
        for menu in p['menus']:
            for method in p['methods']:
                fname=f'{case["id"]:03d}_{menu}_{method}.json';tr=load(run/'trajectories'/fname);ref=load(reference/'trajectories'/fname)
                comp=compare_trajectory(tr,ref);check(comp['pass'],'cross-machine trajectory '+fname)
                reference_pred_d.extend([comp['max_probability_delta']] if comp['probabilities_different'] else [])
                if comp['probabilities_different']==0:raw_science_equal+=1
                m=models[case['panel'],method];check(tr['calibration_fingerprint']==m['model_fingerprint'] and tr['case_sha256']==digest(case),'trajectory binding')
                check(tr['stream']==case['id'] and tr['panel']==case['panel'] and tr['menu']==menu and tr['method']==method and tr['condition']==case['condition'],'trajectory metadata')
                check(tr['startup_credits_equivalent']==6 and tr['startup_outside_runtime_budget'] is True and tr['llm_calls']==0,'startup accounting')
                check(tr['initial_receipts']==[receipt('initial_all',[0,1,2],6,case['initial_mode'])],'initial receipts')
                check(len(tr['records'])==p['steps'],'task count')
                bank=p['budget'];ages=[0]*3;mem=case['initial_mode'];failures=credits=0;stale_n=stale_ok=0
                for i,(rec,step) in enumerate(zip(tr['records'],case['steps'])):
                    ps=packets(menu);ids=rec['packets'];check(len(ids)==len(set(ids)) and all(x in ps for x in ids),'packet IDs')
                    cost=sum(ps[x][1] for x in ids);cover=sorted({j for x in ids for j in ps[x][0]});mask=sum(1<<j for j in cover)
                    before_ages=[x+1 for x in ages];new=(mem&(~mask&7))|(step['true_mode']&mask)
                    check(type(cost) is int and cost<=p['step_cap'] and cost<=bank,'hard budget')
                    required={'step':i,'q':step['q'],'remaining_horizon':p['steps']-i,'ages_before':before_ages,'memory_before':mem,'memory_after':new,'budget_before':bank,'budget_after':bank-cost,'cover':cover,'credits':cost}
                    check(strict_equal({k:rec[k] for k in required},required),'record state/types')
                    check(strict_equal(rec['receipts'],[receipt(pid,ps[pid][0],ps[pid][1],step['true_mode']) for pid in ids]),'probe receipt')
                    req,ev,plan=own_plan(step['task'],new);check(strict_equal(plan,rec['plan']) and strict_equal(req,rec['view']['request']) and strict_equal(ev,rec['view']['evidence']),'compiler/view')
                    ans,trace=expected(case['rows'],step['task'],new,step['true_mode']);g=gold(case['rows'],step['task'])
                    check(strict_equal(ans,rec['answer']) and strict_equal(trace,rec['trace']),'independent runtime execution')
                    ages=[0 if j in cover else before_ages[j] for j in range(3)];prob=predicted(m['table'],step['q'],new,ages,p['hazards']);rp=rec['predicted_task_error_after_receipts']
                    check(type(rp) is float and math.isfinite(rp) and 0<=rp<=1 and abs(prob-rp)<=1e-14,'probability')
                    if prob!=rp:pred_d.append(abs(prob-rp))
                    f=int(ans!=g);a,b=canonical_cell(step['q'],new,step['true_mode'])[1:];stale=(a!=b)
                    tasks.append({'stream':case['id'],'panel':case['panel'],'condition':case['condition'],'menu':menu,'method':method,'step':i,'failure':f,'credits':cost,'cost_units':cost_units(f,cost),'stale_relevant':int(stale),'stale_but_correct':int(stale and not f),'q':step['q'],'predicted_failure':rp})
                    failures+=f;credits+=cost;stale_n+=int(stale);stale_ok+=int(stale and not f);bank-=cost;mem=new
                streams.append({'stream':case['id'],'panel':case['panel'],'condition':case['condition'],'menu':menu,'method':method,'successes':p['steps']-failures,'failures':failures,'credits':credits,'task_cost_units':cost_units(failures,credits),'runtime_j':cost_units(failures,credits)/20,'stale_relevant':stale_n,'stale_but_correct':stale_ok})
                data_by_key[case['id'],menu,method]=tr
    csvout(output/'tasks_recomputed.csv',tasks);csvout(output/'streams_recomputed.csv',streams)
    return cases,tasks,streams,data_by_key,{'trajectories':len(streams),'task_records':len(tasks),'cross_machine_exact_science':raw_science_equal,'cross_machine_probability_differences':len(reference_pred_d),'max_cross_machine_probability_delta':max(reference_pred_d,default=0.),'independent_probability_differences':len(pred_d),'max_independent_probability_delta':max(pred_d,default=0.),'budget_violations':0}

def scientific_summaries(run,p,models,cases,tasks,streams,trajectories,output):
    grouping=defaultdict(list)
    for row in streams:grouping[row['condition'],row['menu'],row['method']].append(row)
    sums=[]
    for (condition,menu,method),rs in sorted(grouping.items()):
        n=len(rs);f=sum(r['failures'] for r in rs);credits=sum(r['credits'] for r in rs);u=cost_units(f,credits)
        sums.append({'condition':condition,'menu':menu,'method':method,'task_records':n*p['steps'],'base_streams':n,'successes':n*p['steps']-f,'failures':f,'probe_credits':credits,'task_cost_units':u,'runtime_j_total':u/20,'runtime_j_per_episode':u/(20*n),'standalone_calibration_workflows_per_panel':sum(models[panel,method]['cost']['total_workflows'] for panel in range(4))/4})
    submitted=csvread(run/'audit/summary.csv');check(len(submitted)==len(sums),'summary rowcount')
    for a,b in zip(sums,submitted):
        for k,v in a.items():check(str(v)==b[k] if isinstance(v,str) else float(b[k])==float(v),'summary '+k)
    csvout(output/'summary_recomputed.csv',sums)
    per={(s['stream'],s['menu'],s['method']):s['task_cost_units'] for s in streams};rng=np.random.default_rng(p['statistics']['resample_seed']);B=p['statistics']['bootstrap_repetitions'];paired=[]
    pairs=[('full_joint','single_only'),('decision_16','single_only'),('decision_32','single_only'),('decision_16','random_16'),('decision_32','random_32'),('decision_16','occupancy_16'),('decision_32','occupancy_32'),('decision_16','full_joint'),('decision_32','full_joint')]
    def pair(cond,menu,left,right):
        arrays=[]
        for panel in range(4):
            ids=[c['id'] for c in cases if c['condition']==cond and c['panel']==panel]
            lm,rm=('shared','single') if menu=='shared_minus_single' else (menu,menu)
            arrays.append(np.array([per[i,lm,left]-per[i,rm,right] for i in ids],dtype=float)/20)
        boot=np.zeros(B)
        for arr in arrays:boot+=arr[rng.integers(0,len(arr),size=(B,len(arr)))].mean(axis=1)/4
        flat=np.concatenate(arrays);lo,hi=np.quantile(boot,[.025,.975])
        paired.append({'condition':cond,'menu':menu,'left':left,'right':right,'mean_runtime_j_delta':float(flat.mean()),'ci_low':float(lo),'ci_high':float(hi),'left_better_streams':int((flat<0).sum()),'tied_streams':int((flat==0).sum()),'left_worse_streams':int((flat>0).sum()),'training_panels':4,'evaluation_streams':len(flat),'inference':'descriptive_conditional_on_four_fitted_panels_not_confirmatory'})
    for cond in p['conditions']:
        for menu in p['menus']:
            for l,r in pairs:pair(cond['name'],menu,l,r)
    for cond in p['conditions']:
        for method in p['methods']:pair(cond['name'],'shared_minus_single',method,method)
    csvout(output/'paired_recomputed.csv',paired)
    check((output/'paired_recomputed.csv').read_bytes()==(run/'audit/paired.csv').read_bytes(),'paired bootstrap csv')
    effects=[]
    for left,right in [('decision_32','random_32'),('decision_16','random_16'),('decision_32','decision_16'),('random_32','random_16'),('full_joint','single_only')]:
        for c in cases:
            for menu in p['menus']:
                a=trajectories[c['id'],menu,left];b=trajectories[c['id'],menu,right]
                action_diff=evidence_diff=answer_diff=0
                for x,y in zip(a['records'],b['records']):
                    action_diff+=int(x['packets']!=y['packets']);evidence_diff+=int(x['view']!=y['view']);answer_diff+=int(x['answer']!=y['answer'])
                effects.append({'stream':c['id'],'panel':c['panel'],'condition':c['condition'],'menu':menu,'left':left,'right':right,'action_differences':action_diff,'public_input_differences':evidence_diff,'answer_differences':answer_diff,'cost_units_delta':per[c['id'],menu,left]-per[c['id'],menu,right]})
    csvout(output/'treatment_effects.csv',effects)
    aggregate=[]
    for m in p['methods']:
        rs=[r for r in streams if r['method']==m];fail=sum(r['failures'] for r in rs);credits=sum(r['credits'] for r in rs)
        aggregate.append({'method':m,'paired_policy_episodes':len(rs),'independent_base_streams':128,'task_records':len(rs)*8,'successes':len(rs)*8-fail,'failures':fail,'probe_credits':credits,'runtime_j_total':cost_units(fail,credits)/20,'runtime_j_per_paired_episode':cost_units(fail,credits)/(20*len(rs)),'runtime_j_per_task':cost_units(fail,credits)/(20*len(rs)*8),'note':'mixed conditions, paired menus; descriptive only'})
    csvout(output/'method_aggregate_corrected.csv',aggregate)
    # Verify the hypothetical cost frontier, not an invoice.
    for r in csvread(run/'audit/cost_frontier.csv'):
        v=float(r['runtime_j_per_episode'])+.3+float(r['price_per_calibration_workflow'])*float(r['standalone_calibration_workflows'])/int(r['deployment_episodes'])
        check(abs(v-float(r['amortized_proxy_per_episode']))<1e-12,'cost sensitivity')
    return aggregate,paired,effects

@contextmanager
def offline():
    original=socket.socket,socket.create_connection,socket.getaddrinfo
    def deny(*a,**k):raise RuntimeError('AUDIT_OFFLINE_ONLY')
    socket.socket=socket.create_connection=socket.getaddrinfo=deny
    try:yield
    finally:socket.socket,socket.create_connection,socket.getaddrinfo=original

def audit(feedback,kit,reference,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    inputs={str(Path(p).name):sha(p) for p in (feedback,kit,reference)}
    with tempfile.TemporaryDirectory(prefix='r6_independent_') as tmp,offline():
        w=Path(tmp);safe_extract(feedback,w/'outer')
        if (w/'outer/BUNDLE_MANIFEST.json').exists():user=w/'outer'
        else:
            inner=list((w/'outer').rglob('R6_feedback_*.zip'));check(len(inner)==1,'feedback archive identification')
            safe_extract(inner[0],w/'user');user=w/'user'
        safe_extract(kit,w/'original');original=w/'original/R6_Research_Kit'
        safe_extract(reference,w/'reference');ref=w/'reference'
        nfiles=bundle_check(user);bundle_check(ref)
        src=load(original/'SOURCE_MANIFEST.json');m=load(user/'run/manifest.json');p=load(original/'configs/protocol.json')
        for name,h in src['files'].items():
            for root in [original,user/'kit_source',user/'run/code_snapshot']:check(sha(root/name)==h,'source mismatch '+name)
        check(m['source_hashes']==src['files'] and m['source_manifest_sha256']==sha(original/'SOURCE_MANIFEST.json'),'source binding')
        check(strict_equal(m['protocol'],p) and m['protocol_sha256']==digest(p),'protocol binding')
        check(m['fingerprint']==digest({k:m[k] for k in ['protocol_sha256','source_manifest_sha256']}),'run fingerprint')
        check(load(user/'run/status.json')['state']=='completed','incomplete run')
        print('Verified archive and sources',flush=True)
        models,cal,costs,selections=verify_calibration(user/'run',ref/'run',p,out);print('Verified calibration',cal,flush=True)
        cases,tasks,streams,tr,verification=verify_trajectories(user/'run',ref/'run',p,models,out);print('Verified execution',verification,flush=True)
        aggregate,paired,effects=scientific_summaries(user/'run',p,models,cases,tasks,streams,tr,out)
        check(strict_equal(load(user/'run/audit/reference_validation.json'),load(original/'reference/science.json')),'reference predictions not exactly matching')
        zero=load(user/'run/execution_summary.json');save(out/'user_execution_metadata.json',{'manifest_environment':m['environment'],'execution':zero})
        report={'pass':True,'protocol':p['id'],'input_hashes':inputs,'bundle_entries':nfiles,'registered_source_files':len(src['files']),'calibration':cal,'runtime':verification,'summary_rows':80,'paired_rows':len(paired),'source_reference_prediction_object_equal':True,'new_llm_api_calls':0,'additional_independent_samples':0,'human_independent_review':False,'scope':'Independent arithmetic and verified-source replay are distinct; this report does not authenticate hardware or unpublished activity.'}
        save(out/'verification.json',report)
    check(inputs=={str(Path(p).name):sha(p) for p in (feedback,kit,reference)},'input modified')
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--feedback',required=True);parser.add_argument('--kit',required=True);parser.add_argument('--reference',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
    print(json.dumps(audit(args.feedback,args.kit,args.reference,args.out),ensure_ascii=False,indent=2))
