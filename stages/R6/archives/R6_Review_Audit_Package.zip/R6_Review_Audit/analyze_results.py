"""Additional descriptive diagnostics; no retraining, selection, or new samples."""
import argparse,csv,json,statistics
from pathlib import Path

def main(out):
 out=Path(out)
 def read(n):return list(csv.DictReader((out/n).open(encoding='utf-8')))
 cal=read('calibration_recomputed.csv')
 def mean(m,k):return statistics.mean(float(r[k]) for r in cal if r['method']==m)
 c={}
 for budget in (16,32):
  a,b=f'decision_{budget}',f'random_{budget}'
  c[str(budget)]={'selector_time_ratio':mean(a,'selector_seconds')/mean(b,'selector_seconds'),'acquisition_elapsed_ratio':mean(a,'acquisition_elapsed_seconds')/mean(b,'acquisition_elapsed_seconds'),'standalone_with_design_ratio':mean(a,'standalone_with_design_seconds')/mean(b,'standalone_with_design_seconds'),'mean_actual_tool_calls_decision':mean(a,'tool_calls'),'mean_actual_tool_calls_random':mean(b,'tool_calls')}
 c['decision32_vs_full']={'acquisition_elapsed_ratio':mean('decision_32','acquisition_elapsed_seconds')/mean('full_joint','acquisition_elapsed_seconds'),'standalone_with_design_ratio':mean('decision_32','standalone_with_design_seconds')/mean('full_joint','standalone_with_design_seconds')}
 sel=read('selection_effects.csv')
 c['posthoc_model_updates']={m:{'purchased_atoms':len(a:=[r for r in sel if r['learner']==m]),'observed_mean_equals_prediction':sum(int(r['no_model_update']) for r in a),'sum_absolute_updates':sum(float(r['absolute_update']) for r in a)} for m in ('random','occupancy','decision')}
 eff=read('treatment_effects.csv');rs=[r for r in eff if r['left']=='decision_32' and r['right']=='random_32'];nz=[r for r in rs if int(r['cost_units_delta'])]
 c['decision32_vs_random32']={'paired_menu_episodes':len(rs),'different_cost_menu_episodes':len(nz),'different_cost_base_streams':sorted({int(r['stream']) for r in nz}),'fitted_panels_with_nonzero_differences':sorted({int(r['panel']) for r in nz}),'rows':nz}
 c['scope']='Descriptive after-audit diagnostics. Changed a loss table does not imply better decisions; zero mean update does not prove a query had zero epistemic value.'
 (out/'additional_diagnostics.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('out');main(p.parse_args().out)
