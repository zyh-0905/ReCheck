# R6审核复现
本包是只读审核材料，不是新的实验任务包，不调用LLM，也不增加独立样本。用户当前无需再次运行。

## 独立评测与统计复算
使用Python 3.11+与numpy==2.3.5，原始三个输入包来自本对话，不包含密钥。

```bash
python -m unittest test_independent -v
python audit_r6.py --feedback /path/dc1eed59-6e1c-4ee7-ac48-6ea211b1bcdc.zip --kit /path/Research_Handoff_R6.zip --reference /path/R6_Offline_Results.zip --out /path/new_review_output
python analyze_results.py /path/new_review_output
```

out必须是新目录，拒绝覆盖。脚本安全解压到临时目录、校验输入源码后独立重算；不修改三个原ZIP。原始文件哈希、离散科学内容、特定概率数值等价分别检查。

## 原算法全链路重建（本次已完成）
results/original_source_replay.json和logs/original_replay_clean2.txt记录原学习器/规划器的另一路审核。
需要复现这一路时，将原运行包的run目录**复制**到新解压原执行包的runs/R6_offline，再在该复制包运行原r6.py audit。不要在用户原始实验目录操作。也可使用replay_original.py <copied-kit-root> <new-result-json>；该启动器按虚拟环境位置查找依赖，禁用网络，并增加阶段计时。

日志保留首次200秒超时和一次清洁启动的依赖路径错误，成功重建没有更改学习方法或实验结果。这些审核过程耗时不能当用户设备性能。原工具60项、新评测器33项均通过；最终解压复验记录单列。

## 数据边界
reference-science的复现不是新增测试集。diagnostic score的末位容差不会放宽条目选择、预算或答案比较。新增模型更新计数与差异集中度是事后诊断，不构成独立确认性研究。

完整报告见R6_Review_Report_ZH.md。来源与比对SHA见results/verification.json。
