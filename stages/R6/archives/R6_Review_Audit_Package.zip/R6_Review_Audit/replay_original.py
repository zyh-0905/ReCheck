"""Re-evaluate a verified copy. No remote calls; raw inputs never modified."""
import sys,sysconfig,time,json
from pathlib import Path
sys.path.append(str(Path(sys.executable).parent.parent/'lib'/f'python{sys.version_info.major}.{sys.version_info.minor}'/'site-packages'))
sys.path.extend([sysconfig.get_paths()['purelib'],sysconfig.get_paths()['platlib']])
root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from r6lib import storage,review
old=review.check_ledger

def check(*a,**kw):
 t=time.perf_counter();v=old(*a,**kw);print('ledger',a[1],a[0]['method'],round(time.perf_counter()-t,3),flush=True);return v
review.check_ledger=check
with storage.no_network():
 t=time.perf_counter();r=review.audit(root)
print(json.dumps({'elapsed_seconds':time.perf_counter()-t,'report':r},indent=2),flush=True)
Path(sys.argv[2]).write_text(json.dumps({'elapsed_seconds':time.perf_counter()-t,'report':r},indent=2))
raise SystemExit(0 if r['mechanical_pass'] else 2)
