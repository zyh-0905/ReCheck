"""Independent audit arithmetic and comparisons; imports no study implementation.
This module never mutates user records, executes user code, or contacts a network.
"""
import copy,math
RELEVANT=((0,1),(2,),(0,1,2),(0,1,2),(0,1,2))

def bits(mode):
    if type(mode) is not int or not 0<=mode<8:raise ValueError('mode must be int in [0,7]')
    return tuple(int(bool(mode & (1<<j))) for j in range(3))

def gold(rows,task):
    free=lambda r:max(0,r['physical']-r['reserved'])
    if task['type']==1:
        lookup={r['sku']:r for r in rows}
        return {'available_total':sum(free(lookup[s]) for s in task['skus'])}
    chosen=[r for r in rows if r['active'] and r['category']==task['category']]
    if task['type']==2:chosen=[r for r in chosen if free(r)>=task['minimum']]
    return {'skus':sorted(r['sku'] for r in chosen)}

def expected(rows,task,memory,current):
    """Recreate every bounded catalog/inventory API result with a separate implementation."""
    mb,zb=bits(memory),bits(current);trace=[];lookup={r['sku']:r for r in rows}
    def inventory(skus):
        if any(s not in lookup for s in skus):out={'error':'UNKNOWN_SKU'}
        else:out={'items':[{'sku':s,'stock_value':lookup[s]['physical'] if zb[2] else max(0,lookup[s]['physical']-lookup[s]['reserved']),'reserved':lookup[s]['reserved']} for s in skus]}
        trace.append({'path':'/inventory/batch','args':{'skus':list(skus)},'result':out})
        return out
    def value(row):return max(0,row['stock_value']- (row['reserved'] if mb[2] else 0))
    if task['type']==1:
        out=inventory(task['skus'])
        if 'error' in out:return out,trace
        return {'available_total':sum(value(r) for r in out['items'])},trace
    active_wanted=(mb[1]==zb[1]);subset=[r for r in rows if r['active']==active_wanted];allrows=[]
    for page in range(mb[0],mb[0]+64):
        args={'page':page,'page_size':3,'status_code':1-mb[1]}
        offset=page-zb[0]
        if offset<0:out={'error':'PAGE_BEFORE_FIRST'}
        else:out={'items':[{'sku':r['sku'],'category':r['category']} for r in subset[3*offset:3*(offset+1)]],'has_more':3*(offset+1)<len(subset)}
        trace.append({'path':'/catalog/items','args':args,'result':out})
        if 'error' in out:return out,trace
        allrows.extend(out['items'])
        if not out['has_more']:break
    else:return {'error':'PAGE_LIMIT'},trace
    chosen=[r for r in allrows if r['category']==task['category']]
    if task['type']==2:
        out=inventory([r['sku'] for r in chosen])
        if 'error' in out:return out,trace
        chosen=[r for r in out['items'] if value(r)>=task['minimum']]
    return {'skus':sorted(r['sku'] for r in chosen)},trace

def strict_equal(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b) and all(strict_equal(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(strict_equal(x,y) for x,y in zip(a,b))
    if isinstance(a,float):return math.isfinite(a) and math.isfinite(b) and a==b
    return a==b

def compare_trajectory(a,b):
    ignore_root={'execution_seconds','planner_setup_seconds','cache_info'}
    ignore_rec={'planning_seconds','probe_seconds','tool_seconds'}
    def strip(x):
        y={k:copy.deepcopy(v) for k,v in x.items() if k not in ignore_root}
        y['records']=[{k:v for k,v in r.items() if k not in ignore_rec} for r in y.get('records',[])]
        return y
    a,b=strip(a),strip(b);issues=[];deltas=[]
    def walk(x,y,path=()):
        if len(path)==3 and path[0]=='records' and type(path[1]) is int and path[2]=='predicted_task_error_after_receipts':
            if any(type(t) is not float or not math.isfinite(t) or not 0<=t<=1 for t in (x,y)):
                issues.append([list(path),'invalid probability']);return
            d=abs(x-y)
            if d>1e-14:issues.append([list(path),'probability deviation'])
            if d:deltas.append(d)
            return
        if type(x) is not type(y):issues.append([list(path),'type']);return
        if isinstance(x,dict):
            if set(x)!=set(y):issues.append([list(path),'keys']);return
            for k in x:walk(x[k],y[k],path+(k,))
        elif isinstance(x,list):
            if len(x)!=len(y):issues.append([list(path),'length']);return
            for i,(xx,yy) in enumerate(zip(x,y)):walk(xx,yy,path+(i,))
        elif not strict_equal(x,y):issues.append([list(path),'value'])
    walk(a,b)
    return {'pass':not issues,'issues':issues,'probabilities_different':len(deltas),'max_probability_delta':max(deltas,default=0.)}

def canonical_cell(q,m,z):
    if type(q) is not int or not 0<=q<5:raise ValueError('task type')
    bits(m);bits(z);mask=sum(1<<j for j in RELEVANT[q]);return q,m&mask,z&mask

def cost_units(failures,credits):
    if any(type(x) is not int or x<0 for x in (failures,credits)):raise ValueError('nonnegative integers')
    return 20*failures+credits

def predicted(table,q,memory,ages,hazards):
    bits(memory)
    if len(ages)!=3 or len(hazards)!=3 or any(type(a) is not int or a<0 for a in ages) or any(not math.isfinite(h) or not 0<=h<=.5 for h in hazards):raise ValueError('belief inputs')
    p=[(1-(1-2*h)**age)/2 for h,age in zip(hazards,ages)]
    return math.fsum(math.prod(p[j] if ((memory^z)>>j)&1 else 1-p[j] for j in range(3))*table[q][memory][z] for z in range(8))

def all_cells():return sorted({canonical_cell(q,m,z) for q in range(5) for m in range(8) for z in range(8)}- {canonical_cell(q,m,m) for q in range(5) for m in range(8)})
def single_cells():return [c for c in all_cells() if (c[1]^c[2]).bit_count()==1]
def purchased_table(observed):
    cells={tuple(map(int,k.split(':'))):v for k,v in observed.items()}
    if not set(single_cells())<=set(cells):raise ValueError('missing single-cell observations')
    def get(q,m,z):
        q,m,z=canonical_cell(q,m,z)
        if m==z:return 0.
        if (q,m,z) in cells:return cells[q,m,z]['mean']
        return 1-math.prod(1-cells[q,m,m^(1<<j)]['mean'] for j in RELEVANT[q] if (m^z)&(1<<j))
    return [[[get(q,m,z) for z in range(8)] for m in range(8)] for q in range(5)]
