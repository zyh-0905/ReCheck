import unittest,copy,math
from independent import *

def rows():
    return [dict(sku=f'S{i}',physical=v,reserved=r,category=c,active=a)
            for i,(v,r,c,a) in enumerate([(10,4,'A',True),(5,2,'B',True),(1,4,'A',True),(15,0,'A',True),(8,1,'C',False),(20,4,'A',False)])]
def task(t=0,cat='A',minimum=1):
    return dict(type=t,category=cat,minimum=minimum,skus=['S0','S2'])
def sample():
    return {'memory':1,'execution_seconds':1.,'records':[{'credits':2,'answer':{'skus':['S0']},'predicted_task_error_after_receipts':.25,'planning_seconds':.1}]}

class Arithmetic(unittest.TestCase):
    def test_bits(self):self.assertEqual(bits(5),(1,0,1))
    def test_bits_reject_bool(self):
        with self.assertRaises(ValueError):bits(True)
    def test_mode_out_of_range(self):
        with self.assertRaises(ValueError):bits(8)
    def test_active_catalog(self):self.assertEqual(expected(rows(),task(),0,0)[0],{'skus':['S0','S2','S3']})
    def test_wrong_page_rejected(self):self.assertEqual(expected(rows(),task(),0,1)[0],{'error':'PAGE_BEFORE_FIRST'})
    def test_skip_page(self):self.assertEqual(expected(rows(),task(),1,0)[0],{'skus':['S3']})
    def test_skip_irrelevant_page_same_final(self):
        r=rows();r[0]['category']=r[1]['category']=r[2]['category']='B'
        self.assertEqual(expected(r,task(),1,0)[0],gold(r,task()))
        self.assertNotEqual(expected(r,task(),1,0)[1],expected(r,task(),0,0)[1])
    def test_opposite_active(self):self.assertEqual(expected(rows(),task(),2,0)[0],{'skus':['S5']})
    def test_stock_gross(self):self.assertEqual(expected(rows(),task(1),4,4)[0],{'available_total':6})
    def test_stock_net(self):self.assertEqual(expected(rows(),task(1),0,0)[0],{'available_total':6})
    def test_wrong_gross_clamps(self):self.assertEqual(expected(rows(),task(1),4,0)[0],{'available_total':2})
    def test_wrong_net(self):self.assertEqual(expected(rows(),task(1),0,4)[0],{'available_total':11})
    def test_inventory_filter(self):self.assertEqual(expected(rows(),task(2,minimum=7),0,0)[0],{'skus':['S3']})
    def test_gold_independent(self):self.assertEqual(gold(rows(),task(2,minimum=7)),{'skus':['S3']})
    def test_pagination_trace_count(self):self.assertEqual(len(expected(rows(),task(),0,0)[1]),2)
    def test_canonical_public_irrelevance(self):self.assertEqual(canonical_cell(1,7,3),(1,4,0))
    def test_integer_cost(self):self.assertEqual(cost_units(3,8),68)
    def test_reject_bool_cost(self):
        with self.assertRaises(ValueError):cost_units(True,8)
    def test_fresh_prediction(self):
        table=[[[float(m!=z) for z in range(8)] for m in range(8)] for q in range(5)]
        self.assertEqual(predicted(table,0,2,[0,0,0],[.12]*3),0.)
    def test_one_uncertain_bit(self):
        table=[[[float((m^z)&1!=0) for z in range(8)] for m in range(8)] for q in range(5)]
        self.assertAlmostEqual(predicted(table,0,0,[1,0,0],[.12]*3),.12)
class Numeric(unittest.TestCase):
    def test_strict_types(self):self.assertFalse(strict_equal({'n':1},{'n':True}))
    def test_strict_nan(self):self.assertFalse(strict_equal(float('nan'),float('nan')))
    def test_trace_equal(self):self.assertTrue(compare_trajectory(sample(),sample())['pass'])
    def test_allowed_ulp(self):
        a=sample();b=copy.deepcopy(a);b['records'][0]['predicted_task_error_after_receipts']+=1e-16
        self.assertTrue(compare_trajectory(a,b)['pass'])
    def test_wrong_answer(self):
        a=sample();b=copy.deepcopy(a);b['records'][0]['answer']['skus']=[]
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_wrong_budget(self):
        a=sample();b=copy.deepcopy(a);b['records'][0]['credits']=True
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_nonscoped_float(self):
        a=sample();b=copy.deepcopy(a);a['extra']=.25;b['extra']=.25+1e-16
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_nan_prediction(self):
        a=sample();b=copy.deepcopy(a);b['records'][0]['predicted_task_error_after_receipts']=float('nan')
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_prediction_not_int(self):
        a=sample();b=copy.deepcopy(a);a['records'][0]['predicted_task_error_after_receipts']=0.;b['records'][0]['predicted_task_error_after_receipts']=0
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_excess_tolerance(self):
        a=sample();b=copy.deepcopy(a);b['records'][0]['predicted_task_error_after_receipts']+=1e-10
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_only_declared_timing_ignored(self):
        a=sample();b=copy.deepcopy(a);b['execution_seconds']=3.;b['records'][0]['planning_seconds']=2.
        self.assertTrue(compare_trajectory(a,b)['pass'])
    def test_missing_record(self):
        a=sample();b=copy.deepcopy(a);b['records']=[]
        self.assertFalse(compare_trajectory(a,b)['pass'])
    def test_incomplete_purchase_table_rejected(self):
        with self.assertRaises(ValueError):purchased_table({})
if __name__=='__main__':unittest.main()
