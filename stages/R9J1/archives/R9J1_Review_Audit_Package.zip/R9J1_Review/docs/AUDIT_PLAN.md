# R9J1 retained-response audit plan

This is an offline evidence audit of the one received smoke and one paused main request, not a new model trial.

- Verify outer and inner ZIP safety, exact manifest and original source; retain original input.
- Reconstruct request configuration, top-level JSON format, wire serialization using loopback only.
- Independently validate usage and parse result; compare raw text against README excerpt without executing parsed fragments.
- Restore pinned runtime from previously verified public materials; replay native initial snapshot and original pause; run original tests.
- Preserve interrupted original protocol as-is; no best-of selection, partial response recovery, retries, or new paid batch.
- Document independent checks and unverified provider internals. No publication-performance claim.
