"""Reconstruct original native first-turn boundary; capture one loopback wire request only."""
from pathlib import Path
import sys,json,socket,shutil,tempfile,threading,urllib.request
from http.server import BaseHTTPRequestHandler,HTTPServer
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'inputs/original_kit/R9J1_Research_Kit';F=ROOT/'inputs/feedback'
sys.path[:0]=[str(ROOT/'runtime/deps'),str(ROOT/'runtime/sdist/rouge_score-0.1.2'),str(O),str(O/'vendor/toolsandbox')]
original_connect=socket.socket.connect;original_connect_ex=socket.socket.connect_ex
attempted_remote=[]
def safe(self,address):
 if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1'):return original_connect(self,address)
 attempted_remote.append(str(address));raise RuntimeError('Only loopback allowed for software wire capture')
def safe_ex(self,address):
 if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1'):return original_connect_ex(self,address)
 attempted_remote.append(str(address));raise RuntimeError('Only loopback allowed')
socket.socket.connect=safe;socket.socket.connect_ex=safe_ex
from pilot.common import read_json as j,request_payload,digest,canonical
from r9lib.prompts import initial_messages,episode_schedule
from r9lib.timeline import Timeline
from r9lib.transport import Client
from pilot.client import RunStopped,NoRedirect
from r9lib.audit import audit
from r9lib.runtime import can_start
from r9lib.identity import response_identity
spec=episode_schedule()[0];assert spec['episode_id']=='primary_n06_verify_confirm'
case=next(c for c in j(O/'fixtures/cases.json') if c['id']==spec['case_id']);t=Timeline(case)
b=j(F/'runs/R9_main/partial'/spec['episode_id']/'boundary.json')
assert b['world']==t.world() and b['snapshot']==t.snapshot() and b['exposure']==t.exposure()
assert b['turns']==[] and b['events']==[]
msgs=initial_messages(case['public'],spec['arm']);assert msgs==b['messages']
prep=j(F/'PREPARED.json');main=j(F/'runs/R9_main/attempts/000001_result.json');smoke=j(F/'runs/R9_smoke/attempts/000001_result.json')
assert main['payload']==request_payload(prep['config'],msgs)
smoke_msgs=[{'role':'system','content':'Return exactly one JSON object: {"done":"ready"}.'},{'role':'user','content':'Check the JSON-only interface.'}]
assert smoke['payload']==request_payload(prep['config'],smoke_msgs)
assert 'response_format' in main['payload'] and 'extra_body' not in main['payload']
with tempfile.TemporaryDirectory() as td:
 tmp=Path(td);d=tmp/'validation';d.mkdir();shutil.copy(F/'runs/R9_main/endpoint_identity.json',d/'endpoint_identity.json')
 c=Client(prep['config'],d)
 try:c._validate_saved(main)
 except RunStopped as e:original_error=str(e)
 else:raise AssertionError('Original validator must reject actual invalid document')
 assert original_error=='Invalid JSON response preserved. Paused, not automatically repaired.'
 assert not list((d/'attempts').glob('*_start.json'))
 copied=tmp/'reconstructed';shutil.copytree(O,copied,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 shutil.copytree(F/'runs',copied/'runs');shutil.copy(F/'PREPARED.json',copied/'PREPARED.json')
 rep=audit(copied);assert rep==j(F/'offline_reports/AUDIT.json')
 assert (copied/'offline_reports/calls.csv').read_bytes()==(F/'offline_reports/calls.csv').read_bytes()
 try:can_start(copied,'R9_main')
 except ValueError as e:refusal=str(e)
 else:raise AssertionError('Paused run admitted')
 # Capture the exact generated wire bytes, not merely a copy of logged extra_body.
 captured=[]
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_POST(self):
   body=self.rfile.read(int(self.headers['Content-Length']));captured.append({'path':self.path,'wire_sha256':__import__('hashlib').sha256(body).hexdigest(),'payload':json.loads(body),'had_authorization':bool(self.headers.get('Authorization'))})
   response=json.dumps(main['response']).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(response)));self.end_headers();self.wfile.write(response)
 server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 cfg=dict(prep['config']);cfg.update(base_url=f'http://127.0.0.1:{server.server_port}/v1',min_interval_seconds=0)
 # Preserve live identity-label checks for the exact saved response; only transport goes to loopback.
 # This internal audit config is never a paid CLI profile and has no key.
 try:
  cc=Client(cfg,tmp/'wire',secret='',cap=1);cc.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
  try:cc.complete(main['logical_id'],msgs,meta=main['metadata'])
  except RunStopped as e:wire_error=str(e)
  else:raise AssertionError('Replayed invalid wire response admitted')
  assert len(captured)==1 and captured[0]['payload']==main['payload']
  assert captured[0]['path']=='/v1/chat/completions' and not captured[0]['had_authorization']
  assert captured[0]['payload']['response_format']=={'type':'json_object'}
  assert wire_error==original_error
 finally:server.shutdown();thread.join();server.server_close()
 assert attempted_remote==[]
 res={'native_snapshot_and_world_equal':True,'initial_cellular_true':t.world()['setting'][0]['cellular'],
      'initial_query_history_and_prompts_equal':True,'reconstructed_smoke_and_partial_requests':2,'original_validator_rejection':original_error,'original_auto_audit_equal':True,'original_calls_csv_equal':True,'paused_restart_refusal':refusal,'agent_tools_executed_in_recorded_trial':0,'environment_events_in_recorded_trial':len(t.events),'wire_capture':{'evidence_kind':'SOFTWARE_TEST_NOT_NEW_LLM_RESPONSE','loopback_requests':1,'payload_equal_to_actual_record':True,'response_format_top_level':True,'extra_body_not_sent_as_nested_key':True,'body_sha256':captured[0]['wire_sha256'],'full_response_rejected':True},'new_remote_model_calls':0,'attempted_remote_network_connections':0,'paid_key_required':False}
 (ROOT/'results/native_audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
