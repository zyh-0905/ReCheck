"""Read-only audit of two received R9J1 responses. Does not execute fragments or call models."""
from pathlib import Path,PurePosixPath
import csv,json,hashlib,math,re,sys,zipfile,socket,stat
from evidence_checks import digest,canonical,strict_document,usage_counts,assert_payload,lexical_fragments,compare_excerpt
ROOT=Path(__file__).resolve().parents[1];F=ROOT/'inputs/feedback';O=ROOT/'inputs/original_kit/R9J1_Research_Kit';OUT=ROOT/'results'
def j(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
 OUT.mkdir(exist_ok=True)
 with zipfile.ZipFile(ROOT/'inputs/submitted_outer.zip') as z:
  ns=z.namelist();assert len(ns)==len(set(ns))
  for i in z.infolist():
   p=PurePosixPath(i.filename)
   assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16)
  raw={n:z.read(n) for n in ns if not n.startswith('__MACOSX/') and not n.endswith('/')}
 m=j(F/'BUNDLE_MANIFEST.json');names={p.relative_to(F).as_posix() for p in F.rglob('*') if p.is_file()}
 assert names==set(m['sha256'])|{'BUNDLE_MANIFEST.json'}
 for n,h in m['sha256'].items():assert sha(F/n)==h,n
 s=j(O/'SOURCE_MANIFEST.json')['sha256']
 for n,h in s.items():assert sha(O/n)==h and sha(F/'kit_source'/n)==h,n
 assert (F/'kit_source/SOURCE_MANIFEST.json').read_bytes()==(O/'SOURCE_MANIFEST.json').read_bytes()
 assert j(O/'UPSTREAM_MANIFEST.json')==j(F/'kit_source/UPSTREAM_MANIFEST.json')
 up=j(O/'UPSTREAM_MANIFEST.json')['sha256'];assert len(up)==77
 for n,h in up.items():assert s['vendor/toolsandbox/'+n]==h
 prep=j(F/'PREPARED.json');assert prep['source']==s;assert prep['protocol']==j(O/'protocol.json')
 assert prep['config']==j(O/'config.example.json');assert prep['fingerprint']==digest({k:prep[k] for k in ['config','protocol','source']})
 rows=[]
 for name,cap in [('R9_smoke',1),('R9_main',360)]:
  d=F/'runs'/name;mm=j(d/'manifest.json');state=j(d/'status.json')
  for k in ['config','protocol','source']:assert mm[k]==prep[k]
  assert mm['prepared_fingerprint']==prep['fingerprint']
  starts=sorted((d/'attempts').glob('*_start.json'));ends=sorted((d/'attempts').glob('*_result.json'));sends=sorted((d/'attempts').glob('*_send_intent.json'));cache=sorted((d/'calls').glob('*.json'))
  assert len(starts)==len(ends)==len(sends)==len(cache)==1
  a=j(starts[0]);r=j(ends[0]);it=j(sends[0]);assert a['attempt']==1==it['attempt']
  assert a['logical_id']==it['logical_id'];assert not it['proves_remote_receipt']
  for k in a:assert canonical(a[k])==canonical(r[k]),k
  assert cache[0].name==digest(a['logical_id'])+'.json';assert cache[0].read_bytes()==ends[0].read_bytes()
  assert_payload(a['payload']);assert digest(a['payload'])==a['payload_sha256'];assert digest({'endpoint':prep['config']['base_url'],'payload':a['payload']})==a['request_sha256']
  assert r['status']=='ok';body=r['response'];assert len(body['choices'])==1
  msg=body['choices'][0]['message'];assert msg['role']=='assistant';assert msg['content']==r['text']
  assert not msg.get('tool_calls');assert body['choices'][0]['finish_reason']=='stop'
  assert type(r['latency_seconds']) in (int,float) and math.isfinite(r['latency_seconds']) and r['latency_seconds']>=0
  identity=j(d/'endpoint_identity.json')
  assert identity['requested_model']==a['payload']['model'];assert identity['returned_model']==body['model'];assert identity['system_fingerprint']==body['system_fingerprint']
  good=True;err=None
  try:strict_document(r['text'])
  except ValueError as e:good=False;err=str(e)
  row={'run':name,'logical_id':a['logical_id'],'state':state['status'],'response_id':body['id'],'requested_model':a['payload']['model'],'returned_model':body['model'],'system_fingerprint':body['system_fingerprint'],'json_output_parameter_present':True,'valid_single_json_object':good,'parse_error':err,'characters':len(r['text']),**usage_counts(body['usage']),'latency_seconds':r['latency_seconds'],'currency':'UNKNOWN'}
  rows.append(row)
 assert rows[0]['valid_single_json_object'] and not rows[1]['valid_single_json_object']
 assert rows[0]['response_id']!=rows[1]['response_id'];assert rows[0]['system_fingerprint']==rows[1]['system_fingerprint']
 smoke=j(F/'runs/R9_smoke/attempts/000001_result.json');assert strict_document(smoke['text'])=={'done':'ready'}
 ss=j(F/'runs/R9_smoke/smoke_result.json');assert ss['shape_ok'] and ss['json_ok'] and ss['request_sha256']==smoke['request_sha256']
 main=j(F/'runs/R9_main/attempts/000001_result.json');b=j(F/'runs/R9_main/partial/primary_n06_verify_confirm/boundary.json')
 assert b['turn']==0 and b['turns']==[] and b['events']==[] and b['logical_id']==main['logical_id']
 assert not list((F/'runs/R9_main/episodes').glob('*.json'));assert main['metadata']=={'episode_id':'primary_n06_verify_confirm','phase':'primary','turn':0}
 case=next(c for c in j(O/'fixtures/cases.json') if c['id']=='n06')
 assert case['family']=='phone' and case['variant']=='post_relevant'
 assert b['world']==case['world_before'];assert b['messages']==main['payload']['messages']
 assert b['exposure']=={'scheduled':True,'triggered':False,'missed_before_primary_write':False,'reason':'no_qualifying_read'}
 assert b['messages'][1]['content']==json.dumps(case['public'],ensure_ascii=False,sort_keys=True)
 assert case['world_before']['setting'][0]['cellular'] is True
 diag=lexical_fragments(main['text']);assert len(diag['objects'])==5
 assert [x['object'].get('tool','done') for x in diag['objects']]==['get_cellular_service_status','set_cellular_service_status','send_message_with_phone_number','search_messages','done']
 readme=(ROOT/'inputs/feedback_README_original.md').read_text()
 fenced=re.findall(r'```[^\n]*\n(.*?)\n```',readme,re.S)
 excerpt=next(x for x in fenced if 'Tool results: cellular service is off.' in x)
 ec=compare_excerpt(main['text'],excerpt);assert ec['matches_after_marker_to_blank_line'] and not ec['exact']
 mapping={'AUDIT.json':'offline_reports/AUDIT.json','calls.csv':'offline_reports/calls.csv','PREPARED.json':'PREPARED.json','smoke_status.json':'runs/R9_smoke/status.json','main_status.json':'runs/R9_main/status.json','smoke_endpoint_identity.json':'runs/R9_smoke/endpoint_identity.json','main_endpoint_identity.json':'runs/R9_main/endpoint_identity.json','smoke_result.json':'runs/R9_smoke/smoke_result.json'}
 for n,t in mapping.items():assert next(v for k,v in raw.items() if PurePosixPath(k).name==n)==(F/t).read_bytes()
 assert next(v for k,v in raw.items() if k.endswith('_boundary.json'))==(F/'runs/R9_main/partial/primary_n06_verify_confirm/boundary.json').read_bytes()
 assert next(v for k,v in raw.items() if PurePosixPath(k).name.startswith('000001_result_'))==(F/'runs/R9_main/attempts/000001_result.json').read_bytes()
 sums={k:sum(r[k] for r in rows) for k in ['prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','uncached_input_tokens','latency_seconds']}
 put('raw_response_analysis.json',{'verbatim_content':main['text'],'utf8_bytes':len(main['text'].encode()),'characters':len(main['text']),**diag,'readme_excerpt_comparison':ec,'native_cellular_state_before_any_tool':True,'unsupported_generated_status_statement':'Tool results: cellular service is off.','actual_tool_calls':0,'actual_environment_events':0,'internal_cause':'UNKNOWN; visible marker or invented observations do not identify the failing service component'})
 report={'input_sha256':sha(ROOT/'inputs/submitted_outer.zip'),'inner_sha256':sha(ROOT/'inputs/feedback_original.zip'),'original_package_sha256':sha(ROOT/'inputs/original_delivery.zip'),'bundle_data_files_verified':len(m['sha256']),'source_files_verified':len(s),'upstream_files_verified':len(up),'convenience_copies_verified':10,'received_responses':2,'smoke_state':rows[0]['state'],'main_state':rows[1]['state'],'planned_primary':32,'completed_primary':0,'partial_primary':1,'unstarted_primary':31,'planned_repeat':4,'completed_repeat':0,'response_format_top_level':True,'main_json_contract_failure':True,'main_output_characters':len(main['text']),'control_marker_count':diag['marker_count'],'objects_lexically_described_not_executed':5,'native_tool_calls':0,'environment_events':0,'state_unchanged':True,'totals':sums,'main_wall_seconds':j(F/'runs/R9_main/status.json')['wall_seconds'],'provider_billing_and_weights_verified':False,'acceptance':'ACCEPT_RETAINED_CONTRACT_FAILURE_NOT_COMPLETE_RESEARCH','new_remote_model_calls':0}
 put('independent_audit.json',report)
 with (OUT/'call_ledger.csv').open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':
 def deny(*a,**k):raise RuntimeError('Offline evidence audit; networking denied')
 socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny
 main()
