"""Independent, standard-library-only diagnostic helpers; fragments are NEVER executed."""
import hashlib,json,math
MARKER='<｜end▁of▁thinking｜>'
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def strict_document(text):
 if type(text) is not str:raise ValueError('text required')
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError('duplicate JSON key')
   d[k]=v
  return d
 def bad(x):raise ValueError('nonfinite JSON constant')
 o=json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
 if type(o) is not dict:raise ValueError('single object required')
 canonical(o)
 return o

def _count(x):
 if type(x) is not int or x<0:raise ValueError('nonnegative integer required')
 return x

def usage_counts(u):
 if type(u) is not dict:raise ValueError('usage required')
 p,c,t=[_count(u.get(k)) for k in ('prompt_tokens','completion_tokens','total_tokens')]
 if p+c!=t:raise ValueError('token total mismatch')
 cached=_count(u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0)))
 other=(u.get('prompt_tokens_details') or {}).get('cached_tokens')
 if other is not None and _count(other)!=cached:raise ValueError('cache representations disagree')
 reasoning=_count((u.get('completion_tokens_details') or {}).get('reasoning_tokens',0))
 miss=_count(u.get('prompt_cache_miss_tokens',p-cached))
 if cached>p or cached+miss!=p or reasoning>c:raise ValueError('token component mismatch')
 return dict(prompt_tokens=p,completion_tokens=c,total_tokens=t,reasoning_tokens=reasoning,cached_input_tokens=cached,uncached_input_tokens=miss)

def assert_payload(p):
 expected={'model','messages','stream','max_tokens','thinking','reasoning_effort','response_format'}
 if type(p) is not dict or set(p)!=expected:raise ValueError('unexpected payload fields')
 for k,v in {'model':'deepseek-v4-flash','stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high','response_format':{'type':'json_object'}}.items():
  if canonical(p[k])!=canonical(v):raise ValueError('payload constraint '+k)
 if type(p['messages']) is not list or len(p['messages'])!=2:raise ValueError('expected first-turn request')
 if [m.get('role') for m in p['messages']]!=['system','user']:raise ValueError('unexpected role history')
 if any(type(m.get('content')) is not str for m in p['messages']):raise ValueError('text messages required')
 return True

def lexical_fragments(text):
 """Lexical description only. Finding JSON fragments NEVER makes an invalid response executable."""
 dec=json.JSONDecoder();objects=[];outside=[];start=0;i=0
 while i<len(text):
  j=text.find('{',i)
  if j<0:break
  try:o,n=dec.raw_decode(text[j:])
  except json.JSONDecodeError:i=j+1;continue
  if type(o) is not dict:i=j+1;continue
  if j>start:outside.append({'start':start,'end':j,'text':text[start:j]})
  objects.append({'start':j,'end':j+n,'object':o});i=j+n;start=i
 if start<len(text):outside.append({'start':start,'end':len(text),'text':text[start:]})
 return {'objects':objects,'outside_segments':outside,'executed_objects':0,'marker_count':text.count(MARKER)}

def compare_excerpt(raw,excerpt):
 return {'exact':raw==excerpt,'matches_after_removing_marker':raw.replace(MARKER,'')==excerpt,
         'matches_after_marker_to_blank_line':raw.replace(MARKER,'\n\n')==excerpt,
         'raw_characters':len(raw),'excerpt_characters':len(excerpt),'removed_characters':len(raw)-len(raw.replace(MARKER,''))}
