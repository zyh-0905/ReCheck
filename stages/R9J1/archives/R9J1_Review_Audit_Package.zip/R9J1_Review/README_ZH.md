# R9J1只读审计附件

不是付费执行包；没有新的模型请求脚本、重跑授权或密钥需求。

## 文件
- R9J1_Review_Report_ZH.md：主审查报告。
- inputs/feedback_original.zip与inputs/feedback/：原内层反馈及原样提取件。
- inputs/submitted_outer.zip：原用户上传件，含便利副本与未改写README。
- inputs/original_delivery.zip及inputs/original_kit：最初冻结R9J1运行器。
- results/：完整性、词法诊断、成本、版本沿革与原生审核结果。
- scripts/：仅用于离线复核的脚本；片段扫描不执行模型输出。
- tests/：独立标准库审核辅助负例。
- provider_case/：便于服务方诊断的保留请求和响应，无鉴权信息，不自动发送。
- logs/：真实执行历史，含审核器自身初始错误和修正记录。

## 复核（研究端已执行，用户无需复跑）

标准库部分：
```bash
python -m unittest discover -s tests -v
python scripts/audit_received.py
```

原生复核需要此前回传的Linux CPython3.11与固定依赖。本包不重复包含约百MB二进制。scripts/restore_runtime.py只从已验证材料ZIP恢复，不联网；脚本内默认路径为研究容器路径，可据本地实际位置调整。还原后：
```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 POLARS_MAX_THREADS=1 runtime/python/bin/python3.11 -S scripts/native_audit.py
```

原版软件测试可用scripts/run_local.py启动，只允许loopback。原生审核会创建临时复制件，使用已存响应重建和捕获本地HTTP请求；不读取模型密钥，不访问远端服务。测试响应不得计入论文样本。

输入ZIP和源码不能修改成匹配审核；错误或版本不符应保留并报告。专用JSON片段分析是只读诊断，不能用来从失败输出中挑取一个“好动作”。
