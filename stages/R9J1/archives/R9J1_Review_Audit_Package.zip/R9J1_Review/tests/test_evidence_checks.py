import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from evidence_checks import strict_document, usage_counts, lexical_fragments, assert_payload, compare_excerpt

class DocumentTests(unittest.TestCase):
 def test_single(self): self.assertEqual(strict_document('{"done":"ready"}'),{'done':'ready'})
 def test_multiple(self):
  with self.assertRaises(ValueError):strict_document('{"x":1}\n{"y":2}')
 def test_prose(self):
  with self.assertRaises(ValueError):strict_document('{"x":1}\nTool results: success')
 def test_array(self):
  with self.assertRaises(ValueError):strict_document('[{"x":1}]')
 def test_duplicate(self):
  with self.assertRaises(ValueError):strict_document('{"x":1,"x":2}')
 def test_nan(self):
  with self.assertRaises(ValueError):strict_document('{"x":NaN}')
 def test_overflow(self):
  with self.assertRaises(ValueError):strict_document('{"x":1e999}')
 def test_fence(self):
  with self.assertRaises(ValueError):strict_document('```json\n{}\n```')
 def test_nested_duplicate(self):
  with self.assertRaises(ValueError):strict_document('{"x":{"v":1,"v":2}}')
 def test_marker_not_stripped(self):
  with self.assertRaises(ValueError):strict_document('{"x":1}<｜end▁of▁thinking｜>')

class UsageTests(unittest.TestCase):
 def setUp(self):self.u={'prompt_tokens':70,'completion_tokens':47,'total_tokens':117,'prompt_cache_hit_tokens':0,'prompt_cache_miss_tokens':70,'prompt_tokens_details':{'cached_tokens':0},'completion_tokens_details':{'reasoning_tokens':41}}
 def test_ok(self):self.assertEqual(usage_counts(self.u),{'prompt_tokens':70,'completion_tokens':47,'total_tokens':117,'reasoning_tokens':41,'cached_input_tokens':0,'uncached_input_tokens':70})
 def test_bool(self):
  self.u['prompt_tokens']=True
  with self.assertRaises(ValueError):usage_counts(self.u)
 def test_missing(self):
  del self.u['completion_tokens']
  with self.assertRaises(ValueError):usage_counts(self.u)
 def test_bad_sum(self):
  self.u['total_tokens']=118
  with self.assertRaises(ValueError):usage_counts(self.u)
 def test_bad_cache(self):
  self.u['prompt_tokens_details']['cached_tokens']=1
  with self.assertRaises(ValueError):usage_counts(self.u)
 def test_bad_reasoning(self):
  self.u['completion_tokens_details']['reasoning_tokens']=48
  with self.assertRaises(ValueError):usage_counts(self.u)
 def test_negative(self):
  self.u['prompt_cache_hit_tokens']=-1
  with self.assertRaises(ValueError):usage_counts(self.u)

class PayloadTests(unittest.TestCase):
 def setUp(self):self.p={'model':'deepseek-v4-flash','messages':[{'role':'system','content':'Return JSON: {"done":"ready"}'},{'role':'user','content':'Check'}],'stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high','response_format':{'type':'json_object'}}
 def test_ok(self):self.assertIs(assert_payload(self.p),True)
 def test_nested(self):
  self.p['extra_body']={'response_format':self.p.pop('response_format')}
  with self.assertRaises(ValueError):assert_payload(self.p)
 def test_no_mode(self):
  self.p.pop('response_format')
  with self.assertRaises(ValueError):assert_payload(self.p)
 def test_altered_cap(self):
  self.p['max_tokens']=16385
  with self.assertRaises(ValueError):assert_payload(self.p)
 def test_tools_not_implicitly_present(self):
  self.p['tools']=[]
  with self.assertRaises(ValueError):assert_payload(self.p)

class FragmentTests(unittest.TestCase):
 def test_nested_not_double_counted(self):
  t='{"tool":"a","arguments":{"x":{"a":1}}}\nTool results: yes\n{"done":"ok"}'
  r=lexical_fragments(t);self.assertEqual(len(r['objects']),2);self.assertEqual(r['executed_objects'],0);self.assertEqual(r['outside_segments'][0]['text'],'\nTool results: yes\n')
 def test_raw_marker_preserved(self):
  t='{"x":1}<｜end▁of▁thinking｜>{"y":2}'
  r=lexical_fragments(t);self.assertEqual(r['marker_count'],1);self.assertIn('<｜end▁of▁thinking｜>',r['outside_segments'][0]['text'])
 def test_original_response(self):
  p=ROOT/'inputs/feedback/runs/R9_main/attempts/000001_result.json';t=json.loads(p.read_text())['text'];r=lexical_fragments(t)
  self.assertEqual(len(r['objects']),5);self.assertEqual(r['marker_count'],3);self.assertEqual(r['executed_objects'],0);self.assertEqual(len(t),1407)
 def test_excerpt_not_exact(self):
  x='a<｜end▁of▁thinking｜>b';r=compare_excerpt(x,'ab');self.assertFalse(r['exact']);self.assertTrue(r['matches_after_removing_marker']);self.assertEqual(r['removed_characters'],19)
 def test_markers_replaced_by_blank_line(self):
  r=compare_excerpt('a<｜end▁of▁thinking｜>b','a\n\nb');self.assertTrue(r.get('matches_after_marker_to_blank_line',False));self.assertFalse(r['exact'])
 def test_excerpt_exact(self):self.assertTrue(compare_excerpt('{}','{}')['exact'])
 def test_prose_alteration_not_excused(self):self.assertFalse(compare_excerpt('x<｜end▁of▁thinking｜>','y')['matches_after_removing_marker'])

if __name__=='__main__':unittest.main()
