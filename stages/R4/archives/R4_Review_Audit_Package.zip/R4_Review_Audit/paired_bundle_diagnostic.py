#!/usr/bin/env python3
"""POST-HOC controlled paired rule-executor diagnostic. Zero LLM calls.
For every submitted stream, flip only packet availability. No selection by outcomes.
Not original R4 results, not a paid-model experiment, not a confirmatory dataset.
"""
import argparse,copy,hashlib,json,socket,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from audit_r4 import EXPECTED_REFERENCE,checked_zip,load,save,table,sha,METHODS
from independent_eval import truth,execute_reference,gold_reference,stale_channels

def run(feedback,reference,out):
    out.mkdir(parents=True,exist_ok=True)
    def no_net(*a,**k):raise RuntimeError('Offline paired diagnostic forbids networking')
    socket.socket.connect=no_net;socket.socket.connect_ex=no_net;socket.create_connection=no_net
    assert sha(reference)==EXPECTED_REFERENCE
    with tempfile.TemporaryDirectory(prefix='r4_paired_') as td:
        root=Path(td);outer=checked_zip(feedback)
        name=next(n for n in outer.namelist() if n.endswith('.zip') and not n.startswith('__MACOSX/'))
        import io
        z=checked_zip(io.BytesIO(outer.read(name)));z.extractall(root/'f');checked_zip(reference).extractall(root/'o')
        kit=root/'o/R4_Research_Kit';src=load(kit/'SOURCE_MANIFEST.json')['sha256']
        for rel,h in src.items():assert sha(kit/rel)==h==sha(root/'f/kit_source'/rel)
        sys.path.insert(0,str(kit));from r4lib import protocol
        from r4lib.model import Solver
        p=protocol.load_protocol();cases=load(root/'f/runs/R4_recheck/private/recheck_cases.json');assert cases==protocol.make_cases(p)
        details=[];by={}
        for cell,case in zip(p['streams'],cases):
            sid=case['stream']
            for overlap in (False,True):
                changed={**cell,'overlap':overlap};spec=protocol.spec(changed,p)
                for method in METHODS:
                    solver=Solver(spec);age=(1,1,1);budget=p['episode_budget'];memory=truth(case['initial_modes']);success=loss=cost=0
                    for t,task in enumerate(case['tasks']):
                        a=solver.choose(method,p['steps']-t,age,task['type'],budget)
                        for j in a.cover:memory[('first_page','active_code','stock_semantics')[j]]=truth(task['modes'])[('first_page','active_code','stock_semantics')[j]]
                        # The rule consumes exactly the public task plus current cache.
                        from r4lib.worker import make_view
                        v=make_view(task,memory);plan={**v['request'],**v['evidence']}
                        answer,tr=execute_reference(case['rows'],task['modes'],v,plan)
                        good=answer==gold_reference(case['rows'],task);sl=len(stale_channels(task,memory,task['modes']))
                        if overlap==cell['overlap']:
                            old=load(root/f'f/runs/R4_recheck/records/api_{sid:03d}_{t:03d}_{method}_primary.json')
                            assert old['plan']==plan and old['answer']==answer and old['packet_ids']==list(a.ids)
                        success+=int(good);loss+=sl;cost+=a.cost;age,budget=solver.after(age,budget,a)
                    r={'stream':sid,'original_condition':cell['condition'],'method':method,'packet_overlap':overlap,
                       'successes_NOT_LLM':success,'semantic_loss':loss,'credits':cost,'proxy_J_NOT_CURRENCY':loss+spec['price']*cost}
                    details.append(r);by[sid,method,overlap]=r
        pairs=[]
        for cell in p['streams']:
            for method in METHODS:
                a=by[cell['stream'],method,True];b=by[cell['stream'],method,False]
                pairs.append({'stream':cell['stream'],'original_condition':cell['condition'],'method':method,
                    'overlap_successes':a['successes_NOT_LLM'],'singleton_successes':b['successes_NOT_LLM'],
                    'success_delta_overlap_minus_singleton':a['successes_NOT_LLM']-b['successes_NOT_LLM'],
                    'overlap_J':a['proxy_J_NOT_CURRENCY'],'singleton_J':b['proxy_J_NOT_CURRENCY'],
                    'J_delta_overlap_minus_singleton':a['proxy_J_NOT_CURRENCY']-b['proxy_J_NOT_CURRENCY'],
                    'overlap_credits':a['credits'],'singleton_credits':b['credits']})
        agg=[]
        for method in METHODS:
            rows=[r for r in pairs if r['method']==method]
            agg.append({'method':method,'streams':len(rows),**{k:sum(r[k] for r in rows) for k in ('overlap_successes','singleton_successes','success_delta_overlap_minus_singleton','overlap_J','singleton_J','overlap_credits','singleton_credits')},
                'overlap_J_lower_streams':sum(r['J_delta_overlap_minus_singleton']<-1e-9 for r in rows),
                'overlap_J_higher_streams':sum(r['J_delta_overlap_minus_singleton']>1e-9 for r in rows)})
        save(out/'paired_bundle_posthoc.json',{'label':'POSTHOC_RULE_COUNTERFACTUAL_NOT_LLM_NOT_CONFIRMATORY','new_model_calls':0,
            'frozen_streams_all_retained':True,'original_factual_plans_and_answers_reproduced':384,'aggregate_descriptive_only':agg,
            'limitation':'Changes the offered packet set only; keeps task sequence, initial state, hidden flips, data, quota and each policy fixed. Conclusions conditional on these twelve mechanisms.'})
        table(out/'paired_bundle_posthoc.csv',pairs);table(out/'paired_bundle_variants.csv',details)
        print(json.dumps(agg,indent=2))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--feedback',type=Path,required=True);a.add_argument('--reference',type=Path,required=True);a.add_argument('--out',type=Path,required=True);v=a.parse_args();run(v.feedback,v.reference,v.out)
