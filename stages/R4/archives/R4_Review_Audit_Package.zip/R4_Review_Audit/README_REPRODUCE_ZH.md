# R4审核附件：离线重现

本包是审核材料，不是新的模型运行包。不会请求API密钥，不调用模型，不修改原始ZIP。
需要已有两个文件：用户R4反馈`fae81259-daf9-403f-a3c6-767c311f50df.zip`与最初分发的`Research_Handoff_R4.zip`。

在本附件目录，用Python3.11+及numpy==2.3.5：

```bash
python -m unittest test_independent_eval -v
python audit_r4.py --feedback /路径/fae81259-daf9-403f-a3c6-767c311f50df.zip --reference /路径/Research_Handoff_R4.zip --out results_reproduced
python paired_bundle_diagnostic.py --feedback /路径/fae81259-daf9-403f-a3c6-767c311f50df.zip --reference /路径/Research_Handoff_R4.zip --out paired_reproduced
```

无需用户现在再次执行上述命令；提供它们用于复现审核。audit_r4在临时目录解压，核对原版哈希后才导入已匹配的原程序，所有socket连接均被禁用。脚本会拒绝不是本轮原版的参考ZIP。输出目录可指定为新的目录。

`independent_eval.py`没有导入原评分器；其19项测试包含分页漏行、库存语义、schema类型和无关陈旧记忆。`audit_r4.py`同时复算原版账本、请求、轨迹、预算、独立分数和离线模型表。只对明确的派生J求和文本误差允许1e-9，原始证据不改动。

`paired_bundle_diagnostic.py`额外执行的是事后规则反事实诊断，不是LLM成绩或新独立测试集；所有12条原流都保留。其结果不可替换主结果。

`logs/original_65_tests.txt`是已由研究端执行的原工具测试；其中409次回环HTTP fixture是软件测试，不计入用户409次真实端点调用。

主要数据位于results/：
- audit_results.json：完整机器可读复核；
- per_record_recomputed.csv：408条主/重复独立评分；
- per_stream.csv、method_summary_recomputed.csv：逐流及方法汇总；
- paired_primary.csv：288个Joint对照方法对；
- repeat_diagnostics.csv：24组重复；
- call_ledger.csv：409次原始usage与调用计时；
- budget_ledger.csv：384个运行期额度扣减；
- pagination_evidence.json：三例陈旧答对的漏行证据；
- paired_bundle_posthoc.json/csv：同世界共享包反事实，零模型调用；
- descriptive_addendum.json：额外描述计数，非显著性结论。

操作只适用于当前公开合成实验材料；不运行模型生成的任意代码，不联系服务商、不对账、不自动修改或提交论文。同一助手独立复算不等于独立人类同行审查。
