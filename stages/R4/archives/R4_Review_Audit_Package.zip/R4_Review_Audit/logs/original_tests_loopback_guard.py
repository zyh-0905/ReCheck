# Permit only local software-test HTTP fixtures; deny remote connections.
import socket
_connect = socket.socket.connect
_connect_ex = socket.socket.connect_ex
def _allowed(address):
    return isinstance(address, tuple) and address[0] in ('127.0.0.1','::1','localhost')
def guard(self, address):
    if not _allowed(address): raise RuntimeError('Audit guard: external connection denied')
    return _connect(self, address)
def guard_ex(self, address):
    if not _allowed(address): raise RuntimeError('Audit guard: external connection denied')
    return _connect_ex(self, address)
socket.socket.connect = guard
socket.socket.connect_ex = guard_ex
