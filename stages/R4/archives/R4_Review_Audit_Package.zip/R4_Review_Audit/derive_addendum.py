"""Derive all extra descriptive counts from independent audit CSVs; zero model calls."""
import csv,json
from collections import Counter
from pathlib import Path
from audit_r4 import save

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def derive(root):
    results=root/'results';rs=read(results/'per_record_recomputed.csv');prs=[r for r in rs if r['replicate']=='primary']
    paired=read(results/'paired_primary.csv');streams=read(results/'per_stream.csv');budgets=read(results/'budget_ledger.csv')
    compare=[]
    for method in ('bundle_rollout','bundle_myopic','age_paced'):
        gr=[r for r in paired if r['comparison']==method];diff=[r for r in gr if r['semantic_difference']=='True']
        compare.append({'comparison':method,'pairs':len(gr),'different_semantics':len(diff),
           'joint_only_correct':sum(r['joint_success']=='True' and r['comparison_success']=='False' for r in gr),
           'comparison_only_correct':sum(r['joint_success']=='False' and r['comparison_success']=='True' for r in gr),
           'both_wrong_given_semantic_difference':sum(r['joint_success']==r['comparison_success']=='False' for r in diff),
           'both_right_given_semantic_difference':sum(r['joint_success']==r['comparison_success']=='True' for r in diff)})
    stcmp=[]
    for method,baseline in [('recheck_joint','bundle_myopic'),('bundle_rollout','bundle_myopic'),('bundle_rollout','recheck_joint')]:
        rows=[]
        for sid in range(12):
            a=next(x for x in streams if x['stream']==str(sid) and x['method']==method);b=next(x for x in streams if x['stream']==str(sid) and x['method']==baseline)
            rows.append({'stream':sid,'condition':a['condition'],'success_delta':int(a['successes'])-int(b['successes']),
              'J_delta':float(a['proxy_J_NOT_CURRENCY'])-float(b['proxy_J_NOT_CURRENCY'])})
        stcmp.append({'method':method,'baseline':baseline,'streams':rows,
            'lower_J':sum(r['J_delta']<-1e-9 for r in rows),'higher_J':sum(r['J_delta']>1e-9 for r in rows),'equal_J':sum(abs(r['J_delta'])<=1e-9 for r in rows)})
    failed=[r for r in prs if r['success']=='False']
    o={'label':'ADDITIONAL_DESCRIPTIVE_AUDIT_NOT_NEW_MODEL_RESULTS','failure_task_positions':len({(r['stream'],r['step']) for r in failed}),
       'stale_task_positions':len({(r['stream'],r['step']) for r in prs if int(r['semantic_loss'])}),
       'failure_types':dict(Counter(json.loads(r['answer']).get('error','WRONG_FINAL_VALUE') for r in failed)),
       'action_semantic_intersection':dict(Counter('action'+str(int(r['packet_difference']=='True'))+'_semantic'+str(int(r['semantic_difference']=='True')) for r in paired)),
       'paired_success_comparisons':compare,'stream_comparisons':stcmp,
       'final_budget_distribution':dict(Counter(r['remaining'] for r in budgets if r['step']=='7')),
       'per_round_credit_distribution':dict(Counter(r['credits_spent'] for r in budgets)),
       'packet_usage_sets':dict(Counter(r['packets'] for r in budgets)),
       'no_LLM_new_calls':0}
    save(results/'descriptive_addendum.json',o)
if __name__=='__main__':derive(Path(__file__).resolve().parent)
