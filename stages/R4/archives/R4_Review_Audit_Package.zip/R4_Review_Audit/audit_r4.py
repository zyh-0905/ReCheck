#!/usr/bin/env python3
"""Read-only R4 research audit. No model calls, no price lookup, no raw-input writes.
Usage: python audit_r4.py --feedback USER.zip --reference Research_Handoff_R4.zip --out OUT
Original sources are imported ONLY after hash/byte matching the pinned reference ZIP.
"""
from __future__ import annotations
import argparse,copy,csv,hashlib,io,json,math,socket,stat,sys,tempfile,zipfile
from pathlib import Path,PurePosixPath
from collections import Counter,defaultdict
from datetime import datetime
sys.path.insert(0,str(Path(__file__).resolve().parent))
from independent_eval import truth,schema_ok,execute_reference,gold_reference,stale_channels,KEYS,RELEVANT
EXPECTED_REFERENCE='bbf20090d0a586f8965479c65da7cf26e071955e03fd43bcb6aac19cbb678eb9'
METHODS=['recheck_joint','bundle_rollout','bundle_myopic','age_paced']

def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def table(p,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for r in rows:w.writerow({k:canon(v) if isinstance(v,(dict,list,tuple)) else v for k,v in r.items()})
def checked_zip(src):
    z=zipfile.ZipFile(src);seen=set();n=0
    for i in z.infolist():
        p=PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename,'Unsafe path'
        assert i.filename not in seen,'Duplicate path';seen.add(i.filename)
        assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1,'Link or encryption'
        n+=i.file_size
    assert n<300_000_000 and len(seen)<20000,'Archive limits'
    return z

def close(a,b,tol=1e-9):
    if isinstance(a,dict) and isinstance(b,dict):return set(a)==set(b) and all(close(a[k],b[k],tol) for k in a)
    if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(close(x,y,tol) for x,y in zip(a,b))
    if isinstance(a,float) or isinstance(b,float):
        return isinstance(a,(int,float)) and isinstance(b,(int,float)) and math.isclose(a,b,rel_tol=0,abs_tol=tol)
    return a==b

def audit(feedback:Path,reference:Path,out:Path):
    out.mkdir(parents=True,exist_ok=True);hashes={str(p.name):sha(p) for p in (feedback,reference)}
    assert hashes[reference.name]==EXPECTED_REFERENCE,'Reference differs from issued R4 archive'
    def no_connect(*args,**kwargs):raise RuntimeError('Offline audit: ALL socket connections prohibited')
    socket.socket.connect=no_connect;socket.socket.connect_ex=no_connect;socket.create_connection=no_connect
    with tempfile.TemporaryDirectory(prefix='r4_audit_') as tmp:
        root=Path(tmp);outer=checked_zip(feedback)
        inner_names=[n for n in outer.namelist() if n.endswith('.zip') and not n.startswith('__MACOSX/')]
        assert len(inner_names)==1
        inner=checked_zip(io.BytesIO(outer.read(inner_names[0])));f=root/'feedback';inner.extractall(f)
        original=checked_zip(reference);original.extractall(root/'reference');kit=root/'reference/R4_Research_Kit'
        manifest=load(f/'BUNDLE_MANIFEST.json');members=manifest['sha256']
        assert set(inner.namelist())==set(members)|{'BUNDLE_MANIFEST.json'}
        assert all(sha(f/p)==h for p,h in members.items())
        source=load(kit/'SOURCE_MANIFEST.json')['sha256']
        for rel,h in source.items():assert sha(kit/rel)==h==sha(f/'kit_source'/rel)
        assert (kit/'SOURCE_MANIFEST.json').read_bytes()==(f/'kit_source/SOURCE_MANIFEST.json').read_bytes()
        sys.path.insert(0,str(kit))
        from r4lib import protocol,review,offline,repair_guard,storage
        p=protocol.load_protocol();assert storage.source_hashes(kit)==source
        cfg=load(kit/'config.example.json');cfg_public={k:v for k,v in cfg.items() if k!='base_url'};cfg_public['base_url_sha256']=digest(cfg['base_url'])
        run=f/'runs/R4_recheck';smoke=f/'runs/R4_smoke';m=load(run/'manifest.json')
        # Public configuration has been frozen, including omissions and unknown prices.
        assert m['config']==cfg_public
        pre=load(f/'offline_reports/PREPARED.json')
        assert pre['config_sha256']==digest(cfg) and pre['protocol_sha256']==digest(p)
        assert pre['source_sha256']==digest(source) and pre['billing_sha256']==digest(m['billing_schedule'])
        assert pre['model_profile']==storage.profile(cfg)
        original_results={};byrun={};allcalls=[];ledgers={};csvcalls=[];responseids=[]
        for d,n in ((smoke,1),(run,408)):
            mm=load(d/'manifest.json');assert mm['source_hashes']==source
            for rel,h in source.items():assert sha(d/'code_snapshot'/rel)==h
            contract={k:mm[k] for k in ('version','config','study','spec','billing_schedule','source_hashes')}
            assert digest(contract)==mm['fingerprint']
            assert mm['profile_sha256']==digest(storage.profile(cfg))
            assert mm['evidence_label']=='REAL_ENDPOINT_CONTROLLED_DEVELOPMENT_NOT_CONFIRMATORY'
            assert mm['config']==cfg_public
            if d==run:assert mm['spec']==p
            assert load(d/'status.json')['state']=='completed'
            starts={load(x)['attempt']:load(x) for x in (d/'attempts').glob('*_start.json')}
            ends={load(x)['attempt']:load(x) for x in (d/'attempts').glob('*_result.json')}
            sends={load(x)['attempt']:load(x) for x in (d/'attempts').glob('*_send_intent.json')}
            calls={load(x)['logical_id']:load(x) for x in (d/'calls').glob('*.json')}
            assert len(starts)==len(ends)==len(sends)==len(calls)==n
            assert set(starts)==set(ends)==set(sends)==set(range(1,n+1))
            ordered=[]
            for i in range(1,n+1):
                st,en,se=starts[i],ends[i],sends[i]
                assert st['logical_id']==se['logical_id']==en['logical_id']
                assert st=={k:en[k] for k in st}
                assert digest(st['payload'])==st['payload_sha256']
                assert digest({'endpoint':cfg['base_url'],'payload':st['payload']})==st['request_sha256']
                assert calls[st['logical_id']]==en
                callfile=d/'calls'/(digest(st['logical_id'])+'.json')
                assert callfile.read_bytes()==(d/'attempts'/f'{i:06d}_result.json').read_bytes()
                assert datetime.fromisoformat(st['started_utc'])<=datetime.fromisoformat(se['local_send_intent_utc'])<=datetime.fromisoformat(en['ended_utc'])
                assert en['status']=='ok';body=en['response'];choice=body['choices'][0];text=choice['message']['content']
                assert en['text']==text and choice['finish_reason']=='stop' and isinstance(json.loads(text),dict)
                assert body['model']==cfg['model']
                u=body['usage'];assert all(type(u[k]) is int and u[k]>=0 for k in ('prompt_tokens','completion_tokens','total_tokens'))
                assert u['total_tokens']==u['prompt_tokens']+u['completion_tokens']
                hit=u.get('prompt_cache_hit_tokens',u.get('prompt_tokens_details',{}).get('cached_tokens'))
                miss=u.get('prompt_cache_miss_tokens');reason=u.get('completion_tokens_details',{}).get('reasoning_tokens')
                assert hit is None or 0<=hit<=u['prompt_tokens'];assert reason is None or 0<=reason<=u['completion_tokens']
                if hit is not None and miss is not None:assert hit+miss==u['prompt_tokens']
                identity={'returned_model':body['model'],'system_fingerprint':body.get('system_fingerprint')};assert identity==load(d/'endpoint_identity.json')
                responseids.append(body['id']);allcalls.append(en);ordered.append(en['logical_id'])
                md=en['metadata'];row={'run':d.name,'attempt':i,'logical_id':en['logical_id'],'replicate':md.get('replicate','smoke'),
                    'method':md.get('method','smoke'),'stream':md.get('stream'),'step':md.get('step'),'prompt_tokens':u['prompt_tokens'],
                    'completion_tokens':u['completion_tokens'],'reasoning_tokens':reason,'cached_tokens':hit,'uncached_tokens':miss,
                    'latency_seconds':en['latency_seconds'],'started_utc':st['started_utc'],'ended_utc':en['ended_utc'],
                    'payload_sha256':st['payload_sha256'],'response_id':body['id'],'finish_reason':choice['finish_reason'],'currency':'UNKNOWN','money':None}
                csvcalls.append(row)
            if d==run:assert ordered==protocol.logical_ids(p)
            else:
                assert ordered==['r4/smoke/one'] and json.loads(next(iter(calls.values()))['text'])=={'ok':True}
                assert next(iter(calls.values()))['payload']['messages']==[{'role':'user','content':'Return exactly {"ok":true} as JSON.'}]
            ev=[json.loads(x) for x in (d/'run_events.jsonl').read_text().splitlines()]
            assert [e['event'] for e in ev]==['invocation_started','invocation_ended']
            assert ev[0]['prior_budget']['attempts']==0 and ev[1]['budget']['attempts']==n
            ledgers[d.name]={'starts':n,'send_intents':n,'responses':n,'completed_calls':n,'unknown_attempts':0,'wall_seconds':ev[1]['wall_seconds'],
                'start_utc':ev[0]['utc'],'end_utc':ev[1]['utc'],'source_files_matched':len(source),'identity':load(d/'endpoint_identity.json')}
            byrun[d.name]=calls;original_results[d.name]=load(d/'summary.json')
        assert len(set(responseids))==409
        assert datetime.fromisoformat(ledgers['R4_smoke']['end_utc'])<datetime.fromisoformat(ledgers['R4_recheck']['start_utc'])
        assert datetime.fromisoformat(pre['prepared_utc'])<datetime.fromisoformat(ledgers['R4_smoke']['start_utc'])
        cases=load(run/'private/recheck_cases.json');assert cases==protocol.make_cases(p)
        records=[load(x) for x in sorted((run/'records').glob('*.json'))];assert len(records)==408
        calls=byrun['R4_recheck'];caseby={c['stream']:c for c in cases};cellby={c['stream']:c for c in p['streams']}
        primary=[r for r in records if r['replicate']=='primary'];rep=[r for r in records if r['replicate']=='repeat']
        assert len(primary)==384 and len(rep)==24
        index={(r['stream'],r['step'],r['method'],r['replicate']):r for r in records};assert len(index)==408
        budget_rows=[];record_rows=[];fresh_success_examples=[]
        for case in cases:
            sid=case['stream'];prefix=load(run/'prefixes'/f'api_{sid:03d}.json')
            assert prefix['memory']==truth(case['initial_modes'])
            assert prefix['startup_credit_equivalent']==6 and prefix['startup_channel_checks']==3 and prefix['outside_runtime_budget']
            for method in METHODS:
                memory=copy.deepcopy(prefix['memory']);ages=[0,0,0];remaining=p['episode_budget']
                packet_catalog={x['id']:x for x in protocol.spec(cellby[sid],p)['packets']}
                for t,task in enumerate(case['tasks']):
                    r=index[sid,t,method,'primary'];ages=[x+1 for x in ages]
                    assert r['prefix_sha256']==digest(prefix) and r['ages_before']==ages
                    packets=[packet_catalog[x] for x in r['packet_ids']]
                    assert len({x['id'] for x in packets})==len(packets)
                    cost=sum(x['cost'] for x in packets);covered=sorted(set(j for pk in packets for j in pk['cover']))
                    assert r['coverage']==covered and r['credits_spent']==cost and r['probe_count']==len(packets)
                    assert r['budget_before']==remaining and cost<=remaining and cost<=p['step_cap']
                    remaining-=cost;assert r['budget_after']==remaining>=0
                    assert close(r['model_probe_cost'],cost*cellby[sid]['price'])
                    assert len(r['probe_receipts'])==len(packets)
                    for pk,receipt in zip(packets,r['probe_receipts']):
                        assert receipt['packet_id']==pk['id'] and receipt['credit_cost']==pk['cost']
                        assert [x['channel'] for x in receipt['observations']]==pk['cover']
                    for j in covered:memory[KEYS[j]]=truth(task['modes'])[KEYS[j]];ages[j]=0
                    assert memory==r['memory_audit']
                    view=r['worker_view'];q=task['type'];req={'workflow':('catalog_ids','stock_sum','available_ids')[q]}
                    if q in (0,2):req.update(category=task['category'],page_size=3)
                    if q==1:req['skus']=task['skus']
                    if q==2:req['minimum_available']=task['minimum']
                    assert view['request']==req and view['evidence']=={KEYS[j]:memory[KEYS[j]] for j in RELEVANT[q]}
                    budget_rows.append({'stream':sid,'condition':case['condition'],'step':t,'method':method,'packets':r['packet_ids'],
                        'cover':covered,'credits_spent':cost,'remaining':remaining,'budget_pass':True})
                # Repeats inherit snapshots but incur no fresh probe transaction.
                if method in p['repeat_methods']:
                    a=index[sid,p['repeat_step'],method,'primary'];b=index[sid,p['repeat_step'],method,'repeat']
                    assert all(b[k]==a[k] for k in ('worker_view','memory_audit','ages_before','packet_ids','coverage','probe_receipts','budget_before','budget_after','prefix_sha256'))
                    assert all(b[k]==0 for k in ('credits_spent','probe_count','model_probe_cost','planning_seconds','probe_seconds'))
        for r in records:
            case=caseby[r['stream']];task=case['tasks'][r['step']];view=r['worker_view'];pl=r['plan'];c=calls[r['logical_calls'][0]]
            assert pl==json.loads(c['text']);valid=schema_ok(pl,view)
            answer,tr=execute_reference(case['rows'],task['modes'],view,pl);gold=gold_reference(case['rows'],task)
            assert answer==r['answer'] and tr==r['tool_trace'] and len(tr)==r['task_tool_calls']
            assert valid==r['plan_schema_valid'];stale=stale_channels(task,r['memory_audit'],task['modes'])
            rule={**view['request'],**view['evidence']};ruleanswer,ruletr=execute_reference(case['rows'],task['modes'],view,rule)
            row={k:r[k] for k in ('stream','condition','step','method','replicate','task_type','credits_spent','probe_count','planning_seconds','probe_seconds','tool_seconds','task_tool_calls')}
            row.update(success=bool(valid and answer==gold),schema_valid=valid,plan_equals_rule=pl==rule,stale_channels=stale,
                semantic_loss=len(stale),proxy_J_NOT_CURRENCY=len(stale)+r['model_probe_cost'],rule_success_NOT_LLM=ruleanswer==gold,
                answer=answer,gold=gold,budget_before=r['budget_before'],budget_after=r['budget_after'],coverage=r['coverage'],packets=r['packet_ids'],
                prompt_tokens=c['response']['usage']['prompt_tokens'],completion_tokens=c['response']['usage']['completion_tokens'],
                model_latency_seconds=c['latency_seconds'],logical_id=c['logical_id'])
            record_rows.append(row)
            if stale and answer==gold and r['replicate']=='primary':
                fixed=copy.deepcopy(pl);fixed.update({KEYS[j]:truth(task['modes'])[KEYS[j]] for j in stale})
                newans,newtr=execute_reference(case['rows'],task['modes'],view,fixed)
                ids=lambda tr:[x['sku'] for y in tr if y['path']=='/catalog/items' for x in y['result'].get('items',[])]
                oldids,newids=ids(tr),ids(newtr);omitted=[s for s in newids if s not in oldids]
                fresh_success_examples.append({'stream':r['stream'],'step':r['step'],'method':r['method'],'task':task,'plan':pl,'answer':answer,
                    'stale_channels':stale,'retrieved_skus_stale':oldids,'retrieved_skus_corrected':newids,'missing_skus':omitted,
                    'missing_canonical_rows':[x for x in case['rows'] if x['sku'] in omitted], 'corrected_answer_NOT_LLM':newans,
                    'row_sets_equal':set(oldids)==set(newids),'original_record':f"records/api_{r['stream']:03d}_{r['step']:03d}_{r['method']}_primary.json"})
        rowsby={(x['stream'],x['step'],x['method'],x['replicate']):x for x in record_rows};prs=[x for x in record_rows if x['replicate']=='primary']
        # Compare original per-task scoring independently; retain original bytes in input archive.
        with (run/'per_task.csv').open(encoding='utf-8-sig',newline='') as fh:
            for x in csv.DictReader(fh):
                a=rowsby[int(x['stream']),int(x['step']),x['method'],x['replicate']]
                for k in ('success','plan_follows_evidence','normative_reference_success_NOT_LLM'):
                    key={'plan_follows_evidence':'plan_equals_rule','normative_reference_success_NOT_LLM':'rule_success_NOT_LLM'}.get(k,k)
                    assert (x[k]=='True')==a[key]
                assert int(x['semantic_mismatches'])==a['semantic_loss']
                assert json.loads(x['stale_channels'])==a['stale_channels']
        aggregates=[];streams=[]
        for condition in ['ALL_DESCRIPTIVE_ONLY']+sorted({x['condition'] for x in prs}):
            for method in METHODS:
                group=[x for x in prs if x['method']==method and (condition=='ALL_DESCRIPTIVE_ONLY' or x['condition']==condition)]
                aggregates.append({'condition':condition,'method':method,'n':len(group),'successes':sum(x['success'] for x in group),
                    'credits':sum(x['credits_spent'] for x in group),'probe_packets':sum(x['probe_count'] for x in group),'semantic_loss':sum(x['semantic_loss'] for x in group),
                    'proxy_J_NOT_CURRENCY':sum(x['proxy_J_NOT_CURRENCY'] for x in group),
                    **{k:sum(x[k] for x in group) for k in ('prompt_tokens','completion_tokens','model_latency_seconds','planning_seconds','probe_seconds','tool_seconds','task_tool_calls')},
                    'plan_equals_rule':sum(x['plan_equals_rule'] for x in group),'rule_success_NOT_LLM':sum(x['rule_success_NOT_LLM'] for x in group)})
        for sid in sorted(caseby):
            for method in METHODS:
                group=[x for x in prs if x['stream']==sid and x['method']==method]
                streams.append({'stream':sid,'condition':caseby[sid]['condition'],'method':method,'successes':sum(x['success'] for x in group),
                                'credits':sum(x['credits_spent'] for x in group),'semantic_loss':sum(x['semantic_loss'] for x in group),
                                'proxy_J_NOT_CURRENCY':sum(x['proxy_J_NOT_CURRENCY'] for x in group)})
        pairs=[]
        for sid in caseby:
            for t in range(p['steps']):
                a=index[sid,t,'recheck_joint','primary'];aa=rowsby[sid,t,'recheck_joint','primary']
                for method in METHODS[1:]:
                    b=index[sid,t,method,'primary'];bb=rowsby[sid,t,method,'primary']
                    pairs.append({'stream':sid,'condition':a['condition'],'step':t,'comparison':method,
                     'packet_difference':a['packet_ids']!=b['packet_ids'],'coverage_difference':a['coverage']!=b['coverage'],
                     'semantic_difference':a['worker_view']['evidence']!=b['worker_view']['evidence'],
                     'same_request_payload':calls[a['logical_calls'][0]]['payload']==calls[b['logical_calls'][0]]['payload'],
                     'joint_success':aa['success'],'comparison_success':bb['success'],'joint_answer':aa['answer'],'comparison_answer':bb['answer']})
        repeats=[]
        for b in rep:
            a=index[b['stream'],b['step'],b['method'],'primary'];ca=calls[a['logical_calls'][0]];cb=calls[b['logical_calls'][0]]
            ua=ca['response']['usage'];ub=cb['response']['usage'];ma=ca['response']['choices'][0]['message'];mb=cb['response']['choices'][0]['message']
            repeats.append({'stream':b['stream'],'step':b['step'],'method':b['method'],'same_payload':ca['payload']==cb['payload'],
                'same_plan':a['plan']==b['plan'],'same_answer':a['answer']==b['answer'],'same_visible_text':ca['text']==cb['text'],
                'same_reasoning_text':ma.get('reasoning_content')==mb.get('reasoning_content'),
                'same_completion_tokens':ua['completion_tokens']==ub['completion_tokens'],
                'primary_completion_tokens':ua['completion_tokens'],'repeat_completion_tokens':ub['completion_tokens'],
                'primary_latency':ca['latency_seconds'],'repeat_latency':cb['latency_seconds'],
                'primary_success':rowsby[a['stream'],a['step'],a['method'],'primary']['success'],
                'repeat_success':rowsby[b['stream'],b['step'],b['method'],'repeat']['success']})
        # Independent pagination counterfactual: same rows/state/status, only start page differs.
        pagechecks=[]
        for c in cases:
            for status in (0,1):
                q={'workflow':'catalog_ids','category':'A','page_size':3};ev={'first_page':0,'active_code':status}
                v={'request':q,'evidence':ev,'allowed_keys':list(q)+list(ev)};pl={**q,**ev}
                _,tr0=execute_reference(c['rows'],(0,0,0),v,pl)
                pl['first_page']=1;_,tr1=execute_reference(c['rows'],(0,0,0),v,pl)
                ids=lambda tr:[i['sku'] for x in tr for i in x['result'].get('items',[])]
                pagechecks.append({'stream':c['stream'],'status_code':status,'rows_start0':len(ids(tr0)),'rows_start1':len(ids(tr1)),
                    'same_row_set':set(ids(tr0))==set(ids(tr1)),'omitted':sorted(set(ids(tr0))-set(ids(tr1)))})
        # Replay original mechanism from saved bytes; never construct Client or contact server.
        old_replay=load(run/'replay_audit.json');replay=review.replay_check(run)
        assert replay['pass'] and replay['request_bodies_checked']==408 and replay==old_replay
        regen_checks={}
        for d in (smoke,run):
            old={n:(d/n).read_bytes() for n in ('per_task.csv','per_call.csv','method_summary.csv','paired.csv') if (d/n).exists()}
            fresh=review.summarize(d)
            assert close(fresh,original_results[d.name])
            exact_names=[];rounding=[]
            for n in old:
                new=(d/n).read_bytes()
                if new==old[n]:exact_names.append(n);continue
                # Source/raw responses remain byte-exact. Only the derived sum's
                # decimal representation may differ by <=1e-9 across Python builds.
                assert n=='method_summary.csv','Unexpected changed CSV '+n
                aa=list(csv.DictReader(io.StringIO(old[n].decode('utf-8-sig'))))
                bb=list(csv.DictReader(io.StringIO(new.decode('utf-8-sig'))))
                assert len(aa)==len(bb)
                for idx,(x,y) in enumerate(zip(aa,bb)):
                    assert set(x)==set(y)
                    for key in x:
                        if x[key]==y[key]:continue
                        assert key=='proxy_J_NOT_CURRENCY' and abs(float(x[key])-float(y[key]))<=1e-9,(n,idx,key,x[key],y[key])
                        rounding.append({'row':idx,'field':key,'original':x[key],'recomputed':y[key],'absolute_difference':abs(float(x[key])-float(y[key]))})
            regen_checks[d.name]={'summary_equal_tolerance_1e_9':True,'csv_byte_matches':exact_names,'derived_proxy_sum_rounding_only':rounding}
        exact=offline.factorial_report();flight=offline.preflight(p);reg=review.regression_checks();repair=repair_guard.prior_diagnostic()
        assert close(exact,load(f/'offline_reports/EXACT_GRID.json'))
        assert close(flight,load(f/'offline_reports/PREFLIGHT.json'))
        assert reg==load(f/'offline_reports/REGRESSION.json') and repair==load(f/'offline_reports/REPAIR_COST_DIAGNOSTIC.json')
        grid_stats=Counter()
        for row in exact['rows']:
            vs=row['values'];j=vs['recheck_joint'];roll=vs['bundle_rollout']
            for key in ('bundle_myopic','age_paced','bundle_rollout'):
                grid_stats['joint_vs_'+key+('_lower' if j<vs[key]-1e-9 else '_higher' if j>vs[key]+1e-9 else '_equal')]+=1
        totals=[]
        for group in ('primary','repeat','smoke'):
            rr=[x for x in csvcalls if x['replicate']==group]
            totals.append({'group':group,'calls':len(rr),**{k:sum(x[k] or 0 for x in rr) for k in ('prompt_tokens','completion_tokens','reasoning_tokens','latency_seconds')}})
        cross={m:Counter() for m in METHODS[1:]}
        for r in pairs:cross[r['comparison']][f"action{int(r['packet_difference'])}_semantic{int(r['semantic_difference'])}"]+=1
        snap_summary={
          'scope':'Submitted R4 controlled development logs. Not provider/invoice attestation or independent peer review.',
          'input_sha256':hashes,'bundle_items_checked':len(members),'bundle_total_files':len(members)+1,'source_files':len(source),
          'ledger':ledgers,'all_response_ids_unique':len(set(responseids)),'prepared_binding_verified':True,'new_remote_model_calls':0,
          'replay':replay,'independent_records_recomputed':len(records),'primary_records':len(primary),'repeat_records':len(rep),
          'regenerated_tables':regen_checks,'hard_budget':{'primary_budget_checks':len(budget_rows),'streams_by_policy':48,
          'per_stream_limit':8,'per_round_limit':4,'startup_calibration_per_stream':6,'violations':0,'repeat_charged':0},
          'aggregates':aggregates,'totals':totals,'paired_primary':len(pairs),'paired_cross_tabs':{k:dict(v) for k,v in cross.items()},
          'repeat_equal_counts':{k:sum(r[k] for r in repeats) for k in ('same_payload','same_plan','same_answer','same_visible_text','same_reasoning_text','same_completion_tokens')},
          'stale_cross_tab':dict(Counter(('stale_' if x['semantic_loss'] else 'fresh_')+('success' if x['success'] else 'failure') for x in prs)),
          'stale_channel_outcomes':dict(Counter(str(x['stale_channels'])+('_success' if x['success'] else '_failure') for x in prs if x['semantic_loss'])),
          'stale_success_cases':fresh_success_examples,'pagination_checks':pagechecks,'offline_exact_cells':exact['cells'],'offline_grid_summary':dict(grid_stats),
          'all_inputs_unchanged':all(sha(fp)==hashes[fp.name] for fp in (feedback,reference)),
          'billing':'UNKNOWN; no current price lookup; not inferred from credits.',
          'decision':'ACCEPT_EXECUTION_DEVELOPMENT_ONLY; NO_RERUN_REQUIRED; DO_NOT_SCALE_SAME_NARROW_LLM_TASK'}
        assert snap_summary['all_inputs_unchanged']
        save(out/'audit_results.json',snap_summary);save(out/'pagination_evidence.json',fresh_success_examples)
        save(out/'original_replay_verified.json',replay);save(out/'exact_grid_verified.json',exact);save(out/'preflight_verified.json',flight)
        table(out/'per_record_recomputed.csv',record_rows);table(out/'per_stream.csv',streams);table(out/'method_summary_recomputed.csv',aggregates)
        table(out/'paired_primary.csv',pairs);table(out/'repeat_diagnostics.csv',repeats);table(out/'call_ledger.csv',csvcalls);table(out/'budget_ledger.csv',budget_rows)
        print(json.dumps({'pass':True,'manifest_items':len(members),'calls':len(allcalls),'records':len(records),'replay':replay['pass'],
            'stale':snap_summary['stale_cross_tab'],'repeats':snap_summary['repeat_equal_counts'],'remote_model_calls':0},indent=2))
        return snap_summary

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--feedback',type=Path,required=True);ap.add_argument('--reference',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();audit(a.feedback,a.reference,a.out)
