import unittest
from independent_eval import truth, schema_ok, execute_reference, gold_reference, stale_channels

class IndependentTests(unittest.TestCase):
    def setUp(self):
        self.rows=[dict(sku=f'S{i}',category='B' if i<3 else 'A',active=True,physical=10+i,reserved=i+1) for i in range(7)]
        self.rows.append(dict(sku='I0',category='A',active=False,physical=50,reserved=2))
    def view(self,workflow='catalog_ids',**kw):
        req={'workflow':workflow}
        if workflow=='stock_sum':req['skus']=['S0','S1','I0'];ev={'stock_semantics':'net'}
        else:
            req.update(category='A',page_size=3)
            if workflow=='available_ids':req['minimum_available']=8
            ev={'first_page':0,'active_code':1}
            if workflow=='available_ids':ev['stock_semantics']='net'
        ev.update(kw)
        return dict(request=req,evidence=ev,allowed_keys=list(req)+list(ev))
    def runplan(self,modes=(0,0,0),**kw):
        v=self.view(**kw);return execute_reference(self.rows,modes,v,{**v['request'],**v['evidence']})
    def test_mode_mapping(self):self.assertEqual(truth([1,1,1]),dict(first_page=1,active_code=0,stock_semantics='gross'))
    def test_reject_bool_origin(self):
        v=self.view();p={**v['request'],**v['evidence'],'first_page':True};self.assertFalse(schema_ok(p,v))
    def test_reject_extra_unused_field(self):
        v=self.view();p={**v['request'],**v['evidence'],'stock_semantics':'net'};self.assertFalse(schema_ok(p,v))
    def test_reject_changed_public_category(self):
        v=self.view();p={**v['request'],**v['evidence'],'category':'B'};self.assertFalse(schema_ok(p,v))
    def test_valid_stale_semantics_not_illegal(self):
        v=self.view();p={**v['request'],**v['evidence'],'first_page':1};self.assertTrue(schema_ok(p,v))
    def test_correct_catalog(self):self.assertEqual(self.runplan()[0],{'skus':['S3','S4','S5','S6']})
    def test_skip_page_reduces_retrieved_rows(self):
        _,a=self.runplan();_,b=self.runplan(first_page=1)
        extract=lambda t:[i['sku'] for x in t for i in x['result'].get('items',[])]
        self.assertEqual(extract(a),[f'S{i}' for i in range(7)]);self.assertEqual(extract(b),[f'S{i}' for i in range(3,7)])
    def test_skip_page_can_preserve_filtered_answer(self):self.assertEqual(self.runplan()[0],self.runplan(first_page=1)[0])
    def test_skip_page_can_drop_requested_sku(self):
        self.rows[0]['category']='A';self.assertNotEqual(self.runplan()[0],self.runplan(first_page=1)[0])
    def test_before_first_page_errors(self):self.assertEqual(self.runplan(modes=(1,0,0))[0],{'error':'PAGE_BEFORE_FIRST'})
    def test_status_flip_wrong_subset(self):self.assertEqual(self.runplan(modes=(0,1,0))[0],{'skus':['I0']})
    def test_stock_gross_subtract_once(self):self.assertEqual(self.runplan(modes=(0,0,1),workflow='stock_sum',stock_semantics='gross')[0],{'available_total':66})
    def test_stock_net_no_double_subtraction(self):self.assertEqual(self.runplan(workflow='stock_sum')[0],{'available_total':66})
    def test_net_with_wrong_gross_loses_reserved(self):self.assertEqual(self.runplan(workflow='stock_sum',stock_semantics='gross')[0],{'available_total':61})
    def test_clamp_at_zero(self):
        self.rows[0]['physical']=0
        self.assertEqual(self.runplan(workflow='stock_sum')[0],{'available_total':57})
    def test_available_filter_after_join(self):self.assertEqual(self.runplan(workflow='available_ids')[0],{'skus':['S3','S4','S5','S6']})
    def test_gold_uses_canonical_active_state(self):self.assertEqual(gold_reference(self.rows,dict(type=0,category='A')),{'skus':['S3','S4','S5','S6']})
    def test_irrelevant_stale_not_counted(self):self.assertEqual(stale_channels(dict(type=0),dict(first_page=0,active_code=1,stock_semantics='gross'),[0,0,0]),[])
    def test_relevant_stale_counted(self):self.assertEqual(stale_channels(dict(type=2),dict(first_page=1,active_code=1,stock_semantics='gross'),[0,0,0]),[0,2])

if __name__=='__main__':unittest.main()
