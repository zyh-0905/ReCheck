"""Independently written, offline R4 evaluator (no original scoring imports).
It accepts evaluator-private canonical rows; it must never be used as a policy.
"""
from copy import deepcopy
KEYS=('first_page','active_code','stock_semantics')
RELEVANT=((0,1),(2,),(0,1,2))

def truth(modes):
    return {'first_page':modes[0],'active_code':1-modes[1],
            'stock_semantics':('net','gross')[modes[2]]}

def schema_ok(plan, view):
    if not isinstance(plan,dict) or set(plan)!=set(view['allowed_keys']):return False
    for key,value in view['request'].items():
        if key not in plan or type(plan[key]) is not type(value) or plan[key]!=value:return False
    for key in ('first_page','active_code'):
        if key in plan and (type(plan[key]) is not int or plan[key] not in (0,1)):return False
    if 'stock_semantics' in plan and plan['stock_semantics'] not in ('net','gross'):return False
    return True

def execute_reference(rows, modes, view, plan):
    """Rebuild exact task-tool trace and output using independent list arithmetic."""
    if not schema_ok(plan,view):return {'error':'INVALID_PLAN'},[]
    trace=[];by_sku={r['sku']:r for r in rows}
    def inventory(skus):
        if any(s not in by_sku for s in skus):result={'error':'UNKNOWN_SKU'}
        else:
            result={'items':[{'sku':s,'stock_value':by_sku[s]['physical'] if modes[2] else max(0,by_sku[s]['physical']-by_sku[s]['reserved']),
                              'reserved':by_sku[s]['reserved']} for s in skus]}
        trace.append({'path':'/inventory/batch','args':{'skus':list(skus)},'result':deepcopy(result)})
        return result
    def free(item):return max(0,item['stock_value']-(item['reserved'] if plan['stock_semantics']=='gross' else 0))
    if plan['workflow']=='stock_sum':
        data=inventory(plan['skus'])
        return (data if 'error' in data else {'available_total':sum(free(r) for r in data['items'])}),trace
    selected=[r for r in rows if r['active']==(plan['active_code']==1-modes[1])]
    gathered=[];size=plan['page_size']
    for k in range(64):
        page=plan['first_page']+k;index=page-modes[0]
        if index<0:result={'error':'PAGE_BEFORE_FIRST'}
        else:result={'items':[{'sku':r['sku'],'category':r['category']} for r in selected[index*size:(index+1)*size]],
                     'has_more':(index+1)*size<len(selected)}
        trace.append({'path':'/catalog/items','args':{'page':page,'page_size':size,'status_code':plan['active_code']},'result':deepcopy(result)})
        if 'error' in result:return result,trace
        gathered.extend(result['items'])
        if not result['has_more']:break
    else:return {'error':'PAGE_LIMIT'},trace
    gathered=[r for r in gathered if r['category']==plan['category']]
    if plan['workflow']=='available_ids':
        data=inventory([r['sku'] for r in gathered])
        if 'error' in data:return data,trace
        gathered=[r for r in data['items'] if free(r)>=plan['minimum_available']]
    return {'skus':sorted(r['sku'] for r in gathered)},trace

def gold_reference(rows, task):
    if task['type']==1:
        table={r['sku']:r for r in rows}
        return {'available_total':sum(max(0,table[s]['physical']-table[s]['reserved']) for s in task['skus'])}
    selected=[r for r in rows if r['active'] and r['category']==task['category']]
    if task['type']==2:selected=[r for r in selected if max(0,r['physical']-r['reserved'])>=task['minimum']]
    return {'skus':sorted(r['sku'] for r in selected)}

def stale_channels(task, memory, modes):
    current=truth(modes)
    return [j for j in RELEVANT[task['type']] if memory.get(KEYS[j])!=current[KEYS[j]]]
