# Feedback19 / R12 receipt audit

This is an accepted material receipt with narrative corrections, not a new R19
experiment, native evaluator rerun, or model dataset. No user execution required.

See `docs/R12_Feedback19_Review_Report_ZH.md`. The original feedback and R12
delivery are preserved byte-for-byte under `inputs/`.

Optional research-side reproduction (standard library, new output directory):

```bash
python src/review_feedback19.py --feedback inputs/feedback19_original.zip --source inputs/R12_Public_Evaluator_Audit.zip --out /tmp/r12_feedback19_new_review
```

The R12 verifier and snapshot checker are reused; the native ToolSandbox
evaluator and original 36 tests are not executed in this receipt audit.
A copied CSV row is not evidence of a new experiment. Input hashes are fixed;
the output path must not already exist. No dependencies are installed.
