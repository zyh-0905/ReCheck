"""Read-only Feedback19/R12 receipt audit. No LLM, ToolSandbox execution or network.

Outputs go to a new directory. The original R12 verifier and pure-standard-library
snapshot checker are executed from the SHA-256-pinned delivery. This is not a new
independent implementation of the original milestone evaluator.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, io, json, math, pathlib, runpy
import socket, stat, subprocess, sys, tempfile, zipfile

SOURCE_SHA = 'eb53d1226e0a213d2a212fbc76f804cc6cc21f651a23b1765df57a9fe242ec7b'
FEEDBACK_SHA = '7cc3ffbe9c1113d9039fb391675733d7e1f02cf3eb87fe5a431d728d4bcb59df'

def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def name_of(info: zipfile.ZipInfo) -> str:
    name = info.filename
    if not (info.flag_bits & 0x800):
        try:
            name = name.encode('cp437').decode('utf-8')
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    p = pathlib.PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
            'Unsafe ZIP name')
    require(not (p.parts and ':' in p.parts[0]), 'Unsafe Windows ZIP path')
    require(not stat.S_ISLNK(info.external_attr >> 16), 'ZIP symlink')
    return name

def entries(data: bytes) -> tuple[dict[str, bytes], dict]:
    files, seen = {}, set()
    counts = {'total_entries': 0, 'directories': 0, 'mac_metadata': 0, 'data_files': 0}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        require(sum(i.file_size for i in z.infolist()) < 64*1024*1024, 'ZIP size cap')
        for i in z.infolist():
            n = name_of(i)
            require(n not in seen, 'Duplicate normalized ZIP name')
            seen.add(n); counts['total_entries'] += 1
            if n.startswith('__MACOSX/'):
                counts['mac_metadata'] += 1
            elif i.is_dir():
                counts['directories'] += 1
            else:
                files[n] = z.read(i)
                counts['data_files'] += 1
    roots = {n.split('/')[0] for n in files}
    require(len(roots) == 1, 'Expected one ZIP root')
    root = next(iter(roots)) + '/'
    require(all(n.startswith(root) for n in files), 'Bad root')
    return {n[len(root):]: b for n, b in files.items()}, counts

def parse_bool(value: str) -> bool:
    require(value in ('True', 'False'), 'Noncanonical Boolean')
    return value == 'True'

def dump(path: pathlib.Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf8')

def write_csv(path: pathlib.Path, rows: list[dict]) -> None:
    require(bool(rows), 'Empty output table')
    with path.open('w', newline='', encoding='utf8') as f:
        w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)

def run(feedback_path: pathlib.Path, source_path: pathlib.Path, out: pathlib.Path) -> None:
    def no_network(*args, **kwargs):
        raise RuntimeError('Network disabled in receipt audit')
    socket.create_connection = no_network
    socket.socket.connect = no_network
    socket.getaddrinfo = no_network
    fb_bytes, src_bytes = feedback_path.read_bytes(), source_path.read_bytes()
    require(sha(fb_bytes) == FEEDBACK_SHA, 'Feedback digest mismatch')
    require(sha(src_bytes) == SOURCE_SHA, 'Pinned R12 source digest mismatch')
    require(not out.exists(), 'Output already exists; do not overwrite')
    out.mkdir(parents=True)
    feedback, fc = entries(fb_bytes)
    source, sc = entries(src_bytes)
    manifest = json.loads(source['MANIFEST.json'])['files']
    require(set(source) == set(manifest) | {'MANIFEST.json'}, 'R12 manifest coverage')
    for n, m in manifest.items():
        require(n in source and len(source[n]) == m['bytes'] and sha(source[n]) == m['sha256'],
                'R12 manifest mismatch: '+n)
    mapping = {
        '原始记录/DELIVERY_VERIFICATION.json': 'DELIVERY_VERIFICATION.json',
        '原始记录/MANIFEST.json': 'MANIFEST.json',
        '原始记录/README.md': 'README.md',
        '审核/R12_Research_Report_ZH.md': 'docs/R12_Research_Report_ZH.md',
        '审核/CLAIM_EVIDENCE_MATRIX_ZH.md': 'docs/CLAIM_EVIDENCE_MATRIX_ZH.md',
        '审核/records.csv': 'results/regrade_final/records.csv',
        '审核/summary.json': 'results/regrade_final/summary.json',
        '审核/PROTOCOL.json': 'docs/PROTOCOL.json',
        '审核/SUPPLEMENT_PROTOCOL.json': 'docs/SUPPLEMENT_PROTOCOL.json',
    }
    require(set(feedback) == set(mapping) | {'README.md', '审核/verify_archive输出.txt'},
            'Unexpected feedback file set')
    copied=[]
    for n, original in mapping.items():
        require(feedback[n] == source[original], 'Changed original copy: '+n)
        copied.append({'feedback_path': n, 'source_path': original,
                       'bytes': len(feedback[n]), 'sha256': sha(feedback[n]), 'byte_equal': True})
    upstream = json.loads(source['vendor/UPSTREAM_MANIFEST.json'])
    vname = 'vendor/ToolSandbox-'+upstream['commit']+'.zip'
    vendored, vc = entries(source[vname])
    require(set(vendored)==set(upstream['sha256']), 'Upstream source coverage')
    for n, h in upstream['sha256'].items():
        require(sha(vendored[n])==h, 'Upstream copied-source hash mismatch')

    with tempfile.TemporaryDirectory(prefix='r12_receipt_') as d:
        temp = pathlib.Path(d)
        for n,b in source.items():
            f=temp/n; f.parent.mkdir(parents=True,exist_ok=True); f.write_bytes(b)
        command=subprocess.run([sys.executable,'-I',str(temp/'verify_archive.py'),str(temp)],
                               capture_output=True,text=True,timeout=20)
        (out/'archive_verifier_stdout.txt').write_text(command.stdout,encoding='utf8')
        (out/'archive_verifier_stderr.txt').write_text(command.stderr,encoding='utf8')
        require(command.returncode==0, 'Original archive verifier failed')
        verify_result=json.loads(command.stdout)
        require(json.loads(feedback['审核/verify_archive输出.txt'])==verify_result,
                'Submitted verifier output differs')
        checker=runpy.run_path(str(temp/'src/evidence_check.py'))['check_record']
        # Only this shipped standard-library checker is called, not native execution.
        raw_rows=list(csv.DictReader(io.StringIO(feedback['审核/records.csv'].decode('utf8'))))
        seen=set(); records=[]
        for row in raw_rows:
            key=(row['cohort'],row['scenario'],row['variant'])
            require(key not in seen, 'Duplicate trajectory in table'); seen.add(key)
            record=json.loads(source[row['source']])
            snapshot_check=checker(record)
            score=float(row['official_similarity']); valid=parse_bool(row['terminal_valid'])
            require(math.isfinite(score) and 0<=score<=1,'Bad score')
            require(score==record['official_evaluation']['similarity'],'Saved original score mismatch')
            require(valid==snapshot_check['terminal_valid'],'Snapshot terminal mismatch')
            require(row['scenario']==record['scenario'] and row['variant']==record['variant'],'Source identity mismatch')
            tool_count=len(record['events']); errors=sum(e['response']['ok'] is False for e in record['events'])
            require(tool_count==int(row['native_tool_calls']) and errors==int(row['native_tool_errors']),
                    'Event count mismatch')
            full=score==1.0; mismatch=full and not valid
            require(parse_bool(row['full_score_terminal_mismatch'])==mismatch, 'Mismatch label')
            require(parse_bool(row['original_full_and_terminal'])==(full and valid), 'Joint label')
            records.append({'cohort':row['cohort'],'scenario':row['scenario'],'variant':row['variant'],
                'official_similarity_saved':score,'terminal_valid_from_saved_snapshot':valid,
                'full_score_terminal_mismatch_recomputed':mismatch,'native_tools_in_original_trace':tool_count,
                'native_errors_in_original_trace':errors,'original_trajectory':row['source']})
    variants=[]
    for v in ['correct','error_then_correct','correct_then_redundant_error',
              'achieve_then_revert','achieve_revert_repair','claim_only']:
        group=[r for r in records if r['variant']==v]
        variants.append({'variant':v,'records':len(group),
                         'original_full_score':sum(r['official_similarity_saved']==1 for r in group),
                         'terminal_true':sum(r['terminal_valid_from_saved_snapshot'] for r in group),
                         'terminal_false':sum(not r['terminal_valid_from_saved_snapshot'] for r in group)})
    summary={
        'records':len(records),'original_full_scores':sum(r['official_similarity_saved']==1 for r in records),
        'terminal_valid':sum(r['terminal_valid_from_saved_snapshot'] for r in records),
        'full_score_terminal_mismatch':sum(r['full_score_terminal_mismatch_recomputed'] for r in records),
        'native_tool_calls':sum(r['native_tools_in_original_trace'] for r in records),
        'native_tool_errors':sum(r['native_errors_in_original_trace'] for r in records)}
    original_summary=json.loads(feedback['审核/summary.json'])
    for k,v in summary.items():require(original_summary[k]==v, 'Summary mismatch: '+k)
    others=[r for r in records if r['variant']!='achieve_then_revert']
    distribution=collections.Counter(str(r['official_similarity_saved']) for r in records if r['variant']=='claim_only')
    verification={
        'phase':'R12_FEEDBACK19_RECEIPT_AUDIT','source_phase':'R12_PUBLIC_EVALUATOR_OFFLINE_AUDIT_01',
        'acceptance':'ACCEPT_RECEIPT_WITH_NARRATIVE_CORRECTIONS','new_R19_research_experiment':False,
        'feedback_sha256':sha(fb_bytes),'feedback_bytes':len(fb_bytes),'feedback_zip_counts':fc,
        'r12_archive_sha256':sha(src_bytes),'r12_archive_bytes':len(src_bytes),'r12_zip_counts':sc,
        'r12_registered_files_verified':len(manifest),'upstream_copied_source_files_checked':len(vendored),
        'upstream_checked_against_bundled_manifest_not_new_web_authentication':True,
        'matched_copy_files':len(mapping),'original_archive_verifier_exit_code':command.returncode,
        'submitted_verifier_output_matches_current_result':True,
        'returned_file_new_llm_call_ledger_present':False,
        'saved_snapshot_checks_passed':len(records),'snapshot_checker':'unchanged R12 src/evidence_check.py',
        'new_independent_native_evaluator_runs':0,'original_36_test_suite_rerun':False,
        'new_tool_workflows':0,'new_model_episodes':0,'review_remote_llm_requests':0,
        'user_current_commands_required':False,'new_paid_budget':0,
        'existing_scripted_record_summary':summary,
        'other_than_achieve_then_revert':{'records':len(others),
           'terminal_true':sum(r['terminal_valid_from_saved_snapshot'] for r in others),
           'terminal_false':sum(not r['terminal_valid_from_saved_snapshot'] for r in others)},
        'claim_only_original_similarity_distribution':dict(sorted(distribution.items())),
        'file_count_or_CSV_rows_not_proof_of_new_native_regrade':True,
        'original_reports_and_raw_data_modified':False,
        'network': 'No network calls in audit; no LLM client imported; reviewed original verifier is stdlib-only',
        'limits': ['Submitted verifier stdout has no independent process provenance; same output reproduced here.',
                   'No new native ToolSandbox evaluation or full dependency installation performed.',
                   'No certification of all user local commands, network accesses, secrets, or previous rounds.',
                   'Historical original similarity is checked for linkage and components, not recomputed natively in this receipt audit.',
                   'The reminder no-action case has no clock receipt: shipped checker uses recorded requested date for this case.',
                   'No new scientific replication sample, model failure rate, maintainer confirmation or publication claim.']}
    dump(out/'verification.json',verification)
    dump(out/'copy_inventory.json',copied)
    dump(out/'feedback_files.json',[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(feedback.items())])
    dump(out/'recomputed_summary.json',summary)
    write_csv(out/'recomputed_variants.csv',variants)
    write_csv(out/'record_checks.csv',records)
    (out/'submitted_README_original.md').write_bytes(feedback['README.md'])
    require(sha(feedback_path.read_bytes())==FEEDBACK_SHA and sha(source_path.read_bytes())==SOURCE_SHA,
            'Original input changed')
    print(json.dumps({'acceptance':verification['acceptance'],'feedback_data_files':fc['data_files'],
        'matched_copies':len(mapping),'source_manifest':len(manifest),'saved_records':len(records),
        'summary':summary,'other_variants':verification['other_than_achieve_then_revert'],
        'claim_only':distribution},ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--feedback',required=True,type=pathlib.Path)
    p.add_argument('--source',required=True,type=pathlib.Path)
    p.add_argument('--out',required=True,type=pathlib.Path)
    args=p.parse_args()
    run(args.feedback,args.source,args.out)
