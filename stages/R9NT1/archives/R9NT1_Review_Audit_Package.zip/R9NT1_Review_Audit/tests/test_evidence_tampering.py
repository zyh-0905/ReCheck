"""Optional full-data tamper tests. Run with R9NT1_FEEDBACK_ROOT and R9NT1_KIT_ROOT.
Each change is made only in a temporary COPY and the outer file digest is updated;
this checks substantive validation, not just the original bundle hash.
"""
import unittest,os,tempfile,shutil,sys,json,hashlib,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from review import review,dump,read,sha,digest
@unittest.skipUnless(os.environ.get('R9NT1_FEEDBACK_ROOT') and os.environ.get('R9NT1_KIT_ROOT'),'full-data roots not supplied')
class EvidenceTamperTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory(prefix='r9nt-mutant-');cls.root=Path(cls.temp.name)/'input';shutil.copytree(os.environ['R9NT1_FEEDBACK_ROOT'],cls.root);cls.kit=Path(os.environ['R9NT1_KIT_ROOT']);cls.output=Path(cls.temp.name)/'review';cls.originals={}
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def setUp(self):self.originals={}
 def tearDown(self):
  for p,b in self.originals.items():p.write_bytes(b)
 def replace(self,rel,obj,raw=False):
  p=self.root/rel
  if p not in self.originals:self.originals[p]=p.read_bytes()
  if raw:p.write_bytes(obj)
  else:dump(p,obj)
  mpath=self.root/'BUNDLE_MANIFEST.json'
  if mpath not in self.originals:self.originals[mpath]=mpath.read_bytes()
  m=read(mpath);m['files'][rel]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())};dump(mpath,m)
 def rejected(self):
  with self.assertRaises(ValueError):review(self.root,self.kit,self.output)
 def test_unmodified_evidence_passes(self):self.assertTrue(review(self.root,self.kit,self.output)['execution_complete'])
 def test_forged_final_success_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['score']['trace_safe_success']=True;self.replace(rel,x);self.rejected()
 def test_missing_reasoning_history_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['turns'][0]['assistant_message'].pop('reasoning_content');self.replace(rel,x);self.rejected()
 def test_forged_tool_return_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['turns'][2]['tool_messages'][0]['content']='{"ok":true,"value":[],"error":null}';self.replace(rel,x);self.rejected()
 def test_bad_tool_link_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['turns'][1]['executions'][0]['tool_call_id']='forged';self.replace(rel,x);self.rejected()
 def test_exposure_changed_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['exposure']['triggered']=False;self.replace(rel,x);self.rejected()
 def test_source_changed_even_resigned_bundle_rejected(self):
  rel='nt/prompts.py';self.replace(rel,(self.root/rel).read_bytes()+b'\n# changed\n',raw=True);self.rejected()
 def test_response_identity_duplicate_rejected(self):
  rel='runs/main/attempts/000002_response.json';x=read(self.root/rel);first=read(self.root/'runs/main/attempts/000001_response.json');x['response']['id']=first['response']['id'];raw=json.dumps(x['response']).encode();x['raw_original_sha256']=sha(raw);x['raw_stored_sha256']=sha(raw);self.replace(rel,x);self.replace('runs/main/attempts/000002_response.raw',raw,raw=True);self.rejected()
 def test_budget_count_changed_rejected(self):
  rel='runs/main/episodes/primary_n02_verify_confirm.json';x=read(self.root/rel);x['tool_calls']-=1;self.replace(rel,x);self.rejected()
 def test_goal_contract_changed_rejected(self):
  rel='fixtures/cases.json';x=read(self.root/rel);x[2]['contract']['name']='someone else';self.replace(rel,x);self.rejected()
if __name__=='__main__':unittest.main(verbosity=2)
