# R9NT1反馈审计包（不运行新模型）

这不是新的付费实验包。原反馈内层ZIP与原执行包位于evidence/；输入不修改。

## 标准库独立复核

Python 3.10+，无需任何模型账户、GPU或额外依赖：

```bash
python scripts/review.py --feedback evidence/R9NT1_feedback.zip --kit evidence/Research_Handoff_R9NT1.zip --out reproduced
python -m unittest discover -s tests -v
```

未设置完整证据测试路径时，36项单位测试执行，10项证据破坏测试跳过。要执行全部46项，先将反馈内层与原执行包分别安全解压，设置`R9NT1_FEEDBACK_ROOT`为包含BUNDLE_MANIFEST.json的根目录、`R9NT1_KIT_ROOT`为原R9NT1_Research_Kit根目录，再运行上述测试。测试只修改临时副本并对外层文件清单重新签名，以检验是否真正检查回执、状态与分数。

## 原版原生重放（可选，研究端已经完成）

需要Python3.11和原版requirements依赖。本包不重新附带130MB公开运行材料，也不要求用户重跑。用原解释器运行：

```bash
python scripts/native_replay.py --feedback evidence/R9NT1_feedback.zip --kit evidence/Research_Handoff_R9NT1.zip --out native_replay.json
```

它在临时副本运行原audit，所有网络连接禁用，复用原模型响应。completed分支保护也在副本中验证，不能改成对真实旧目录重新启动。

## 结果范围

- results/independent_review.json：文件、账本、回执和独立评分。
- results/native_replay_verification.json：原生执行与原报告重建。
- results/failure_evidence.json：8条含重复的失败轨迹证据，主结果只有4条、来自2个条件。
- results/posthoc_observability.json：4次只读诊断和2次参数反事实，绝不是新LLM结果。
- docs/：中文报告、事实更正和英文增补段落。
- logs/：红灯、绿灯、证据破坏测试与执行时限日志均保留。

时间与UUID等字段只在明示的原生重放机制下处理；原始HTTP正文不删改。文件摘要不能认证服务商权重或账单；同一助手的独立实现不等于独立人类同行审稿。不授权后续实验或投稿。
