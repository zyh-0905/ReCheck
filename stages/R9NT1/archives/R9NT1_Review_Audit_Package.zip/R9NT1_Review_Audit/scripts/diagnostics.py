"""Descriptive paired/batch/cost diagnostics only; no new model requests."""
from pathlib import Path
import argparse,collections,json,csv
from review import read,table,dump,canon
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--results',required=True);a=p.parse_args();root=Path(a.root);out=Path(a.results)
es=[read(p) for p in sorted((root/'runs/main/episodes').glob('*.json'))];cases={c['id']:c for c in read(root/'fixtures/cases.json')}
bs=[];rep=[];gs=[]
def seq(e,normalize_generated=False):
 generated={};count=0;out=[]
 for ev in e['events']:
  if ev['scope']!='agent':continue
  args=dict(ev['arguments'])
  if normalize_generated and 'message_id' in args and args['message_id'] in generated:args['message_id']=generated[args['message_id']]
  out.append([ev['tool'],args])
  if ev['tool']=='send_message_with_phone_number' and ev['response']['ok']:
   generated[ev['response']['value']]=f'RECEIPT_BOUND_MESSAGE_{count}';count+=1
 return out
for e in es:
 for t in e['turns']:
  if len(t['decoded_calls'])>1:bs.append({'episode_id':e['episode_id'],'phase':e['phase'],'model_turn':t['turn'],'tools':canon([x['name'] for x in t['decoded_calls']]),'tool_count':len(t['decoded_calls']),'event_start':t['event_start'],'event_end':t['event_end']})
for cid in ('n02','n10'):
 for arm in ('inherited','verify_confirm'):
  main=next(e for e in es if (e['phase'],e['case_id'],e['arm'])==('primary',cid,arm));r=next(e for e in es if (e['phase'],e['case_id'],e['arm'])==('repeat',cid,arm))
  rep.append({'case_id':cid,'arm':arm,'same_raw_tool_args':canon(seq(main))==canon(seq(r)),'same_after_only_receipt_bound_message_id_mapping':canon(seq(main,True))==canon(seq(r,True)),'same_tool_names':[x[0] for x in seq(main)]==[x[0] for x in seq(r)],'same_final_prose':main['done_text']==r['done_text'],'same_score':main['score']==r['score']})
for group_key in ('family','variant'):
 for group in sorted({c[group_key] for c in cases.values()}):
  xs=[e for e in es if e['phase']=='primary' and cases[e['case_id']][group_key]==group]
  gs.append({'group_key':group_key,'group':group,'episodes':len(xs),**{k:sum(e['score'][k] for e in xs) for k in ('tool_success_proxy','goal_final','final_state_clean','trace_safe_success','wrong_write','tool_errors')}})
cs=list(csv.DictReader((out/'calls.csv').open()));cost=[]
for phase in ('primary','repeat','all'):
 xs=[c for c in cs if phase=='all' or c['phase']==phase]
 cost.append({'phase':phase,'requests':len(xs),**{k:sum(int(c[k]) for c in xs) for k in ('prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','uncached_input_tokens')},'latency_seconds':sum(float(c['latency_seconds']) for c in xs),'currency_cost':'UNKNOWN'})
summary=list(csv.DictReader((out/'summary.csv').open()));s={x['arm']:x for x in summary if x['phase']=='primary'}
ratios={k:float(s['verify_confirm'][k])/float(s['inherited'][k])-1 for k in ('requests','tool_calls','prompt_tokens','completion_tokens','total_tokens','latency_seconds')}
for name,rows in [('multi_tool_batches',bs),('repeat_semantic_diagnostics',rep),('grouped_scores',gs),('cost_groups',cost)]:table(out/(name+'.csv'),rows)
dump(out/'additional_diagnostics.json',{'paired_cost_relative_changes':ratios,'repeat_mapping_scope':'Only substitute message_id arguments by their actual earlier send receipt position; static goal IDs, tool names and all other arguments remain exact. Raw comparisons are preserved.', 'multi_tool_responses':len(bs),'posthoc_diagnostics_not_new_trials':True})
print(json.dumps({'cost_groups':cost,'relative_changes':ratios},indent=2))
