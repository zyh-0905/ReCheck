"""POST-HOC native read-only observability / sparse-write diagnostics.
Not live-model continuations, not included in original performance scores.
Run with the supplied Python3.11 native dependencies and original kit on PYTHONPATH.
"""
from pathlib import Path
import argparse,json,sys,copy,socket
from independent import evaluate,canon
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root)
sys.path[:0]=[str(root),str(root/'vendor/toolsandbox')]
def blocked(*a,**k):raise RuntimeError('no network in posthoc native diagnostics')
socket.socket.connect=blocked;socket.socket.connect_ex=blocked;socket.create_connection=blocked
from legacy.native import NativeSession
from legacy.timeline import Timeline
cases={c['id']:c for c in json.loads((root/'fixtures/cases.json').read_text())}
reads=[];sparse=[]
for cid in ('n02','n10'):
 for arm in ('inherited','verify_confirm'):
  eid='primary_'+cid+'_'+arm;e=json.loads((root/'runs/main/episodes'/f'{eid}.json').read_text());c=cases[cid]
  ns=NativeSession(e['final_snapshot']);b=ns.world()
  tool,args=('search_contacts',{'name':c['contract']['name']}) if cid=='n02' else ('search_reminder',{'content':c['contract']['title']})
  response=ns.call(tool,args);assert canon(ns.world())==canon(b)
  if cid=='n02':relevant=[r for r in response['value'] if r['name']==c['contract']['name']]
  else:relevant=[r for r in response['value'] if r['content']==c['contract']['title']]
  reads.append({'episode_id':eid,'tool':tool,'arguments':args,'response':response,'exact_matches':relevant,'business_state_unchanged':True,'kind':'POSTHOC_READ_NOT_MODEL_ACTION'})
  if cid=='n10':
   tl=Timeline(c,replay_events=e['events'])
   for ev in e['events']:
    if ev['scope']!='agent':continue
    if ev['tool']=='modify_reminder':break
    tl.call(ev['tool'],ev['arguments'])
   assert canon(tl.world())==canon(ev['before_world'])
   tl.replay_events=None
   args={k:v for k,v in ev['arguments'].items() if k in ('reminder_id','reminder_timestamp')}
   write_result=tl.call('modify_reminder',args);read_result=tl.call('search_reminder',{'reminder_id':args['reminder_id']})
   s=evaluate(c['public']['user_request'],c['world_before'],tl.events,tl.world())
   sparse.append({'episode_id':eid,'kind':'POSTHOC_ARGUMENT_ABLATION_NOT_MODEL_CONTINUATION','original_arguments':ev['arguments'],'sparse_arguments':args,'write_response':write_result,'id_readback':read_result,'counterfactual_score':s,'original_score_unchanged':e['score'],'events':tl.events})
out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps({'posthoc':True,'new_llm_calls':0,'not_added_to_primary_results':True,'reads':reads,'sparse_writes':sparse},ensure_ascii=False,indent=2)+'\n')
print('4 native read-only observability checks; 2 sparse-write counterfactuals. No new model results.')
for s in sparse:print(s['episode_id'],s['id_readback']['value'][0]['content'],s['counterfactual_score']['trace_safe_success'])
