"""Read-only R9NT1 audit: hashes, raw ledger, native receipt chain and independent scores.
Usage: python scripts/review.py --feedback USER.zip --kit Research_Handoff_R9NT1.zip --out results
Accepts already extracted roots too. Does not import the experiment or access a network.
"""
from pathlib import Path,PurePosixPath
import argparse,ast,collections,copy,csv,hashlib,io,json,math,stat,tempfile,zipfile
from independent import canon,decode,evaluate,parse_task,usage
KIT_SHA='e8686e52224b7d2ff454bdf521a72855f90925dfbe1dc96b0c6c64bb8bc7ad83'

def sha(b):return hashlib.sha256(b).hexdigest()
def digest(x):return sha(canon(x).encode())
def read(p):return decode(Path(p).read_text())
def same(a,b,label):
 if canon(a)!=canon(b):raise ValueError('Mismatch: '+label)
def require(value,label):
 if not value:raise ValueError('Rejected: '+label)
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')
def table(p,rows):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',newline='',encoding='utf8') as f:
  fields=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def unzip(raw,dest):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  require(len(z.namelist())==len(set(z.namelist())),'duplicate zip names')
  require(sum(i.file_size for i in z.infolist())<150_000_000,'archive size cap')
  for i in z.infolist():
   n=PurePosixPath(i.filename)
   require(not n.is_absolute() and '..' not in n.parts and '\\' not in i.filename,'archive path')
   require(stat.S_IFMT(i.external_attr>>16)!=stat.S_IFLNK,'archive symlink')
  z.extractall(dest)
def feedback_root(p,temp):
 p=Path(p)
 if p.is_dir():return p,None,None
 raw=p.read_bytes();outer_sha=sha(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  candidates=[n for n in z.namelist() if PurePosixPath(n).name.startswith('R9NT1_feedback_') and n.endswith('.zip') and not n.startswith('__MACOSX/')]
  if candidates:
   require(len(candidates)==1,'one inner feedback only');raw=z.read(candidates[0])
 unzip(raw,temp/'feedback');return temp/'feedback',outer_sha,sha(raw)
def kit_root(p,temp):
 p=Path(p)
 if p.is_dir():return p
 raw=p.read_bytes();require(sha(raw)==KIT_SHA,'approved kit archive hash')
 unzip(raw,temp/'kit');dirs=[p for p in (temp/'kit').iterdir() if p.is_dir()]
 require(len(dirs)==1,'kit root');return dirs[0]
def function_constants(p):
 out={}
 for a in ast.parse(p.read_text()).body:
  if isinstance(a,ast.Assign) and len(a.targets)==1 and isinstance(a.targets[0],ast.Name) and a.targets[0].id in ('BASE','VERIFY'):out[a.targets[0].id]=ast.literal_eval(a.value)
 require(set(out)=={'BASE','VERIFY'},'prompt literals');return out

def review(root,kit,out):
 root,kit,out=Path(root),Path(kit),Path(out);out.mkdir(parents=True,exist_ok=True)
 bm=read(root/'BUNDLE_MANIFEST.json')['files'];expected=set(bm)|{'BUNDLE_MANIFEST.json'}
 same(sorted(p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()),sorted(expected),'complete file set')
 for rel,meta in bm.items():
  p=root/rel;require(not p.is_symlink(),'file symlink');same({'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())},meta,'bundle '+rel)
 sm=read(kit/'SOURCE_MANIFEST.json');same(read(root/'SOURCE_MANIFEST.json'),sm,'source manifest')
 for rel,meta in sm['files'].items():
  require((root/rel).read_bytes()==(kit/rel).read_bytes(),'source '+rel)
  same({'bytes':(root/rel).stat().st_size,'sha256':sha((root/rel).read_bytes())},meta,'source size/hash')
 cfg=read(root/'config.json');proto=read(root/'protocol.json');prep=read(root/'PREPARED.json')
 source=digest(sm);binding=digest({'source':source,'config':cfg,'protocol':proto})
 same(prep['binding'],binding,'prepared binding');same(prep['source_manifest_sha256'],source,'prepared source')
 same(prep['config'],cfg,'prepared config');same(prep['protocol'],proto,'prepared protocol')
 run=root/'runs/main';manifest=read(run/'manifest.json');status=read(run/'status.json');identity=read(run/'endpoint_identity.json')
 same(manifest['binding'],binding,'run binding');same(manifest['config'],cfg,'run config');same(manifest['protocol'],proto,'run protocol')
 same(manifest['evidence_kind'],'REAL_ENDPOINT_NATIVE_CONTINUATION','run evidence kind');same(status['status'],'completed','expected completed feedback')
 cases={x['id']:x for x in read(root/'fixtures/cases.json')};schedule=read(root/'fixtures/schedule.json');tools=read(root/'fixtures/tools.json');tool_names={x['function']['name'] for x in tools}
 const=function_constants(kit/'nt/prompts.py');attempts=run/'attempts';reqs=sorted(attempts.glob('*_request.json'));require(len(reqs)<=360,'request budget')
 same(len(list(attempts.iterdir())),4*len(reqs),'four ledger files per request')
 records={};call_rows=[];raw_ids=set();native_ids=set();fingerprints=set();finish=collections.Counter();batches=collections.Counter()
 for number,p in enumerate(reqs,1):
  same(p.name,f'{number:06d}_request.json','ordered ledger')
  q=read(p);r=read(attempts/f'{number:06d}_response.json');s=read(attempts/f'{number:06d}_send_intent.json');raw=(attempts/f'{number:06d}_response.raw').read_bytes()
  for k,v in q.items():same(v,r[k],'request/response '+k)
  same(q['attempt'],number,'attempt');same(s['attempt'],number,'send intention')
  same(sha(raw),r['raw_stored_sha256'],'raw stored sha');require(r['secret_redacted'] is False,'no redaction expected');same(sha(raw),r['raw_original_sha256'],'original body sha')
  b=decode(raw.decode('utf8'));same(b,r['response'],'parsed raw response');same(r['http_status'],200,'http success');same(r['status'],'received','response received')
  same(q['payload_sha256'],digest(q['payload']),'payload sha');same(q['request_sha256'],digest({'endpoint':cfg['endpoint'],'payload':q['payload']}),'endpoint sha')
  require(b['id'] not in raw_ids,'response ID reuse');raw_ids.add(b['id']);fingerprints.add(b['system_fingerprint'])
  require(isinstance(b['system_fingerprint'],str) and bool(b['system_fingerprint'].strip()),'fingerprint')
  same({'requested_model':cfg['model'],'returned_model':b['model'],'system_fingerprint':b['system_fingerprint'],'weight_identity_verified':False},identity,'recorded identity')
  require(type(b['choices']) is list and len(b['choices'])==1,'one choice');ch=b['choices'][0];same(ch['index'],0,'choice index')
  m=ch['message'];same(m['role'],'assistant','assistant role');require('reasoning_content' in m,'reasoning available')
  tc=m.get('tool_calls') or [];require(type(tc) is list and len(tc)<=4,'batch cap');finish[ch['finish_reason']]+=1
  if tc:
   same(ch['finish_reason'],'tool_calls','tool finish');batches[len(tc)]+=1
   for c in tc:
    require(c['type']=='function' and c['function']['name'] in tool_names,'allowed structured tool')
    require(type(c['id']) is str and bool(c['id']),'call id')
    native_ids.add(c['id']);a=decode(c['function']['arguments']);require(type(a) is dict,'argument object')
  else:same(ch['finish_reason'],'stop','final finish');require(type(m['content']) is str and bool(m['content'].strip()),'final content')
  u=usage(b['usage']);elapsed=r['latency_seconds'];require(type(elapsed) in (int,float) and math.isfinite(elapsed) and elapsed>=0,'finite timing')
  lid=q['logical_id'];require(lid not in records,'logical id duplicated');records[lid]=(q,r,m,tc)
  call_rows.append({'attempt':number,'logical_id':lid,**q['metadata'],'response_id':b['id'],'returned_model':b['model'],'system_fingerprint':b['system_fingerprint'],'finish_reason':ch['finish_reason'],'tool_calls':len(tc),**u,'latency_seconds':elapsed,'monetary_cost':'UNKNOWN'})
 episodes=[];e_rows=[];receipts=[];exposure_rows=[];evidence=[];actual_order=[];rebuilt_status=[]
 for sp in schedule:
  e=read(run/'episodes'/f'{sp["episode_id"]}.json');c=cases[sp['case_id']]
  for k,v in sp.items():same(e[k],v,'episode binding')
  same(e['case_sha256'],digest(c),'case hash');same(e['public_input_sha256'],digest(c['public']),'public hash')
  same(parse_task(c['public']['user_request']),c['contract'],'public-derived intent')
  msgs=[{'role':'system','content':const['BASE']+('\n'+const['VERIFY'] if sp['arm']=='verify_confirm' else '')},{'role':'user','content':canon(c['public'])}]
  same(msgs,e['initial_messages'],'public messages no oracle');count=0;used=set();links={};seen_events=set();identity_mismatch=[]
  require(1<=len(e['turns'])<=10,'episode turn budget')
  for j,t in enumerate(e['turns']):
   lid=sp['episode_id']+f'/turn_{j:02d}';same(lid,t['logical_id'],'logical sequence');actual_order.append(lid)
   q,r,m,tc=records[lid]
   same(q['metadata'],{**sp,'turn':j},'metadata')
   same(q['payload'],{'model':cfg['model'],'messages':msgs,'tools':tools,'tool_choice':'auto','stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high'},'independent full payload reconstruction')
   same(t['request_sha256'],q['request_sha256'],'turn request hash')
   visible={k:copy.deepcopy(m[k]) for k in ('role','content','reasoning_content','tool_calls') if k in m};same(visible,t['assistant_message'],'assistant history')
   decoded=[]
   for z in tc:
    require(z['id'] not in used,'call id repeated within episode');used.add(z['id']);decoded.append({'id':z['id'],'name':z['function']['name'],'arguments':decode(z['function']['arguments'])})
   same(decoded,t['decoded_calls'],'decoded calls');same(t['kind'],'tools' if tc else 'final','turn kind');msgs.append(visible)
   require(len(t['executions'])==len(tc),'each structural call executed once')
   same(len(t['tool_messages']),len(tc),'all replies present')
   for k,(x,ex) in enumerate(zip(decoded,t['executions'])):
    same(ex['batch_index'],k,'batch index');same(ex['tool_call_id'],x['id'],'execution id')
    begin,end=ex['event_start'],ex['event_end'];require(end>begin,'execution event window')
    require(not (set(range(begin,end))&seen_events),'overlapping tool windows');seen_events.update(range(begin,end))
    ev=e['events'][begin];same(ev['scope'],'agent','native event scope');same(ev['tool'],x['name'],'native tool name');same(ev['arguments'],x['arguments'],'native arguments')
    for h in range(begin,end):links[h]={'model_turn':j,'batch_index':k,'tool_call_id':x['id']}
    for follow in e['events'][begin+1:end]:same(follow['scope'],'environment','post-read event window')
    rep={'role':'tool','tool_call_id':x['id'],'content':canon(ev['response'])};same(t['tool_messages'][k],rep,'real tool result content/ID');msgs.append(rep);count+=1;same(ex['outer_tool_count'],count,'outer count')
    receipts.append({'episode_id':e['episode_id'],'phase':e['phase'],'model_turn':j,'batch_index':k,'tool_call_id':x['id'],'tool':x['name'],'event_index':begin,'reply_sha256':digest(ev['response']),'reply_in_next_request':j+1<len(e['turns'])})
   if not tc:require(j==len(e['turns'])-1,'no calls after final')
  same(e['final_messages'],msgs,'entire final transcript');same(e['model_calls'],len(e['turns']),'request count');same(e['tool_calls'],count,'tool count');require(count<=40,'tool budget')
  same(e['terminated'],not bool(e['turns'][-1]['decoded_calls']),'termination');same(e['stop_reason'],'final' if e['terminated'] else 'request_cap','stop reason')
  score=evaluate(c['public']['user_request'],c['world_before'],e['events'],e['after_world']);same(score,e['score'],'independent score including violations')
  agent=[i for i,v in enumerate(e['events']) if v['scope']=='agent'];environment=[i for i,v in enumerate(e['events']) if v['scope']=='environment']
  same(count,len(agent),'all agent events counted');same(e['environment_operations'],len(environment),'environment operation count')
  # Reconstruct declared one-shot trigger, independent of the original Timeline.
  expected_ops=c['unrelated_operations'] if c['variant']=='post_unrelated' else c['relevant_operations']
  eligible=[]
  for i in agent:
   v=e['events'][i]
   if v['tool']==c['primary_mutator']:break
   qualifies=v['tool'] in c['anchors'] and v['response']['ok'] is True
   val=v['response']['value']
   if c['family']=='person':qualifies=qualifies and type(val) is list and any(r.get('name')==c['contract']['name'] for r in val)
   elif c['family']=='reminder':qualifies=qualifies and type(val) is list and any(r.get('content')==c['contract']['title'] for r in val)
   if qualifies:eligible.append(i);break
  planned=c['variant']!='stable';pre=c['variant']=='pre_relevant';should=pre or (c['variant'].startswith('post_') and bool(eligible))
  same(e['exposure']['scheduled'],planned,'event scheduled');same(e['exposure']['triggered'],should,'event triggered')
  if should:
   start=0 if pre else eligible[0]+1;expected_indices=list(range(start,start+len(expected_ops)));same(environment,expected_indices,'exact event timing')
   for ei,op in zip(environment,expected_ops):same([e['events'][ei]['tool'],e['events'][ei]['arguments']],op,'frozen event operations')
  else:same(environment,[],'no forced exposure')
  same(len(agent)+len(environment),len(e['events']),'scope count')
  for i in agent:require(i in seen_events,'unattached agent event')
  writes=[i for i in agent if e['events'][i]['tool']==c['primary_mutator']]
  same_batch=None
  if not pre and should and writes:
   same_batch=links[eligible[0]]['model_turn']==links[writes[0]]['model_turn']
  er={**sp,'family':c['family'],'variant':c['variant'],'scheduled':planned,'triggered':should,'environment_operations':len(environment),'first_anchor_index':eligible[0] if eligible else None,'environment_indices':canon(environment),'first_primary_write_index':writes[0] if writes else None,'post_read_to_write_same_response':same_batch}
  exposure_rows.append(er)
  row={**sp,'family':c['family'],'variant':c['variant'],**{k:v for k,v in score.items() if k!='violations'},'model_calls':len(e['turns']),'tool_calls':count,'terminated':e['terminated'],'exposed':should,'elapsed_seconds':e['elapsed_seconds']}
  e_rows.append(row);episodes.append(e);rebuilt_status.append({**sp,'score':score,'model_calls':len(e['turns']),'tool_calls':count,'terminated':e['terminated'],'exposure':e['exposure']})
  if score['wrong_write']:
   evidence.append({'episode_id':e['episode_id'],'phase':e['phase'],'user_request':c['public']['user_request'],'contract':parse_task(c['public']['user_request']),'score':score,'exposure':er,'tool_sequence':[{'event_index':i,'model_turn':links[i]['model_turn'],'batch_index':links[i]['batch_index'],'tool':e['events'][i]['tool'],'arguments':e['events'][i]['arguments'],'response':e['events'][i]['response']} for i in agent], 'environment_changes':[{'event_index':i,'tool':e['events'][i]['tool'],'arguments':e['events'][i]['arguments']} for i in environment], 'violation_transitions':[{'event_index':v['event_index'],'before':e['events'][v['event_index']]['before_world'],'after':e['events'][v['event_index']]['after_world']} for v in score['violations'] if v['event_index'] is not None], 'final_world':e['after_world'],'final_prose':e['done_text']})
 same(actual_order,list(records),'request schedule order');same(status['completed_episodes'],rebuilt_status,'all status outcomes');same(status['recorded_attempts'],len(records),'status count')
 same(len(episodes),36,'all planned episodes');same(len(list((run/'episodes').glob('*.json'))),36,'no extra episodes');same(len(e_rows),36,'rows')
 summaries=[]
 for phase in ('primary','repeat'):
  for arm in ('inherited','verify_confirm'):
   es=[e for e in e_rows if e['phase']==phase and e['arm']==arm];cs=[r for r in call_rows if r['phase']==phase and r['arm']==arm]
   summaries.append({'phase':phase,'arm':arm,'episodes':len(es),**{k:sum(x[k] for x in es) for k in ('tool_success_proxy','goal_final','final_state_clean','trace_safe_success','wrong_write','goal_only_false_accept','final_clean_false_accept','tool_errors','tool_calls','terminated')},'requests':len(cs),**{k:sum(x[k] for x in cs if x[k] is not None) for k in ('prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','uncached_input_tokens','latency_seconds')},'monetary_cost':'UNKNOWN'})
 repeats=[]
 for cid in ('n02','n10'):
  for arm in ('inherited','verify_confirm'):
   main=next(e for e in episodes if (e['phase'],e['case_id'],e['arm'])==('primary',cid,arm));again=next(e for e in episodes if (e['phase'],e['case_id'],e['arm'])==('repeat',cid,arm))
   seq=lambda e:[(v['tool'],v['arguments']) for v in e['events'] if v['scope']=='agent']
   repeats.append({'case_id':cid,'arm':arm,'same_initial_messages':canon(main['initial_messages'])==canon(again['initial_messages']),'same_tools_and_arguments':canon(seq(main))==canon(seq(again)),'same_final_prose':main['done_text']==again['done_text'],'same_scores':main['score']==again['score'],'primary_calls':main['model_calls'],'repeat_calls':again['model_calls']})
 pairs=[]
 for cid,c in cases.items():
  a,z=[next(e for e in e_rows if (e['phase'],e['case_id'],e['arm'])==('primary',cid,arm)) for arm in ('inherited','verify_confirm')]
  pairs.append({'case_id':cid,'family':c['family'],'variant':c['variant'],**{arm+'_'+k:e[k] for arm,e in [('inherited',a),('verify_confirm',z)] for k in ('trace_safe_success','goal_final','final_state_clean','wrong_write','model_calls','tool_calls')},'extra_model_calls':z['model_calls']-a['model_calls'],'extra_tool_calls':z['tool_calls']-a['tool_calls']})
 result={'accepted_internal_integrity':True,'execution_complete':True,'source_files':len(sm['files']),'upstream_files':sum(k.startswith('vendor/toolsandbox/') for k in sm['files']),'bundle_data_files':len(bm),'bundle_total_files':len(bm)+1,'requests':len(call_rows),'primary_episodes':sum(e['phase']=='primary' for e in e_rows),'repeat_episodes':sum(e['phase']=='repeat' for e in e_rows),'native_tool_events':len(receipts),'environment_operations':sum(e['environment_operations'] for e in episodes),'raw_response_ids_unique':len(raw_ids),'global_unique_tool_call_ids':len(native_ids),'finish_reasons':dict(finish),'tool_batch_sizes':dict(batches),'receipt_links':len(receipts),'all_receipts_in_next_model_request':all(x['reply_in_next_request'] for x in receipts),'returned_identity':identity,'new_remote_llm_calls':0,'monetary_cost':'UNKNOWN','status_elapsed_seconds':status['elapsed_seconds'],'started_utc':status['started_utc'],'ended_utc':status['ended_utc'],'environment_reported_not_authenticated':prep['environment'],'primary_final_vs_trace_disagreements':sum(e['goal_final']!=e['trace_safe_success'] for e in e_rows if e['phase']=='primary'),'primary_clean_vs_trace_disagreements':sum(e['final_state_clean']!=e['trace_safe_success'] for e in e_rows if e['phase']=='primary')}
 for name,rows in [('calls',call_rows),('episodes',e_rows),('summary',summaries),('exposure',exposure_rows),('receipt_links',receipts),('repeats',repeats),('paired',pairs)]:table(out/(name+'.csv'),rows)
 dump(out/'independent_review.json',result);dump(out/'failure_evidence.json',evidence)
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--feedback',required=True);p.add_argument('--kit',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 import socket
 def blocked(*args,**kwargs):raise RuntimeError('network forbidden in review')
 socket.socket.connect=blocked;socket.socket.connect_ex=blocked;socket.create_connection=blocked
 with tempfile.TemporaryDirectory(prefix='r9nt1-audit-') as td:
  root,outer,inner=feedback_root(a.feedback,Path(td));kit=kit_root(a.kit,Path(td));r=review(root,kit,a.out)
  dump(Path(a.out)/'input_binding.json',{'feedback_outer_sha256':outer,'feedback_inner_sha256':inner,'approved_kit_sha256':KIT_SHA})
  print(json.dumps(r,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
