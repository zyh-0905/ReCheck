"""Optional unchanged-engine replay in a temporary copy; requires original Python3.11 deps.
No model calls. Never execute the original run command against live endpoints.
"""
from pathlib import Path
import argparse,shutil,sys,tempfile,json,socket,getpass
from review import feedback_root,kit_root,read,sha,dump
p=argparse.ArgumentParser();p.add_argument('--feedback',required=True);p.add_argument('--kit',required=True);p.add_argument('--out',required=True);a=p.parse_args()
sys.dont_write_bytecode=True
def blocked(*a,**k):raise RuntimeError('network disabled throughout replay')
socket.socket.connect=blocked;socket.socket.connect_ex=blocked;socket.create_connection=blocked
getpass.getpass=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('no key reading during replay'))
with tempfile.TemporaryDirectory(prefix='r9nt1-native-audit-') as tmp:
 t=Path(tmp);fb,_,_=feedback_root(a.feedback,t);k=kit_root(a.kit,t);root=t/'work';shutil.copytree(k,root);shutil.copytree(fb/'runs',root/'runs');shutil.copy2(fb/'PREPARED.json',root/'PREPARED.json')
 sys.path[:0]=[str(root),str(root/'vendor/toolsandbox')]
 from nt.audit import audit
 from nt.runtime import run_study
 result=audit(root);assert result['mechanical_pass'] and result['execution_complete']
 comparisons={p.name:p.read_bytes()==(root/'runs/review'/p.name).read_bytes() for p in (fb/'runs/review').iterdir() if p.is_file()}
 assert all(comparisons.values());assert read(root/'runs/AUDIT.json')==read(fb/'runs/AUDIT.json')
 before={p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()};status=run_study(root,360)
 after={p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()};assert before==after
 result.update(saved_report_bytes_equal=comparisons,completed_run_did_not_resample=True,completed_branch_files_unchanged=True)
 dump(Path(a.out),result);print(json.dumps(result,indent=2))
