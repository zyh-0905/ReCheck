# R9首次主响应格式暂停：审计与修订证据

本包不是新用户运行任务。真实原始证据为2份响应，0个完整任务回合；software_fixtures下全部是本地HTTP软件测试，不是模型研究结果。

## 标准库复核
```bash
python -m unittest discover -s tests -v
python scripts/audit_received.py
```
重建原包清单、绑定、两次请求账本、使用量、初始边界和便利副本，不发模型请求。派生results可重算；inputs原始数据不能修改。

## 原生复核
使用Python3.11及原R9 requirements固定版本运行：
```bash
python scripts/native_audit.py
```
脚本优先加载本研究端runtime目录（如存在），也可使用已经安装依赖的Python3.11环境。原生部分导入未修改的原工具代码，用已记录响应复现解析暂停与现场。不会执行响应中描述的两个动作。
当前环境所用轮子来自此前已核验材料；runtime与依赖二进制不重复打包。restore_runtime.py保留研究端恢复步骤及该环境路径，仅供审查，不要求用户再下载或运行。

## 修订
amendment内为R9J1完整新包，必须另解压到全新目录后显式用户确认才进行真实模型调用。它只把response_format=json_object添加到全部请求；任务提示、工具、环境变化、评分、cap不变。原R9格式违规记录不删除、不修复、不导入为新回合。

## 限制
哈希与重放不认证服务商权重、收费、用户所有历史命令或独立人类审阅。原自动AUDIT机械通过不是研究完成。资金成本保持UNKNOWN。
