from pathlib import Path
import sys,json,socket,shutil,tempfile
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'inputs/original/R9_Research_Kit';F=ROOT/'inputs/feedback'
sys.path[:0]=[str(ROOT/'runtime/deps'),str(ROOT/'runtime/sdist/rouge_score-0.1.2'),str(O),str(O/'vendor/toolsandbox')]
def deny(*a,**k):raise RuntimeError('Offline audit; network denied')
socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny
from pilot.common import read_json as j,request_payload,digest
from r9lib.prompts import initial_messages,episode_schedule
from r9lib.timeline import Timeline
from r9lib.transport import Client
from pilot.client import RunStopped
from r9lib.audit import audit
from r9lib.runtime import can_start
spec=episode_schedule()[0];assert spec['episode_id']=='primary_n06_verify_confirm'
case=next(c for c in j(O/'fixtures/cases.json') if c['id']==spec['case_id']);t=Timeline(case)
b=j(F/'runs/R9_main/partial'/spec['episode_id']/'boundary.json')
assert b['world']==t.world() and b['snapshot']==t.snapshot() and b['exposure']==t.exposure()
msgs=initial_messages(case['public'],spec['arm']);assert msgs==b['messages']
prep=j(F/'PREPARED.json');main=j(F/'runs/R9_main/attempts/000001_result.json')
assert main['payload']==request_payload(prep['config'],msgs)
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp);d=tmp/'validation';d.mkdir()
 shutil.copy(F/'runs/R9_main/endpoint_identity.json',d/'endpoint_identity.json')
 c=Client(prep['config'],d)
 try:c._validate_saved(main)
 except RunStopped as e:original_error=str(e)
 else:raise AssertionError('Original validator must reject retained malformed output')
 assert original_error=='Invalid JSON response preserved. Paused, not automatically repaired.'
 assert not list((d/'attempts').glob('*_start.json'))
 reconstructed=tmp/'reconstructed';shutil.copytree(O,reconstructed,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 shutil.copytree(F/'runs',reconstructed/'runs');shutil.copy(F/'PREPARED.json',reconstructed/'PREPARED.json')
 r=audit(reconstructed);assert r==j(F/'offline_reports/AUDIT.json')
 assert (reconstructed/'offline_reports/calls.csv').read_bytes()==(F/'offline_reports/calls.csv').read_bytes()
 try:can_start(reconstructed,'R9_main')
 except ValueError as e:refusal=str(e)
 else:raise AssertionError('Paused run incorrectly admitted')
 res={'original_audit_equal':True,'original_calls_csv_equal':True,'reconstructed_requests_including_incomplete_first_turn':2,
  'native_initial_snapshot_equal':True,'events_applied':len(t.events),'tools_applied':0,
  'original_json_error_reproduced':original_error,'paused_run_start_refusal':refusal,
  'new_remote_calls':0,'new_scientific_samples':0}
 (ROOT/'results/native_audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
