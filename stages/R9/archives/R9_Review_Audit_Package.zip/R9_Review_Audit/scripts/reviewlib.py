"""Standard-library audit helpers. Never execute model output or import the runner."""
import json,hashlib,math

def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def strict_object(text):
 if type(text) is not str:raise ValueError('Expected text')
 def unique(pairs):
  d={}
  for k,v in pairs:
   if k in d:raise ValueError('Duplicate JSON key')
   d[k]=v
  return d
 def bad(s):raise ValueError('Nonfinite JSON')
 obj=json.loads(text,object_pairs_hook=unique,parse_constant=bad)
 if type(obj) is not dict:raise ValueError('Object required')
 canonical(obj) # rejects overflowed floats including nested values
 return obj

def integer(x):
 if type(x) is not int or x<0:raise ValueError('Expected nonnegative integer')
 return x

def check_usage(u):
 if type(u) is not dict:raise ValueError('Usage missing')
 p,c,t=[integer(u.get(k)) for k in ('prompt_tokens','completion_tokens','total_tokens')]
 if p+c!=t:raise ValueError('Token conservation')
 reasoning=integer((u.get('completion_tokens_details') or {}).get('reasoning_tokens',0))
 cached=integer(u.get('prompt_cache_hit_tokens',(u.get('prompt_tokens_details') or {}).get('cached_tokens',0)))
 if reasoning>c or cached>p:raise ValueError('Token component exceeds total')
 if 'prompt_cache_miss_tokens' in u and integer(u['prompt_cache_miss_tokens'])+cached!=p:raise ValueError('Cache conservation')
 return dict(prompt_tokens=p,completion_tokens=c,total_tokens=t,reasoning_tokens=reasoning,cached_input_tokens=cached)

def check_request_record(s,r,endpoint):
 for k in ('attempt','logical_id','payload','payload_sha256','request_sha256','metadata','started_utc'):
  if canonical(s[k])!=canonical(r[k]):raise ValueError('Ledger changed: '+k)
 if s['payload_sha256']!=digest(s['payload']):raise ValueError('Payload digest')
 if s['request_sha256']!=digest({'endpoint':endpoint,'payload':s['payload']}):raise ValueError('Request digest')
 if r['status']!='ok':raise ValueError('Not a received response')
 b=r['response'];choices=b.get('choices')
 if type(choices) is not list or len(choices)!=1:raise ValueError('Expected one choice')
 if r['text']!=choices[0]['message']['content']:raise ValueError('Text is not original content')
 if type(r['latency_seconds']) not in (int,float) or not math.isfinite(r['latency_seconds']) or r['latency_seconds']<0:raise ValueError('Invalid timing')
 valid=True;error=None
 try:strict_object(r['text'])
 except (ValueError,TypeError) as e:valid=False;error=str(e)
 return {**check_usage(b['usage']),'valid_object':valid,'json_error':error,'finish_reason':choices[0].get('finish_reason'),
  'response_id':b['id'],'returned_model':b['model'],'system_fingerprint':b.get('system_fingerprint'),
  'requested_model':s['payload']['model'],'response_format':s['payload'].get('response_format'),
  'text_characters':len(r['text']),'latency_seconds':r['latency_seconds']}
