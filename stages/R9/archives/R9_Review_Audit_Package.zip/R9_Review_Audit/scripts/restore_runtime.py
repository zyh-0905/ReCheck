from pathlib import Path,PurePosixPath
import zipfile,io,json,hashlib,tarfile,stat
R=Path('/mnt/data/R9_Review_Work/runtime');R.mkdir(parents=True,exist_ok=True)
source=Path('/mnt/data/be0c8748-7cf7-4095-8e92-699f71d9a566.zip')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='d2afe3ee01d58122844e7b7fc67ca1c8a32ace0f72ff87b47dd641e7c161aa53'
with zipfile.ZipFile(source) as outer:
 n=next(n for n in outer.namelist() if n.endswith('.zip') and not n.startswith('__MACOSX/'))
 z=zipfile.ZipFile(io.BytesIO(outer.read(n)))
 m=json.loads(z.read('BUNDLE_MANIFEST.json'))['files']
 for name in z.namelist():
  if not name.startswith(('runtime/','packages/')):continue
  b=z.read(name);assert hashlib.sha256(b).hexdigest()==m[name]['sha256'] and len(b)==m[name]['bytes']
  if name.startswith('runtime/'):
   with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:t.extractall(R,filter='data')
  elif name.endswith('.whl'):
   with zipfile.ZipFile(io.BytesIO(b)) as w:
    for i in w.infolist():
     p=PurePosixPath(i.filename)
     assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(i.external_attr>>16)
     if i.is_dir():continue
     q=R/'deps'/i.filename;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(w.read(i))
  elif name.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:t.extractall(R/'sdist',filter='data')
print('Restored validated runtime + 52 wheels + rouge-score source; not claiming pip install')
