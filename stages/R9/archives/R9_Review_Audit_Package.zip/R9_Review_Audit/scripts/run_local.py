"""Run pinned native scripts with no non-loopback networking or model credentials."""
from pathlib import Path
import sys,os,socket,runpy
BASE=Path(__file__).resolve().parents[1]
kit=Path(sys.argv[1]).resolve();target=sys.argv[2];args=sys.argv[3:]
sys.path[:0]=[str(kit),str(kit/'vendor/toolsandbox'),str(BASE/'runtime/deps'),str(BASE/'runtime/sdist/rouge_score-0.1.2')]
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['POLARS_MAX_THREADS']='1'
old=socket.socket.connect;old_ex=socket.socket.connect_ex
# Only test fixtures may connect to local test servers. Remote API and DNS are not needed.
def safe(self,address):
 if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1','localhost'):return old(self,address)
 raise RuntimeError('Non-loopback networking forbidden by research launcher')
def safe_ex(self,address):
 if isinstance(address,tuple) and address[0] in ('127.0.0.1','::1','localhost'):return old_ex(self,address)
 raise RuntimeError('Non-loopback networking forbidden by research launcher')
socket.socket.connect=safe;socket.socket.connect_ex=safe_ex
os.chdir(kit)
if target=='unittest':sys.argv=['unittest',*args];runpy.run_module('unittest',run_name='__main__')
else:sys.argv=[str(kit/target),*args];runpy.run_path(str(kit/target),run_name='__main__')
