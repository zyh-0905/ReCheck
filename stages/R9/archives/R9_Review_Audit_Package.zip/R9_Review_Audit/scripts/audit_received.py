"""No-network audit of the received R9 first-turn format pause. No model calls."""
from pathlib import Path
import json,hashlib,csv,sys,zipfile,socket
from reviewlib import canonical,digest,check_request_record,strict_object
ROOT=Path(__file__).resolve().parents[1]
F=ROOT/'inputs/feedback';O=ROOT/'inputs/original/R9_Research_Kit';OUT=ROOT/'results'
def j(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
 OUT.mkdir(exist_ok=True)
 m=j(F/'BUNDLE_MANIFEST.json');names={p.relative_to(F).as_posix() for p in F.rglob('*') if p.is_file()}
 assert names==set(m['sha256'])|{'BUNDLE_MANIFEST.json'}
 for n,h in m['sha256'].items():assert sha(F/n)==h,n
 source=j(O/'SOURCE_MANIFEST.json')['sha256']
 for n,h in source.items():assert sha(O/n)==h and sha(F/'kit_source'/n)==h,n
 assert (F/'kit_source/SOURCE_MANIFEST.json').read_bytes()==(O/'SOURCE_MANIFEST.json').read_bytes()
 prep=j(F/'PREPARED.json');source_with_manifest={**source,'SOURCE_MANIFEST.json':sha(O/'SOURCE_MANIFEST.json')}
 assert prep['source']==source
 assert prep['protocol']==j(O/'protocol.json') and prep['config']==j(O/'config.example.json')
 assert prep['fingerprint']==digest({k:prep[k] for k in ('config','protocol','source')})
 rows=[]
 for name in ('R9_smoke','R9_main'):
  rdir=F/'runs'/name;manifest=j(rdir/'manifest.json');state=j(rdir/'status.json')
  for k in ('config','protocol','source'):assert manifest[k]==prep[k]
  assert manifest['prepared_fingerprint']==prep['fingerprint']
  ss=sorted((rdir/'attempts').glob('*_start.json'));rr=sorted((rdir/'attempts').glob('*_result.json'))
  assert len(ss)==len(rr)==1
  s=j(ss[0]);r=j(rr[0]);intent=j(rdir/'attempts/000001_send_intent.json')
  assert s['attempt']==1 and intent['attempt']==1 and intent['logical_id']==s['logical_id']
  cache=rdir/'calls'/(digest(s['logical_id'])+'.json')
  assert cache.read_bytes()==rr[0].read_bytes()
  a=check_request_record(s,r,prep['config']['base_url'])
  identity=j(rdir/'endpoint_identity.json')
  assert identity['requested_model']==a['requested_model'] and identity['returned_model']==a['returned_model'] and identity['system_fingerprint']==a['system_fingerprint']
  assert s['metadata']['phase'] in ('smoke','primary')
  rows.append({'run':name,'logical_id':s['logical_id'],'state':state['status'],**a})
 assert rows[0]['valid_object'] and not rows[1]['valid_object']
 assert rows[0]['returned_model']==rows[1]['returned_model'] and rows[0]['system_fingerprint']==rows[1]['system_fingerprint']
 assert rows[0]['response_id']!=rows[1]['response_id']
 assert all(x['finish_reason']=='stop' and x['response_format'] is None for x in rows)
 boundary=j(F/'runs/R9_main/partial/primary_n06_verify_confirm/boundary.json')
 assert boundary['turn']==0 and boundary['turns']==[] and boundary['events']==[]
 assert not list((F/'runs/R9_main/episodes').glob('*.json'))
 case=next(c for c in j(O/'fixtures/cases.json') if c['id']=='n06')
 assert case['family']=='phone' and case['variant']=='post_relevant'
 assert boundary['world']==case['world_before']
 assert boundary['exposure']=={'scheduled':True,'triggered':False,'missed_before_primary_write':False,'reason':'no_qualifying_read'}
 start=j(F/'runs/R9_main/attempts/000001_start.json')
 assert start['metadata']=={'episode_id':'primary_n06_verify_confirm','phase':'primary','turn':0}
 assert start['payload']['messages']==boundary['messages']
 # Exact prompt reconstruction also occurs in the native audit; here inspect the information boundary.
 assert boundary['messages'][1]['content']==json.dumps(case['public'],ensure_ascii=False,sort_keys=True)
 text=j(F/'runs/R9_main/attempts/000001_result.json')['text']
 first,end=json.JSONDecoder().raw_decode(text)
 last_start=text.rfind('\n{')+1;last=json.loads(text[last_start:])
 write('raw_response_analysis.json',{'full_text':text,'first_object_only_for_diagnosis':first,'first_object_end':end,
   'intervening_prose':text[end:last_start],'second_object_only_for_diagnosis':last,'executed_objects':0,
   'no_tools_executed':True,'no_state_update_triggered':True,'format_failure_not_task_outcome':True})
 # Match every submitted convenience copy by original bytes, rather than accepting their summaries.
 mapping={'AUDIT.json':'offline_reports/AUDIT.json','calls.csv':'offline_reports/calls.csv',
  'PREPARED.json':'PREPARED.json','smoke_status.json':'runs/R9_smoke/status.json','main_status.json':'runs/R9_main/status.json',
  'smoke_endpoint_identity.json':'runs/R9_smoke/endpoint_identity.json','main_endpoint_identity.json':'runs/R9_main/endpoint_identity.json',
  'smoke_result.json':'runs/R9_smoke/smoke_result.json'}
 outer=[p for p in (ROOT/'inputs/outer').rglob('*') if p.is_file()]
 for base,target in mapping.items():assert next(p for p in outer if p.name==base).read_bytes()==(F/target).read_bytes()
 for suffix,target in [('boundary.json','runs/R9_main/partial/primary_n06_verify_confirm/boundary.json')]:
  assert next(p for p in outer if p.name.endswith(suffix)).read_bytes()==(F/target).read_bytes()
 assert next(p for p in outer if p.name.startswith('000001_result')).read_bytes()==(F/'runs/R9_main/attempts/000001_result.json').read_bytes()
 total={k:sum(r[k] for r in rows) for k in ('prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','latency_seconds')}
 write('independent_audit.json',{'input_sha256':sha(ROOT/'inputs/submitted_outer.zip'),
 'inner_sha256':sha(ROOT/'inputs/R9_feedback_original.zip'),'original_handoff_sha256':sha(ROOT/'inputs/original_delivery.zip'),
 'bundle_files_verified':len(m['sha256']),'source_files_verified':len(source),'convenience_copies_verified':len(mapping)+2,
 'received_responses':2,'completed_primary':0,'planned_primary':32,'completed_repeat':0,'planned_repeat':4,
 'main_format_failures':1,'main_turns_applied':0,'agent_tools':0,'environment_events':0,'state_unchanged':True,
 'request_response_identity_consistent':True,'json_mode_requested':False,'totals':total,
 'main_state':rows[1]['state'],'smoke_state':rows[0]['state'],'evidence_acceptance':'ACCEPT_PAUSE_RECORDS_NOT_COMPLETED_RESEARCH',
 'additional_remote_model_calls':0})
 with (OUT/'call_ledger.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps(j(OUT/'independent_audit.json'),ensure_ascii=False,indent=2))
if __name__=='__main__':
 def deny(*a,**k):raise RuntimeError('Network disabled for audit')
 socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny
 main()
