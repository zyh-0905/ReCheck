import unittest,copy,json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from reviewlib import strict_object,check_usage,check_request_record

def dg(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
class ReviewTests(unittest.TestCase):
 def test_object(self):self.assertEqual(strict_object('{"x":2}'),{'x':2})
 def test_two_actions(self):
  with self.assertRaises(ValueError):strict_object('{"tool":"read"}\n{"tool":"write"}')
 def test_prose(self):
  with self.assertRaises(ValueError):strict_object('{"x":1}\nExplanation')
 def test_fence(self):
  with self.assertRaises(ValueError):strict_object('```json\n{}\n```')
 def test_duplicate(self):
  with self.assertRaises(ValueError):strict_object('{"x":1,"x":2}')
 def test_array(self):
  with self.assertRaises(ValueError):strict_object('[]')
 def test_empty(self):
  with self.assertRaises(ValueError):strict_object('')
 def test_nan(self):
  with self.assertRaises(ValueError):strict_object('{"x":NaN}')
 def test_overflow(self):
  with self.assertRaises(ValueError):strict_object('{"x":1e10000}')
 def test_usage(self):self.assertEqual(check_usage({'prompt_tokens':2,'completion_tokens':5,'total_tokens':7,'completion_tokens_details':{'reasoning_tokens':3}})['total_tokens'],7)
 def test_reasoning_not_added_twice(self):self.assertEqual(check_usage({'prompt_tokens':2,'completion_tokens':5,'total_tokens':7,'completion_tokens_details':{'reasoning_tokens':3}})['reasoning_tokens'],3)
 def test_bool_usage(self):
  with self.assertRaises(ValueError):check_usage({'prompt_tokens':True,'completion_tokens':5,'total_tokens':6})
 def test_total_mismatch(self):
  with self.assertRaises(ValueError):check_usage({'prompt_tokens':2,'completion_tokens':5,'total_tokens':8})
 def test_reasoning_exceeds_output(self):
  with self.assertRaises(ValueError):check_usage({'prompt_tokens':2,'completion_tokens':5,'total_tokens':7,'completion_tokens_details':{'reasoning_tokens':6}})
 def test_cached_input_exceeds_total(self):
  with self.assertRaises(ValueError):check_usage({'prompt_tokens':2,'completion_tokens':5,'total_tokens':7,'prompt_cache_hit_tokens':3})
 def fixture(self):
  endpoint='https://example.invalid/v1';p={'model':'m','messages':[],'stream':False}
  s={'attempt':1,'logical_id':'a','payload':p,'payload_sha256':dg(p),'request_sha256':dg({'endpoint':endpoint,'payload':p}),'metadata':{},'started_utc':'2026-09-13T12:00:00+00:00'}
  r={**s,'status':'ok','text':'{}','latency_seconds':1.0,'response':{'id':'r','model':'m','system_fingerprint':'f','choices':[{'message':{'content':'{}'},'finish_reason':'stop'}],'usage':{'prompt_tokens':2,'completion_tokens':5,'total_tokens':7}}}
  return s,r,endpoint
 def test_valid_record(self):
  s,r,e=self.fixture();self.assertTrue(check_request_record(s,r,e)['valid_object'])
 def test_malformed_record_preserved(self):
  s,r,e=self.fixture();r['text']='{} text';r['response']['choices'][0]['message']['content']=r['text'];self.assertFalse(check_request_record(s,r,e)['valid_object'])
 def test_response_text_mismatch(self):
  s,r,e=self.fixture();r['text']='{"y":2}'
  with self.assertRaises(ValueError):check_request_record(s,r,e)
 def test_payload_changed(self):
  s,r,e=self.fixture();r['payload']=dict(r['payload'],model='other')
  with self.assertRaises(ValueError):check_request_record(s,r,e)
 def test_metadata_changed(self):
  s,r,e=self.fixture();r['metadata']={'phase':'other'}
  with self.assertRaises(ValueError):check_request_record(s,r,e)
 def test_nonfinite_latency(self):
  s,r,e=self.fixture();r['latency_seconds']=float('nan')
  with self.assertRaises(ValueError):check_request_record(s,r,e)
if __name__=='__main__':unittest.main()
