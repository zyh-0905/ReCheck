from pathlib import Path
import json,zipfile,hashlib,shutil,platform,sqlite3,csv,datetime
BASE=Path('/mnt/data');SRC=BASE/'R10_Research_Kit';W=BASE/'r10_work'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,o):Path(p).write_text(json.dumps(o,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
m=json.loads((SRC/'SOURCE_MANIFEST.json').read_text());source_digest=sha(SRC/'SOURCE_MANIFEST.json')
fixtures={}
for name,folder in [('rule','final_http_rule'),('cap','final_http_cap_retry'),('late_bad','final_http_late_bad'),('prose','final_http_prose')]:
 root=W/'results'/folder;v=json.loads((root/'verification.json').read_text());fixtures[name]=v
 assert sha(root/'kit/SOURCE_MANIFEST.json')==source_digest
 assert v['audit']['mechanical_pass'] and v['no_resampling']
 assert v['http_requests']=={'rule':256,'cap':384,'late_bad':2,'prose':48}[name]
 summaries=list(csv.DictReader((root/'kit/runs/main/summary.csv').open()))
 fixtures[name]['simulated_arm_outcomes_not_llm_results']=summaries
for name in ['fresh_final_tests.txt','final_source_tests.txt']:
 t=(W/'logs'/name).read_text();assert 'Ran 92 tests' in t and '\nOK\n' in t
for key,dst in [('README_ZH.md','R10_Runbook_ZH.md'),('EXECUTION_PROMPT_ZH.md','R10_Execution_Prompt_ZH.md'),('docs/OFFLINE_FINDINGS_ZH.md','R10_Offline_Findings_ZH.md'),('docs/ANALYSIS_LOCK_ZH.md','R10_Analysis_Lock_ZH.md'),('docs/PAPER_PROTOCOL_EN.md','R10_Paper_Protocol_EN.md')]:shutil.copyfile(SRC/key,BASE/dst)
shutil.copyfile(W/'results/offline_run1/cases.csv',BASE/'R10_Offline_Results.csv')
legacy={'Research_Handoff_R9NT1.zip':'e8686e52224b7d2ff454bdf521a72855f90925dfbe1dc96b0c6c64bb8bc7ad83','e9c3066b-474b-4d1c-b162-a0ca812a1c89.zip':'b8f3c4d009f40932e6ad8c127633e36ebf4a340ad09931278a79965fb603c8ae'}
for file,h in legacy.items():assert sha(BASE/file)==h
v={'phase':'R10_OFFLINE_MECHANISM_AND_HANDOFF','task_id':'R10_SELECTION_AND_WRITE_SCOPE_DIAGNOSIS_01','version':'r10-1.0.0','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'researcher_new_remote_llm_calls':0,'new_live_r10_results':0,'legacy_archives_unchanged':legacy,
 'source_registered_files':len(m['files']),'source_manifest_sha256':source_digest,'upstream_tool_sandbox_imported':False,'standard_library_only':True,
 'native_backend':'file-backed SQLite; separate agent/environment connections; cooperative one-change schedule','sqlite_version':sqlite3.sqlite_version,
 'actual_offline_preparation_queries':12,'scripted_cases':12,'scripted_policies':8,'scripted_trajectories':96,'scripted_second_run_all_except_elapsed_equal':True,
 'scripted_claim_is_deterministic_check_not_model_utterance':True,
 'final_source_tests':92,'fresh_extracted_tests':92,'fresh_extracted_failures':0,
 'http_fixtures_final_distributed_source':fixtures,'successful_final_fixture_loopback_requests':sum(x['http_requests'] for x in fixtures.values()),
 'interrupted_software_fixture_retained':{'path':'results/final_http_cap','reason':'Combined rule+cap command exceeded45seconds; cap had353savedresponses and44completeepisodes. Preserved partial software records; independent deterministic cap fixture repeated with same final source and completed. No real model data or parameters changed.'},
 'test_history':['Missing implementation stubs failed before database/score/runner/auditor implementation. Some failures were missing-interface errors, not all assertions.','Initial SQL INSERT placeholder count mismatch caught and fixed before paid handoff; original failure logs retained.','Initial final combined HTTP command exceeded wall limit; described partial fixture preserved; independent complete final cap, late_bad and prose checks passed.'],
 'paid_budget':{'primary_episodes':48,'repeat_episodes':0,'max_requests_per_episode':8,'max_calls_per_response':4,'max_calls_per_episode':32,'max_model_requests':384,'extra_smoke':0,'max_visible_tools':1536,'finish_task_in_tool_budget':True,'max_output_per_request':16384,'extreme_output_tokens_not_forecast':384*16384,'currency':'UNKNOWN','automatic_followup':False},
 'qualification_not_repeated':True,'tasks_constructed_not_public_benchmark':True,'no_new_repairlens_result':True,'model_arm_tasks_permissions_preconditions_equal':True,'baseline_not_forced_full_write':True,
 'finish_task_is_self_report_not_hidden_oracle':True,'atomic_conditions_standard_mechanism_not_claimed_novel':True,
 'tested_environment':{'python':platform.python_version(),'os':platform.system(),'machine':platform.machine()},'windows_macos_tested':False,'independent_human_or_subagent_review':False,
 'handoff_zip_sha256':sha(BASE/'Research_Handoff_R10.zip'),'handoff_zip_bytes':(BASE/'Research_Handoff_R10.zip').stat().st_size,
 'research_gate':'One frozen paid exploratory factorial diagnostic; not method superiority, significance, broad generalization or publication readiness'}
write(BASE/'R10_Delivery_Verification.json',v)
# Compose evidence: exact source, offline experiments, all development logs, final HTTP exports,
# retained interrupted records. Do not bundle interpreters, credentials or font files.
evidence=BASE/'R10_Offline_Evidence';evidence.mkdir(exist_ok=False)
shutil.copytree(SRC,evidence/'source',ignore=shutil.ignore_patterns('__pycache__','runs','uploads','.venv','PREPARED.json'))
shutil.copytree(W/'logs',evidence/'logs')
for folder in ['offline_run1','offline_run2']:
 shutil.copytree(W/'results'/folder,evidence/'results'/folder)
for f in ['preparation.json','offline_reproduction.json']:shutil.copyfile(W/'results'/f,evidence/'results'/f)
for name,folder in [('rule','final_http_rule'),('cap','final_http_cap_retry'),('late_bad','final_http_late_bad'),('prose','final_http_prose')]:
 out=evidence/'software_http'/name;out.mkdir(parents=True)
 root=W/'results'/folder
 shutil.copyfile(root/'verification.json',out/'verification.json')
 latest=sorted((root/'kit/uploads').glob('*.zip'))[-1];shutil.copyfile(latest,out/latest.name)
inter=evidence/'software_interrupted_cap';inter.mkdir()
shutil.copytree(W/'results/final_http_cap/kit/runs',inter/'runs')
shutil.copyfile(W/'results/final_http_cap/kit/PREPARED.json',inter/'PREPARED.json')
shutil.copyfile(W/'results/final_http_cap/kit/SOURCE_MANIFEST.json',inter/'SOURCE_MANIFEST.json')
(inter/'README.txt').write_text('Software fixture interrupted by outer command timeout, not a paid model run. All353recordedresponses and partial prefix retained. Original final source manifest applies; source is in ../../source. Subsequent independent deterministic cap fixture used identical final source and fixed inputs. No actual model answers were resampled.\n')
shutil.copyfile(BASE/'R10_Delivery_Verification.json',evidence/'VERIFICATION.json')
shutil.copyfile(W/'finalize_delivery.py',evidence/'packaging_script.py')
(evidence/'README_ZH.md').write_text('# R10研究端证据\n\nsource为最终冻结源码；results/offline_run1与run2是实际SQLite脚本机制实验，重复不增样本。software_http为本地HTTP模型夹具，不能当真实LLM；software_interrupted_cap保留一次45秒命令超时的未完成软件运行。logs含初始红灯、修复与最终测试。VERIFICATION记录范围。\n\n复核：在source运行`python -m unittest discover -s tests -v`或`python scripts/offline.py <新结果目录>`；无需API密钥。用户不需要重复这些离线实验。\n')
files={}
for p in sorted(evidence.rglob('*')):
 if p.is_file():files[p.relative_to(evidence).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
write(evidence/'EVIDENCE_MANIFEST.json',{'files':files})
zp=BASE/'R10_Offline_Evidence.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(evidence.rglob('*')):
  if p.is_file():z.write(p,'R10_Offline_Evidence/'+p.relative_to(evidence).as_posix())
with zipfile.ZipFile(zp) as z:
 for rel,meta in files.items():
  b=z.read('R10_Offline_Evidence/'+rel);assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256']
assert len(zipfile.ZipFile(BASE/'Research_Handoff_R10.zip').namelist()) == len(m['files']) + 1 # ensure can read final central directory
write(BASE/'R10_Package_Checksums.json',{'handoff':{'sha256':sha(BASE/'Research_Handoff_R10.zip'),'bytes':(BASE/'Research_Handoff_R10.zip').stat().st_size},'evidence':{'sha256':sha(zp),'bytes':zp.stat().st_size,'manifest_files_verified':len(files)},'verification_sha256':sha(BASE/'R10_Delivery_Verification.json')})
print(json.dumps({'evidence_bytes':zp.stat().st_size,'evidence_verified_files':len(files),'handoff_bytes':(BASE/'Research_Handoff_R10.zip').stat().st_size,'fresh_tests':92,'final_loopback':v['successful_final_fixture_loopback_requests']},indent=2))
