# R10研究端证据

source为最终冻结源码；results/offline_run1与run2是实际SQLite脚本机制实验，重复不增样本。software_http为本地HTTP模型夹具，不能当真实LLM；software_interrupted_cap保留一次45秒命令超时的未完成软件运行。logs含初始红灯、修复与最终测试。VERIFICATION记录范围。

复核：在source运行`python -m unittest discover -s tests -v`或`python scripts/offline.py <新结果目录>`；无需API密钥。用户不需要重复这些离线实验。
