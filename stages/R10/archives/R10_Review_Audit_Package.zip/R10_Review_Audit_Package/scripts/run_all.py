"""Reproduce this review locally. Never starts a model or reads an API key."""
import argparse,json,os,shutil,subprocess,sys
from pathlib import Path
from extract_inputs import prepare
from independent_review import analyze,read,save,sha,require
from narrative_checks import check as narratives

def main():
    p=argparse.ArgumentParser();p.add_argument('--feedback-zip',required=True);p.add_argument('--kit-zip',required=True);p.add_argument('--work',required=True);p.add_argument('--tests',action='store_true');a=p.parse_args()
    work=Path(a.work).resolve();script=Path(__file__).resolve().parent
    feedback,source=prepare(a.feedback_zip,a.kit_zip,work)
    result=analyze(feedback,source,work/'results/independent')
    narratives(feedback,work/'results/narrative_checks.json')
    (work/'logs').mkdir(exist_ok=True)
    env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'PYTHONNOUSERSITE':'1','PYTHONHASHSEED':'0','HOME':str(work),'R10_FEEDBACK_ROOT':str(feedback),'R10_SOURCE_ROOT':str(source)}
    def run(cmd,name,cwd=None):
        with (work/'logs'/name).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=cwd,check=False)
        require(r.returncode==0,'Failed step '+name+'; preserve log')
    replay=work/'replay_kit';shutil.copytree(feedback,replay,ignore=shutil.ignore_patterns('BUNDLE_MANIFEST.json'))
    run([sys.executable,str(script/'native_replay.py'),'--root',str(replay),'--reference',str(feedback),'--out',str(work/'results/native_replay.json')],'native_replay.log')
    run([sys.executable,str(script/'local_guard_check.py'),'--feedback-root',str(feedback),'--original-root',str(source),'--out',str(work/'results/local_guards')],'local_guard_check.log')
    if a.tests:
        run([sys.executable,'-m','unittest','discover','-s',str(script.parent/'tests'),'-v'],'independent_tests.log')
        run([sys.executable,'-m','unittest','discover','-s','tests','-v'],'original_tests.log',source)
    save(work/'COMPLETED.json',{'review_passed':result['passed'],'all_original_outcomes_preserved':True,'remote_calls':0,'tests_requested':a.tests,'input_feedback_sha256':sha(Path(a.feedback_zip).read_bytes()),'input_kit_sha256':sha(Path(a.kit_zip).read_bytes())})
    print(json.dumps(read(work/'COMPLETED.json'),indent=2))
if __name__=='__main__':main()
