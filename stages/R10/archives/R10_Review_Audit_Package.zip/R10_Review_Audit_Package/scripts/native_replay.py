import argparse,sys,hashlib,getpass,json,platform,sqlite3
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--reference',required=True);p.add_argument('--out',required=True);args=p.parse_args()
root=Path(args.root).resolve();ref=Path(args.reference).resolve();sys.path.insert(0,str(root))
from core.audit import audit
from core.runtime import run_study
from core.common import no_network
with no_network():result=audit(root)
comparisons={name:(root/'runs/main'/name).read_bytes()==(ref/'runs/main'/name).read_bytes() for name in ('AUDIT.json','calls.csv','episodes.csv','summary.csv')}
assert all(comparisons.values()),comparisons
hashes=lambda:{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in str(p)}
before=hashes()
def no_new(*a,**k):raise AssertionError('Unexpected request or credential read')
getpass.getpass=no_new
with no_network():completed=run_study(root,384,exchange=no_new)
assert completed['status']=='completed' and hashes()==before
summary={'audit':result,'original_derived_files_identical':comparisons,'no_resampling_on_completed':True,'new_remote_model_calls':0,'python':platform.python_version(),'sqlite':sqlite3.sqlite_version}
Path(args.out).write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,indent=2))
