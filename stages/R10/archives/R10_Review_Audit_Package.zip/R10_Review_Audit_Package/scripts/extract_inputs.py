"""Safe extraction for two frozen audit inputs; original ZIP bytes never change."""
from pathlib import Path,PurePosixPath
import stat,zipfile
from independent_review import require,sha,save

def extract(archive,destination,decode_legacy=False):
    destination=Path(destination);require(not destination.exists(),'Use a fresh extraction directory')
    destination.mkdir(parents=True);names=set();mapped=set();mapping=[]
    with zipfile.ZipFile(archive) as z:
        require(sum(i.file_size for i in z.infolist())<200_000_000,'Archive too large')
        for i in z.infolist():
            name=i.filename;require(name not in names,'Duplicate ZIP path');names.add(name)
            if decode_legacy and not i.flag_bits&0x800:
                try:name=name.encode('cp437').decode('utf8')
                except UnicodeError:pass
            p=PurePosixPath(name)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and not any(':' in q for q in p.parts),'Unsafe archive path')
            require(not stat.S_ISLNK(i.external_attr>>16),'Symlink in ZIP')
            require(name not in mapped,'Mapped path collision');mapped.add(name)
            out=destination/name
            if i.is_dir():out.mkdir(parents=True,exist_ok=True)
            else:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(i))
            mapping.append({'original_path':i.filename,'local_path':name,'bytes':i.file_size})
    return mapping

def prepare(outer,kit,work):
    work=Path(work);require(not work.exists(),'Output work directory must be new');work.mkdir(parents=True)
    m=extract(outer,work/'outer',True)
    inner=[p for p in (work/'outer').rglob('R10_feedback_*.zip') if '__MACOSX' not in p.parts]
    require(len(inner)==1,'Expected one inner feedback ZIP')
    fm=extract(inner[0],work/'feedback');km=extract(kit,work/'original')
    source=work/'original/R10_Research_Kit';require(source.is_dir(),'Frozen kit root missing')
    save(work/'extraction.json',{'outer_sha256':sha(Path(outer).read_bytes()),'inner_sha256':sha(inner[0].read_bytes()),'frozen_kit_sha256':sha(Path(kit).read_bytes()),'outer_entries':len(m),'inner_entries':len(fm),'original_entries':len(km),'outer_name_mapping':m})
    return work/'feedback',source
