"""Retrospective single-transition audit: omit only a rejected precondition.
No model continuation, no efficacy estimate, no replacement of original scores.
"""
import argparse,copy,sys,tempfile
from pathlib import Path
from independent_review import read,save,csvsave,equal,require,score,predicted_patch_safe

def check(root,source,out):
    root,source,out=Path(root),Path(source),Path(out)
    sys.path.insert(0,str(source))
    from core.db import Store
    from core.common import no_network
    cases={c['id']:c for c in read(root/'fixtures/cases.json')};rows=[];evidence=[]
    with no_network():
        for ep_path in sorted((root/'runs/main/episodes').glob('*.json')):
            if ep_path.name.endswith('.partial.json'):continue
            ep=read(ep_path);case=cases[ep['case_id']]
            for rejected in ep['events']:
                if rejected['kind']!='tool' or rejected['result']['error'] not in ('ROW_VERSION_CONFLICT','SELECTION_CONFLICT'):continue
                with tempfile.TemporaryDirectory(prefix='r10-guard-audit-') as d:
                    store=Store(case,Path(d)/'world.sqlite')
                    try:
                        for e in ep['events'][:rejected['index']]:
                            if e['kind']=='tool':
                                require(equal(store.world(),e['before']),'Saved prefix prestate mismatch')
                                require(equal(store.call(e['name'],e['arguments']),e['result']),'Saved prefix tool mismatch')
                        require(equal(store.world(),rejected['before']),'Rejected operation prestate mismatch')
                        args=copy.deepcopy(rejected['arguments']);removed={}
                        drop=['expected_version'] if rejected['result']['error']=='ROW_VERSION_CONFLICT' else ['expected_selection_token','service','lane_query','min_units_query']
                        for key in drop:
                            if key in args:removed[key]=args.pop(key)
                        expected,_=predicted_patch_safe(case['task'],store.world(),rejected['name'],args)
                        before=store.world();result=store.call(rejected['name'],args);after=store.world()
                        require(result['ok'] is True,'Local variant unexpectedly still rejected')
                        scored=score(case['task'],store.initial,store.events,store.world())
                        require(scored['trace_safe_success']==expected,'Independent classification/native mismatch')
                        rows.append({'episode_id':ep['episode_id'],'case_id':ep['case_id'],'arm':ep['arm'],'event_index':rejected['index'],'original_error':rejected['result']['error'],'removed_parameters':removed,'local_branch_accepted':result['ok'],'local_branch_goal_final':scored['goal_final'],'local_branch_trace_safe':scored['trace_safe_success'],'new_model_calls':0,'not_a_live_agent_result':True})
                        evidence.append({**rows[-1],'task':case['task'],'original_arguments':rejected['arguments'],'modified_arguments':args,'before':before,'result':result,'after':after,'local_score':scored})
                    finally:store.close()
    csvsave(out/'local_guard_checks.csv',rows);save(out/'local_guard_checks.json',evidence)
    summary={'branch_transitions':len(rows),'model_calls':0,'safe_after_removing_failed_row_guard':sum(r['original_error']=='ROW_VERSION_CONFLICT' and r['local_branch_trace_safe'] for r in rows),'unsafe_after_removing_failed_selection_guard':sum(r['original_error']=='SELECTION_CONFLICT' and not r['local_branch_trace_safe'] for r in rows),'same_model_actions_except_guard_arguments':True,'new_agent_episodes':0,'not_a_no_guard_policy_evaluation':True,'all_original_outcomes_unchanged':True}
    save(out/'local_guard_summary.json',summary);return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--feedback-root',required=True);p.add_argument('--original-root',required=True);p.add_argument('--out',required=True);a=p.parse_args();print(check(a.feedback_root,a.original_root,a.out))
