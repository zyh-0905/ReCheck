"""Re-signing an outer manifest must not conceal semantic corruption."""
import unittest, os, tempfile, shutil, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import independent_review as a

@unittest.skipUnless(os.environ.get('R10_FEEDBACK_ROOT') and os.environ.get('R10_SOURCE_ROOT'), 'Set evidence paths to run full-bundle negative tests')
class BundleTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'feedback'
        shutil.copytree(os.environ['R10_FEEDBACK_ROOT'],self.root)
        self.source=Path(os.environ['R10_SOURCE_ROOT']);self.attempts=self.root/'runs/main/attempts'
        self.ep=self.root/'runs/main/episodes/primary_x06_intent.json'
    def tearDown(self):self.tmp.cleanup()
    def resign(self):
        p=self.root/'BUNDLE_MANIFEST.json'
        a.save(p,{'files':{x.relative_to(self.root).as_posix():{'bytes':x.stat().st_size,'sha256':a.sha(x.read_bytes())} for x in self.root.rglob('*') if x.is_file() and x!=p}})
    def expect_reject(self):
        self.resign()
        with self.assertRaises(ValueError):a.analyze(self.root,self.source,Path(self.tmp.name)/'result')
    def change_payload(self,index,edit):
        qpath=self.attempts/f'{index:06d}_request.json';rpath=self.attempts/f'{index:06d}_response.json'
        q=a.read(qpath);r=a.read(rpath);edit(q['payload']);q['payload_sha256']=a.digest(q['payload']);q['request_sha256']=a.digest({'endpoint':a.read(self.root/'config.json')['endpoint'],'payload':q['payload']});r.update(q);a.save(qpath,q);a.save(rpath,r)
    def test_tampered_score(self):
        x=a.read(self.ep);x['score']['conflicts']+=1;a.save(self.ep,x);self.expect_reject()
    def test_bool_integer_score(self):
        x=a.read(self.ep);x['score']['goal_final']=1;a.save(self.ep,x);self.expect_reject()
    def test_fabricated_receipt(self):
        def edit(p):
            m=next(m for m in p['messages'] if m['role']=='tool');v=a.strict_loads(m['content']);v['value']={'invented':True};m['content']=a.canonical(v)
        self.change_payload(2,edit);self.expect_reject()
    def test_missing_reasoning_history(self):
        def edit(p):next(m for m in p['messages'] if m['role']=='assistant').pop('reasoning_content',None)
        self.change_payload(2,edit);self.expect_reject()
    def test_tool_id_changed_in_next_request(self):
        def edit(p):next(m for m in p['messages'] if m['role']=='tool')['tool_call_id']='invented-id'
        self.change_payload(2,edit);self.expect_reject()
    def test_duplicate_response_id(self):
        p=self.attempts/'000002_response.json';r=a.read(p);r['response']['id']=a.read(self.attempts/'000001_response.json')['response']['id'];wire=a.canonical(r['response']).encode();r['raw_original_sha256']=r['raw_stored_sha256']=a.sha(wire);(self.attempts/'000002_response.raw').write_bytes(wire);a.save(p,r);self.expect_reject()
    def test_source_change(self):
        p=self.root/'core/prompts.py';p.write_text(p.read_text()+'\n# changed\n');self.expect_reject()
    def test_response_usage_resigned(self):
        p=self.attempts/'000002_response.json';r=a.read(p);r['response']['usage']['total_tokens']+=1;wire=a.canonical(r['response']).encode();r['raw_original_sha256']=r['raw_stored_sha256']=a.sha(wire);(self.attempts/'000002_response.raw').write_bytes(wire);a.save(p,r);self.expect_reject()
    def test_visible_budget_changed(self):
        x=a.read(self.ep);x['visible_tool_calls']+=1;a.save(self.ep,x);self.expect_reject()
    def test_unchanged_final_but_wrong_trace(self):
        x=a.read(self.ep);x['events'][1]['after']['batches'][0]['note']='changed';a.save(self.ep,x);self.expect_reject()
    def test_false_exposure(self):
        x=a.read(self.ep);x['exposure']['triggered']=True;a.save(self.ep,x);self.expect_reject()
    def test_endpoint_identity_change(self):
        p=self.root/'runs/main/endpoint_identity.json';x=a.read(p);x['system_fingerprint']='different';a.save(p,x);self.expect_reject()

if __name__=='__main__':unittest.main()
