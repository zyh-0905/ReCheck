# R10 feedback review — offline reproducibility artifact

No model call is needed. User rerunning is not requested. This package archives the
accepted original feedback, the frozen R10 source ZIP, and an independent standard-
library reviewer. It contains no API key and does not fetch dependencies.

## Verify / reproduce
Use Python 3.11 or newer in this package directory. Choose a NEW work directory:

```bash
python scripts/run_all.py --feedback-zip inputs/feedback_original.zip --kit-zip inputs/frozen_handoff.zip --work reproduced --tests
```

The command safely unpacks copies, runs the independent receipt/state/score audit,
replays the unchanged original SQLite engine from recorded responses only, checks
22 local rejected-precondition branches, and runs 50 independent-review tests plus
92 original tests. Original tests use software/loopback response fixtures, not a
remote model. Fresh work directories prevent accidentally replacing observations.

The local precondition branches are retrospective single-transition checks. They
are not new model rollouts, not an unguarded agent baseline, not additions to the
48 primary episodes, and do not replace the submitted success scores.

The two narration checks are targeted posthoc counterexamples, not an exhaustive
language evaluator or a revised task-success endpoint.

## Evidence boundaries
- The original benchmark is a constructed SQLite development diagnostic.
- All four prompting conditions have 12/12 safe completion in this sample.
- Row guards rejected 14 proposals; selection guards rejected 8 proposals.
- The raw feedback contains 237 recorded model responses, not 384 executed calls.
- The reviewer runs no live inference. SHA/fingerprint checks do not authenticate
  model weights, billed currency, or all historic user-machine activity.
- This is a second implementation by the same assistant, not independent human review.
- Raw archives remain unchanged. Code and frozen-data licenses inside inputs remain intact.
- No new paid batch is authorized by this package.

Report: R10_Review_Report_ZH.md. Detailed derived data: results/independent/.
Native replay and negative-test results are in logs/ and results/.
