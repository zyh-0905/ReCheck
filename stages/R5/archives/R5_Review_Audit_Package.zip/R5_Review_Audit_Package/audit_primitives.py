"""Independent R5 audit. No experiment imports; no network or data mutation.
Numeric tolerance applies ONLY to the per-record derived failure prediction.
Primary actions, evidence, outputs, budget, data and source identity remain exact.
"""
import math

PREDICTION_ATOL = 1e-14  # Post-audit numeric equivalence rule; not experimental scoring tolerance.
OMIT = {'cache_info','wall_started','wall_finished'}

def science_projection(obj):
    if isinstance(obj,dict):
        return {k:science_projection(v) for k,v in obj.items()
                if not k.endswith('_seconds') and k not in OMIT}
    if isinstance(obj,list):return [science_projection(v) for v in obj]
    return obj

def compare_science(a,b):
    strict=[];numeric=[]
    def walk(x,y,path):
        prediction=(len(path)==3 and path[0]=='records' and type(path[1]) is int
                    and path[2]=='predicted_task_error_after_receipts')
        if prediction:
            valid=lambda v: type(v) is float and math.isfinite(v) and 0<=v<=1
            if not valid(x) or not valid(y):
                strict.append({'path':list(path),'reason':'invalid prediction/range/type','reference':repr(x),'observed':repr(y)})
            elif x!=y:
                d={'path':list(path),'reference':x,'observed':y,'abs_error':abs(x-y)}
                (numeric if abs(x-y)<=PREDICTION_ATOL else strict).append(d)
            return
        if type(x) is not type(y):
            strict.append({'path':list(path),'reason':'type','reference':repr(x),'observed':repr(y)});return
        if isinstance(x,dict):
            if x.keys()!=y.keys():
                strict.append({'path':list(path),'reason':'keys','reference':sorted(x),'observed':sorted(y)})
            for k in sorted(x.keys()&y.keys()):walk(x[k],y[k],path+(k,))
        elif isinstance(x,list):
            if len(x)!=len(y):strict.append({'path':list(path),'reason':'length','reference':len(x),'observed':len(y)})
            for i,(xx,yy) in enumerate(zip(x,y)):walk(xx,yy,path+(i,))
        elif (isinstance(x,float) and (not math.isfinite(x) or not math.isfinite(y))) or x!=y:
            strict.append({'path':list(path),'reason':'value','reference':x,'observed':y})
    walk(science_projection(a),science_projection(b),())
    return {'pass':not strict,'strict_differences':strict,'numeric_differences':numeric}

def semantics(mode):
    if type(mode) is not int or not 0<=mode<8:raise ValueError('mode')
    return {'first_page':mode&1,'active_code':1-((mode>>1)&1),
            'stock_semantics':'gross' if mode&4 else 'net'}

def rule_reference(task,memory):
    s=semantics(memory);q=task['type']
    plan={'workflow':('catalog_ids','stock_sum','available_ids')[q]}
    if q in (0,2):plan.update(category=task['category'],page_size=3)
    if q==1:plan['skus']=list(task['skus'])
    if q==2:plan['minimum_available']=task['minimum']
    for key in (('first_page','active_code'),('stock_semantics',),('first_page','active_code','stock_semantics'))[q]:
        plan[key]=s[key]
    return plan

def gold_reference(rows,task):
    q=task['type'];lookup={r['sku']:r for r in rows}
    if q==1:
        return {'available_total':sum(max(0,lookup[k]['physical']-lookup[k]['reserved']) for k in task['skus'])}
    kept=[r for r in rows if r['active'] and r['category']==task['category']]
    if q==2:kept=[r for r in kept if max(0,r['physical']-r['reserved'])>=task['minimum']]
    return {'skus':sorted(r['sku'] for r in kept)}

def execute_reference(rows,task,memory,true_mode):
    plan=rule_reference(task,memory);true=semantics(true_mode);trace=[]
    table={r['sku']:r for r in rows}
    def inventory(skus):
        items=[]
        for k in skus:
            if k not in table:
                result={'error':'UNKNOWN_SKU'};break
            r=table[k];v=r['physical'] if true['stock_semantics']=='gross' else max(0,r['physical']-r['reserved'])
            items.append({'sku':k,'stock_value':v,'reserved':r['reserved']})
        else:result={'items':items}
        trace.append({'path':'/inventory/batch','args':{'skus':list(skus)},'result':result})
        return result
    def usable(item):return max(0,item['stock_value']-(item['reserved'] if plan.get('stock_semantics')=='gross' else 0))
    if task['type']==1:
        inv=inventory(task['skus'])
        if 'error' in inv:return inv,trace
        return {'available_total':sum(usable(r) for r in inv['items'])},trace
    eligible=[r for r in rows if r['active']==(plan['active_code']==true['active_code'])]
    observed=[]
    for j in range(64):
        page=plan['first_page']+j;relative=page-true['first_page']
        args={'page':page,'page_size':3,'status_code':plan['active_code']}
        if relative<0:result={'error':'PAGE_BEFORE_FIRST'}
        else:
            part=eligible[relative*3:(relative+1)*3]
            result={'items':[{'sku':r['sku'],'category':r['category']} for r in part],
                    'has_more':(relative+1)*3<len(eligible)}
        trace.append({'path':'/catalog/items','args':args,'result':result})
        if 'error' in result:return result,trace
        observed.extend(result['items'])
        if not result['has_more']:break
    else:return {'error':'PAGE_LIMIT'},trace
    selected=[r for r in observed if r['category']==task['category']]
    if task['type']==2:
        inv=inventory([r['sku'] for r in selected])
        if 'error' in inv:return inv,trace
        selected=[r for r in inv['items'] if usable(r)>=task['minimum']]
    return {'skus':sorted(r['sku'] for r in selected)},trace

def posterior_prediction(ages,hazards,memory,table,q):
    probs=[(1-(1-2*h)**a)/2 for a,h in zip(ages,hazards)]
    terms=[]
    for z in range(8):
        mass=math.prod(probs[j] if (memory^z)&(1<<j) else 1-probs[j] for j in range(3))
        terms.append(mass*table[q][memory][z])
    return math.fsum(terms)
