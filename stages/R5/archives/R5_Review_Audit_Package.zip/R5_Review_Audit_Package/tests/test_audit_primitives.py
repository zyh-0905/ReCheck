import copy,math,unittest
from audit_primitives import compare_science,execute_reference,gold_reference,posterior_prediction

class NumericalGateTests(unittest.TestCase):
    def row(self,prob=.2256):
        return {'records':[{'step':0,'packets':['s0'],'credits':2,'budget_after':6,
                'answer':{'available_total':12},'predicted_task_error_after_receipts':prob,
                'planning_seconds':.1}],'case_sha256':'abc','llm_calls':0}
    def test_exact_pass(self):
        x=self.row();self.assertTrue(compare_science(x,copy.deepcopy(x))['pass'])
    def test_real_ulp_difference_accepted(self):
        r=compare_science(self.row(.22559999999999997),self.row(.2256))
        self.assertTrue(r['pass']);self.assertEqual(len(r['numeric_differences']),1)
    def test_excessive_probability_change_rejected(self):
        self.assertFalse(compare_science(self.row(),self.row(.22560001))['pass'])
    def test_answer_float_not_tolerated(self):
        a=self.row();b=copy.deepcopy(a);a['records'][0]['answer']['available_total']=.1;b['records'][0]['answer']['available_total']=.10000000000000002
        self.assertFalse(compare_science(a,b)['pass'])
    def test_packets_not_tolerated(self):
        a=self.row();b=copy.deepcopy(a);b['records'][0]['packets']=['s1'];self.assertFalse(compare_science(a,b)['pass'])
    def test_budget_not_tolerated(self):
        a=self.row();b=copy.deepcopy(a);b['records'][0]['budget_after']=5;self.assertFalse(compare_science(a,b)['pass'])
    def test_hash_not_tolerated(self):
        a=self.row();b=copy.deepcopy(a);b['case_sha256']='abd';self.assertFalse(compare_science(a,b)['pass'])
    def test_probability_nan_rejected_even_on_both_sides(self):
        self.assertFalse(compare_science(self.row(math.nan),self.row(math.nan))['pass'])
    def test_probability_range_rejected(self):
        self.assertFalse(compare_science(self.row(1.1),self.row(1.1))['pass'])
    def test_integer_bool_type_difference_rejected(self):
        a=self.row();b=copy.deepcopy(a);b['records'][0]['step']=False;self.assertFalse(compare_science(a,b)['pass'])
    def test_missing_record_rejected(self):
        a=self.row();b=copy.deepcopy(a);b['records']=[];self.assertFalse(compare_science(a,b)['pass'])
    def test_extra_field_rejected(self):
        a=self.row();b=copy.deepcopy(a);b['extra']='x';self.assertFalse(compare_science(a,b)['pass'])
    def test_prediction_key_not_wildcard(self):
        a={'answer':{'predicted_task_error_after_receipts':.1}};b={'answer':{'predicted_task_error_after_receipts':.10000000000000002}}
        self.assertFalse(compare_science(a,b)['pass'])
    def test_timing_difference_explicitly_ignored(self):
        a=self.row();b=copy.deepcopy(a);b['records'][0]['planning_seconds']=9
        self.assertTrue(compare_science(a,b)['pass'])

class IndependentExecutionTests(unittest.TestCase):
    def rows(self):
        return [{'sku':f'S{i}','category':'B' if i<3 else 'A','active':True,'physical':10,'reserved':4} for i in range(5)]
    def test_correct_gold(self):
        self.assertEqual(gold_reference(self.rows(),{'type':0,'category':'A'}),{'skus':['S3','S4']})
    def test_skipped_page_different_trace_same_answer(self):
        rows=self.rows();task={'type':0,'category':'A'}
        a,ta=execute_reference(rows,task,0,0);b,tb=execute_reference(rows,task,1,0)
        self.assertEqual(a,b);self.assertEqual(a,{'skus':['S3','S4']});self.assertNotEqual(ta,tb)
        self.assertEqual(len(ta[0]['result']['items']),3)
    def test_skipped_relevant_rows_changes_answer(self):
        rows=self.rows();task={'type':0,'category':'B'}
        a,_=execute_reference(rows,task,0,0);b,_=execute_reference(rows,task,1,0)
        self.assertNotEqual(a,b);self.assertEqual(b,{'skus':[]})
    def test_page_before_first(self):
        a,t=execute_reference(self.rows(),{'type':0,'category':'A'},0,1)
        self.assertEqual(a,{'error':'PAGE_BEFORE_FIRST'});self.assertEqual(len(t),1)
    def test_wrong_status(self):
        a,_=execute_reference(self.rows(),{'type':0,'category':'A'},2,0);self.assertEqual(a,{'skus':[]})
    def test_gross_and_net(self):
        task={'type':1,'skus':['S0','S1']}
        for mode in range(8):
            a,_=execute_reference(self.rows(),task,mode,mode);self.assertEqual(a,{'available_total':12})
    def test_stock_mismatch(self):
        a,_=execute_reference(self.rows(),{'type':1,'skus':['S0']},0,4);self.assertEqual(a,{'available_total':10})
    def test_clamp(self):
        rows=self.rows();rows[0]['reserved']=20
        a,_=execute_reference(rows,{'type':1,'skus':['S0']},4,4);self.assertEqual(a,{'available_total':0})
    def test_available_filter(self):
        a,_=execute_reference(self.rows(),{'type':2,'category':'A','minimum':7},0,0);self.assertEqual(a,{'skus':[]})
    def test_empty_inventory_call_is_recorded(self):
        a,t=execute_reference(self.rows(),{'type':2,'category':'C','minimum':3},0,0)
        self.assertEqual(a,{'skus':[]});self.assertEqual(t[-1]['args'],{'skus':[]})
    def test_prediction_single_bit(self):
        table=[[[float(m!=z) for z in range(8)] for m in range(8)]]
        self.assertAlmostEqual(posterior_prediction([1,0,0],[.12]*3,0,table,0),.12)
    def test_prediction_zero_age(self):
        table=[[[float(m!=z) for z in range(8)] for m in range(8)]]
        self.assertEqual(posterior_prediction([0,0,0],[.12]*3,7,table,0),0.)

if __name__=='__main__':unittest.main()
