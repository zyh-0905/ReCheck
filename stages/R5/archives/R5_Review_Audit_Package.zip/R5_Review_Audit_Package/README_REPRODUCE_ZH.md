# R5审计附件复现

这不是新的实验执行包，不需要模型、密钥或用户重跑R5。只读以下三份已有ZIP：

1. 用户反馈`7bfb267f-104c-454b-a840-8f049baf3249.zip`（也接受其唯一内层R5_feedback ZIP）。
2. 最初交付`Research_Handoff_R5.zip`。
3. 研究端参考`R5_Offline_Results.zip`。

需要Python3.11+、numpy==2.3.5。审计脚本禁用网络，不修改输入，不执行未知的用户代码；只在与第2项原版逐字节匹配后导入原研究源码。临时目录中重建策略，另用标准库工具评测实现复算结果。

```bash
python -m unittest discover -s tests -v
python audit_r5.py --feedback /path/7bfb267f-104c-454b-a840-8f049baf3249.zip --kit /path/Research_Handoff_R5.zip --reference /path/R5_Offline_Results.zip --out /path/new_review_output
```

原始`audit/report.json`机械失败永远保留。新的`verification.json`单列数值等价验收；不得拿新文件覆盖原报告。

## 文件说明
- `audit_primitives.py`：独立执行器、金标准、标量预测、有限字段浮点比较。
- `audit_r5.py`：安全解压、哈希与绑定、标签重算、完整策略回放、独立评分、统计重建。
- `tests/`：26个正负例；修改答案、预算、包ID、类型和任务绑定会失败。
- `results/`：8192逐任务行、1024逐流行、全部配对比较、2152个浮点差异、计时及日期证据。
- `verification/`：原版45测试、新测试先失败后通过、两轮复核日志。
- `paired_exact_credit_units.csv`：将成本写为(20×失败＋额度)/20以消除派生统计求和残差；新增数值审计，不是新实验。

默认最多解压256 MiB，并检查路径、重名、符号链接和加密项。脚本的科研输出不是服务商、平台或人类同行认证。原始日志含有的本地路径和平台只按元数据记录，不作为身份认证。

SHA256SUMS.json用于本附件自身完整性检查，不是数字签名。原始实验无新增独立数据，不据此扩大论文样本量。
