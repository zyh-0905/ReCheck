#!/usr/bin/env python3
"""R5 feedback audit; local files only. Never alters input ZIPs or original run.
Usage: python audit_r5.py --feedback feedback.zip --kit Research_Handoff_R5.zip \
                        --reference R5_Offline_Results.zip --out results
Needs the original numpy==2.3.5 for exact same-code replay. Independent scoring
and cross-platform comparison are in audit_primitives.py (standard library).
"""
from pathlib import Path,PurePosixPath
from collections import Counter,defaultdict
from contextlib import contextmanager
import argparse,copy,csv,datetime,hashlib,io,json,math,os,platform,random,socket,stat,sys,tempfile,zipfile
from audit_primitives import (science_projection,compare_science,execute_reference,gold_reference,
                              rule_reference,posterior_prediction,PREDICTION_ATOL)

def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(o):return sha(canonical(o))
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,o):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_bytes(canonical(o)+b'\n')
def csvwrite(p,rows):
    if not rows:return
    with Path(p).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def csvread(p):
    with Path(p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def safe_unpack(raw,dest):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        seen=set();total=0
        for x in z.infolist():
            pp=PurePosixPath(x.filename);total+=x.file_size
            if (x.filename in seen or pp.is_absolute() or '..' in pp.parts or '\\' in x.filename
                or x.flag_bits&1 or stat.S_ISLNK(x.external_attr>>16)
                or total>256*1024**2 or x.file_size>100*1024**2):raise ValueError('unsafe ZIP')
            seen.add(x.filename)
            if not x.is_dir():
                p=Path(dest)/pp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(x))
        return {'entries':len(seen),'uncompressed_bytes':total}
@contextmanager
def no_network():
    old=(socket.socket,socket.create_connection,socket.getaddrinfo)
    def reject(*a,**kw):raise RuntimeError('R5 REVIEW: network prohibited')
    socket.socket=socket.create_connection=socket.getaddrinfo=reject
    try:yield
    finally:socket.socket,socket.create_connection,socket.getaddrinfo=old

def catalog(seed,profile='standard',n=23):
    rng=random.Random(seed);rows=[]
    for i in range(n):rows.append({'sku':f'SKU-{i:03d}','physical':rng.randint(0,25),'reserved':rng.randint(0,12),
                                  'category':rng.choice(['A','B','C']),'active':bool(rng.getrandbits(1))})
    if profile=='reservation_free_clustered':
        for r in rows:r['reserved']=0
        rows.sort(key=lambda r:(r['category'],r['sku']))
    return rows

def task(q,rows,seed):
    rng=random.Random(seed)
    return {'type':q if q<2 else 2,'category':rng.choice(['A','B','C']),
            'minimum':(3,12,22)[q-2] if q>=2 else 3,'skus':sorted(rng.sample([r['sku'] for r in rows],5))}

def independent_fit(ids):
    counts=[[[0]*8 for _ in range(8)] for _ in range(5)]
    for seed in ids:
        rows=catalog(seed)
        for q in range(5):
            t=task(q,rows,seed*100+q);truth=gold_reference(rows,t)
            for m in range(8):
                for z in range(8):
                    ans,_=execute_reference(rows,t,m,z);counts[q][m][z]+=int(ans!=truth)
    table=[[[v/len(ids) for v in mm] for mm in qq] for qq in counts]
    return counts,table

def find_nested_feedback(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist()
        if 'BUNDLE_MANIFEST.json' in names:return raw
        candidates=[n for n in names if n.endswith('.zip') and not n.startswith('__MACOSX/') and Path(n).name.startswith('R5_feedback_')]
        if len(candidates)!=1:raise ValueError('Expected one explicit R5 feedback ZIP')
        return z.read(candidates[0])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--feedback',required=True);ap.add_argument('--kit',required=True)
    ap.add_argument('--reference',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    paths={k:Path(getattr(args,k)).resolve() for k in ('feedback','kit','reference')}
    initial={k:sha(p.read_bytes()) for k,p in paths.items()}
    checks=[]
    def ck(name,condition,detail=None):
        checks.append({'check':name,'pass':bool(condition),'detail':detail})
    with tempfile.TemporaryDirectory(prefix='r5-review-') as tmp,no_network():
        tmp=Path(tmp);fb=tmp/'feedback';ref=tmp/'reference';orig=tmp/'original'
        outer=safe_unpack(paths['feedback'].read_bytes(),tmp/'outer')
        inner=find_nested_feedback(paths['feedback'].read_bytes())
        fi=safe_unpack(inner,fb);ri=safe_unpack(paths['reference'].read_bytes(),ref)
        safe_unpack(paths['kit'].read_bytes(),orig);kit=orig/'R5_Research_Kit'
        for label,base in [('feedback',fb),('reference',ref)]:
            manifest=read(base/'BUNDLE_MANIFEST.json');actual={p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
            ck(label+'_index_exact',actual==set(manifest['files'])|{'BUNDLE_MANIFEST.json'})
            errors=[k for k,v in manifest['files'].items() if sha((base/k).read_bytes())!=v['sha256'] or (base/k).stat().st_size!=v['bytes']]
            ck(label+'_hashes',not errors,{'listed':len(manifest['files']),'mismatches':errors})
        sm=read(kit/'SOURCE_MANIFEST.json');smhash=sha((kit/'SOURCE_MANIFEST.json').read_bytes())
        for label,base in [('kit_source',fb/'kit_source'),('run_snapshot',fb/'run/code_snapshot')]:
            errors=[k for k,v in sm['files'].items() if not (base/k).is_file() or (base/k).read_bytes()!=(kit/k).read_bytes() or sha((base/k).read_bytes())!=v]
            ck(label+'_matches_original',not errors,{'files':len(sm['files']),'differences':errors})
            ck(label+'_source_manifest',(base/'SOURCE_MANIFEST.json').read_bytes()==(kit/'SOURCE_MANIFEST.json').read_bytes())
        p=read(kit/'configs/protocol.json');m=read(fb/'run/manifest.json');train=read(fb/'run/calibration/fitted.json');val=read(fb/'run/private/validation.json')
        ck('protocol_frozen',p==m['protocol']);ck('source_binding',m['source_manifest_sha256']==smhash)
        ck('run_fingerprint',m['fingerprint']==digest({'protocol':p,'source':smhash}))
        ck('original_status_preserved',read(fb/'run/status.json')['state']=='completed')
        original_audit=read(fb/'run/audit/report.json')
        ck('original_only_issue_is_strict_reference_hash',original_audit['issues']==['reference scientific outputs differ: preserve records for review'])
        split=read(fb/'run/calibration/split_ids.json');all_ids=sum(split.values(),[])
        ck('disjoint_seed_sets',len(set(all_ids))==len(all_ids),{k:len(v) for k,v in split.items()})
        for name,obj in [('calibration',train),('validation',val)]:
            counts,table=independent_fit(split[name])
            ck(name+'_independent_tool_labels',counts==obj['failure_counts'] and table==obj['table'],{'executions':len(split[name])*320})
            n=copy.deepcopy(obj);fingerprint=n.pop('fingerprint');ck(name+'_fingerprint',digest(n)==fingerprint)
            ck(name+'_reference_exact',obj==read(ref/('run/calibration/fitted.json' if name=='calibration' else 'run/private/validation.json')))
        print('Verified immutable source and independent calibration/validation labels',flush=True)
        # Import only exact byte-matched original implementation, for same-code replay.
        sys.path.insert(0,str(kit))
        from r5lib import data,runtime,calibration,study,review
        cases=read(fb/'run/private/cases.json');regenerated=data.make_cases(p);ck('case_generation',cases==regenerated)
        ck('reference_cases_exact',cases==read(ref/'run/private/cases.json'))
        ck('unique_cases',len({digest(c) for c in cases})==len(cases))
        for c in cases:ck('catalog_independent_'+str(c['id']),c['rows']==catalog(c['seeds']['data'],c['profile'],p['catalog_size']))
        ids={c['id']:c for c in cases};expected_names={f'{c["id"]:03d}_{menu}_{method}.json' for c in cases for menu in p['menus'] for method in p['methods']}
        found={f.name for f in (fb/'run/trajectories').glob('*.json')};ck('trajectory_set_exact',expected_names==found,{'count':len(found)})
        predicted_diffs=[];trajectory_rows=[];primary=[];source_hashes=read(kit/'reference/scientific_hashes.json')
        feedback_hashes=read(fb/'run/audit/scientific_hashes.json');all_operational_hashes={}
        replay_numeric=0;scalar_max=0.;raw_matches=0;behavior_matches=0;replay_errors=[];budget_errors=[];record_errors=[]
        relevant=((0,1),(2,),(0,1,2),(0,1,2),(0,1,2))
        for menu in p['menus']:
            for method in p['methods']:
                solver=runtime.planner(method,p,menu,train)
                for case in cases:
                    name=f'{case["id"]:03d}_{menu}_{method}.json';rr=read(fb/'run/trajectories'/name);reference=read(ref/'run/trajectories'/name)
                    rscience=science_projection(rr);sci_reference=science_projection(reference)
                    ck('record_identity_'+name,(rr['stream'],rr['condition'],rr['menu'],rr['method'],rr['llm_calls'])==(case['id'],case['condition'],menu,method,0))
                    ck('record_binding_'+name,rr['case_sha256']==digest(case) and rr['calibration_fingerprint']==train['fingerprint'])
                    ck('reference_hash_valid_'+name,digest(sci_reference)==source_hashes[name])
                    ck('feedback_hash_valid_'+name,digest(rscience)==feedback_hashes[name])
                    same=digest(rscience)==source_hashes[name];raw_matches+=int(same)
                    compared=compare_science(reference,rr)
                    if compared['strict_differences']:record_errors.append({'file':name,'differences':compared['strict_differences']})
                    for d in compared['numeric_differences']:
                        predicted_diffs.append({'file':name,'path':'.'.join(map(str,d['path'])),'reference':d['reference'],'observed':d['observed'],'abs_error':d['abs_error'],
                                                'ulp_units':d['abs_error']/max(math.ulp(d['reference']),math.ulp(d['observed']))})
                    # Exact behavior fingerprint, excluding only known diagnostic probability.
                    rb=copy.deepcopy(rscience);sb=copy.deepcopy(sci_reference)
                    for a in (rb,sb):
                        for r in a['records']:r.pop('predicted_task_error_after_receipts')
                    beq=digest(rb)==digest(sb);behavior_matches+=int(beq);all_operational_hashes[name]=digest(rb)
                    replay=runtime.run_one(case,p,menu,method,train,solver)
                    repcheck=compare_science(replay,rr);replay_numeric+=len(repcheck['numeric_differences'])
                    if not repcheck['pass']:replay_errors.append({'file':name,'diffs':repcheck['strict_differences']})
                    bank=p['budget'];mem=case['initial_mode'];ages=(0,0,0);totalcost=0.;successes=0;credits=0;stales=0;harmless=0
                    ps={f's{i}':(1<<i,2) for i in range(3)}
                    if menu=='shared':ps.update({'p01':(3,3),'p12':(6,3)})
                    if len(rr['records'])!=len(case['steps']):record_errors.append({'file':name,'error':'record count'})
                    for r,e in zip(rr['records'],case['steps']):
                        old=mem;bb=bank;age_before=tuple(a+1 for a in ages)
                        pk=r['packets'];valid=(len(pk)==len(set(pk)) and all(k in ps for k in pk))
                        if not valid:budget_errors.append({'file':name,'step':r['step'],'error':'unknown/duplicate packets'});continue
                        cost=sum(ps[k][1] for k in pk);mask=0
                        for k in pk:mask|=ps[k][0]
                        cover=[j for j in range(3) if mask&(1<<j)]
                        if cost>bank or cost>p['step_cap']:budget_errors.append({'file':name,'step':r['step'],'error':'exceeded'})
                        mem=(mem&(~mask&7))|(e['true_mode']&mask);bank-=cost
                        ages=tuple(0 if j in cover else age_before[j] for j in range(3))
                        fields=(r['q']==e['q'] and r['remaining_horizon']==p['steps']-r['step'] and r['ages_before']==list(age_before)
                            and r['memory_before']==old and r['memory_after']==mem and r['budget_before']==bb and r['budget_after']==bank
                            and r['credits']==cost and r['cover']==cover and r['plan']==rule_reference(e['task'],mem))
                        if not fields:record_errors.append({'file':name,'step':r['step'],'error':'state or plan'})
                        answer,trace=execute_reference(case['rows'],e['task'],mem,e['true_mode']);truth=gold_reference(case['rows'],e['task'])
                        if answer!=r['answer'] or trace!=r['trace']:record_errors.append({'file':name,'step':r['step'],'error':'independent tool output'})
                        fail=int(answer!=truth);ns=sum(bool((mem^e['true_mode'])&(1<<j)) for j in relevant[e['q']])
                        pred=posterior_prediction(ages,p['hazards'],mem,train['table'],e['q']);scalar_max=max(scalar_max,abs(pred-r['predicted_task_error_after_receipts']))
                        if abs(pred-r['predicted_task_error_after_receipts'])>PREDICTION_ATOL:record_errors.append({'file':name,'step':r['step'],'error':'scalar prediction'})
                        row={'stream':case['id'],'condition':case['condition'],'menu':menu,'method':method,'step':r['step'],'q':e['q'],
                             'failure':fail,'success':1-fail,'credits':cost,'budget_after':bank,'task_cost':fail+p['credit_price']*cost,
                             'semantic_mismatches':ns,'stale_but_correct':int(ns>0 and not fail),'fresh_but_wrong':int(ns==0 and fail),
                             'page_error':int(answer.get('error')=='PAGE_BEFORE_FIRST'),'predicted_failure':r['predicted_task_error_after_receipts'],
                             'planning_seconds':r['planning_seconds'],'probe_seconds':r['probe_seconds'],'tool_seconds':r['tool_seconds']}
                        primary.append(row);totalcost+=row['task_cost'];successes+=1-fail;credits+=cost;stales+=ns;harmless+=row['stale_but_correct']
                    trajectory_rows.append({'stream':case['id'],'condition':case['condition'],'menu':menu,'method':method,
                         'successes':successes,'failures':p['steps']-successes,'credits':credits,'task_cost':totalcost,
                         'semantic_mismatches':stales,'stale_but_correct':harmless,'raw_reference_hash_equal':same,
                         'operational_reference_equal':beq,'prediction_float_differences':len(compared['numeric_differences'])})
                solver.clear();print('Replayed and independently scored',menu,method,flush=True)
        ck('strict_outcome_and_identity_comparison',not record_errors,record_errors[:10]);ck('hard_budget',not budget_errors,budget_errors[:10])
        ck('same_code_replay',not replay_errors,{'trajectories':len(trajectory_rows),'task_records':len(primary),'strict_errors':replay_errors[:10],
                                              'numeric_prediction_differences':replay_numeric})
        csvwrite(out/'prediction_float_differences.csv',predicted_diffs);csvwrite(out/'per_task.csv',primary);csvwrite(out/'per_stream.csv',trajectory_rows)
        write(out/'operational_hashes.json',all_operational_hashes)
        submitted=csvread(fb/'run/audit/per_task.csv');ck('independent_scoring_rows',len(submitted)==len(primary))
        scorediffs=[]
        for i,(a,b) in enumerate(zip(submitted,primary)):
            for k in a:
                equal=(a[k]==str(b[k])) if isinstance(b[k],str) else float(a[k])==b[k]
                if not equal:scorediffs.append((i,k,a[k],b[k]))
        ck('submitted_per_task_independent_match',not scorediffs,scorediffs[:8])
        # Aggregation does not call the original review.aggregate implementation.
        g=defaultdict(list)
        for row in primary:g[(row['condition'],row['menu'],row['method'])].append(row)
        sums=[]
        for key,rs in sorted(g.items()):
            successes=sum(r['success'] for r in rs);cr=sum(r['credits'] for r in rs);j=sum(r['task_cost'] for r in rs)
            sums.append({'condition':key[0],'menu':key[1],'method':key[2],'tasks':len(rs),'successes':successes,'failures':len(rs)-successes,
                         'credits':cr,'task_cost':j,'semantic_mismatches':sum(r['semantic_mismatches'] for r in rs),
                         'stale_but_correct':sum(r['stale_but_correct'] for r in rs),'success_rate':successes/len(rs),
                         'mean_task_cost':j/len(rs),'mean_brier':sum((r['predicted_failure']-r['failure'])**2 for r in rs)/len(rs)})
        csvwrite(out/'summary.csv',sums)
        summary_sub=csvread(fb/'run/audit/summary.csv');bad=[]
        for i,(a,b) in enumerate(zip(summary_sub,sums)):
            for k in a:
                equal=a[k]==b[k] if isinstance(b[k],str) else abs(float(a[k])-b[k])<=1e-13
                if not equal:bad.append((i,k))
        ck('independent_summary_match',not bad and len(sums)==len(summary_sub),bad)
        # Reconstruct frozen descriptive resampling protocol from independent scores.
        import numpy as np
        rng=np.random.default_rng(p['statistics']['resample_seed']);R=p['statistics']['bootstrap_repetitions']
        totals={(r['condition'],r['stream'],r['menu'],r['method']):r['task_cost'] for r in trajectory_rows};stats=[]
        contrasts=[('task_exact','any_exact'),('task_exact','semantic_exact'),('task_exact','single_effect_exact'),('task_rollout2','task_exact'),('task_myopic','task_exact')]
        def statrow(condition,menu,label,values):
            v=np.array(values);boot=v[rng.integers(0,len(v),(R,len(v)))].mean(axis=1);lo,hi=np.quantile(boot,[.025,.975])
            return {'condition':condition,'menu':menu,'contrast':label,'independent_streams':len(v),'mean_stream_cost_difference':float(v.mean()),
                    'ci_low':float(lo),'ci_high':float(hi),'status':'DESCRIPTIVE_NOT_CONFIRMATORY'}
        for c in p['conditions']:
            name=c['name'];sids=sorted(x['id'] for x in cases if x['condition']==name)
            for menu in p['menus']:
                for a,b in contrasts:stats.append(statrow(name,menu,a+' minus '+b,[totals[(name,i,menu,a)]-totals[(name,i,menu,b)] for i in sids]))
            for method in p['methods']:stats.append(statrow(name,'paired_shared_minus_single',method,[totals[(name,i,'shared',method)]-totals[(name,i,'single',method)] for i in sids]))
        csvwrite(out/'paired.csv',stats);ck('independent_paired_statistics_exact',(out/'paired.csv').read_bytes()==(fb/'run/audit/paired.csv').read_bytes())
        # Exact 1/20 credit units are a supplemental audit, never overwrite old statistics.
        exact_totals={(r['condition'],r['stream'],r['menu'],r['method']):20*r['failures']+r['credits'] for r in trajectory_rows}
        exact_rng=np.random.default_rng(p['statistics']['resample_seed']);exact_stats=[]
        def exact_stat(condition,menu,label,values):
            vv=np.asarray(values,dtype=np.int64)
            boot=vv[exact_rng.integers(0,len(vv),(R,len(vv)))].sum(axis=1)/(20*len(vv))
            lo,hi=np.quantile(boot,[.025,.975])
            return {'condition':condition,'menu':menu,'contrast':label,'independent_streams':len(vv),
                    'mean_stream_cost_difference':sum(values)/(20*len(vv)),'ci_low':float(lo),'ci_high':float(hi),
                    'status':'NUMERIC_AUDIT_EXACT_CREDIT_UNITS_NOT_NEW_DATA'}
        for c in p['conditions']:
            cn=c['name'];sids=sorted(x['id'] for x in cases if x['condition']==cn)
            for mn in p['menus']:
                for a,b in contrasts:
                    exact_stats.append(exact_stat(cn,mn,a+' minus '+b,[exact_totals[(cn,i,mn,a)]-exact_totals[(cn,i,mn,b)] for i in sids]))
            for method in p['methods']:
                exact_stats.append(exact_stat(cn,'paired_shared_minus_single',method,[exact_totals[(cn,i,'shared',method)]-exact_totals[(cn,i,'single',method)] for i in sids]))
        csvwrite(out/'paired_exact_credit_units.csv',exact_stats)
        ck('exact_units_agree_with_float_statistics',all(abs(a[k]-b[k])<=1e-13 for a,b in zip(stats,exact_stats) for k in ('mean_stream_cost_difference','ci_low','ci_high')))

        # Post hoc explain the invalid one-sided normalized-hash diagnostic.
        normalization=[]
        for rule in ['remove_prediction','round_prediction_6','round_prediction_12']:
            bilateral=0;onesided=0
            for name in sorted(found):
                a=science_projection(read(ref/'run/trajectories'/name));b=science_projection(read(fb/'run/trajectories'/name))
                for x in (a,b):
                    for r in x['records']:
                        if rule=='remove_prediction':r.pop('predicted_task_error_after_receipts')
                        else:r['predicted_task_error_after_receipts']=round(r['predicted_task_error_after_receipts'],int(rule.rsplit('_',1)[-1]))
                bilateral+=digest(a)==digest(b);onesided+=digest(b)==source_hashes[name]
            normalization.append({'rule':rule,'both_sides_same_transform_matches':bilateral,'only_local_transformed_vs_original_hash_matches':onesided})
        write(out/'hash_diagnostic_explanation.json',normalization)
        # Reference model expectation recomputed, never provided to live planner.
        diag=study.model_diagnostics(p,train,val);observed=read(fb/'run/model_validation.json');modeldiff=[]
        ck('model_validation_rows',len(diag)==len(observed))
        for i,(a,b) in enumerate(zip(diag,observed)):
            for k in a:
                if isinstance(a[k],float):
                    if a[k]!=b[k]:modeldiff.append({'row':i,'key':k,'reference':a[k],'observed':b[k],'abs_error':abs(a[k]-b[k])})
                    ck('model_expected_value_'+str(i)+'_'+k,math.isfinite(b[k]) and abs(a[k]-b[k])<=1e-13)
                else:ck('model_label_'+str(i)+'_'+k,a[k]==b[k])
        write(out/'model_expectation_differences.json',modeldiff)
        sf=csvread(ref/'run/audit/summary.csv');uf=summary_sub;sd=[]
        for i,(a,b) in enumerate(zip(sf,uf)):
            for k in a:
                if a[k]!=b[k]:sd.append({'row':i,'key':k,'reference':a[k],'observed':b[k],'abs_error':abs(float(a[k])-float(b[k]))})
        write(out/'summary_last_bit_differences.json',sd)
        # Timing is reported as recorded measurements, not required to reproduce.
        timing=[]
        for method in ('task_exact','task_rollout2','task_myopic'):
            xs=[r for r in read(fb/'run/scaling.json') if r['horizon']==8 and r['method']==method]
            timing.append({'method':method,'horizon':8,'replicates':len(xs),'mean_cold_seconds':sum(r['cold_initial_policy_seconds'] for r in xs)/len(xs),
                           'min_cold_seconds':min(r['cold_initial_policy_seconds'] for r in xs),'max_cold_seconds':max(r['cold_initial_policy_seconds'] for r in xs),
                           'peak_traced_bytes':max(r['peak_traced_python_bytes'] for r in xs),
                           'value_states':xs[0]['value_states'],'scope':'recorded two-repeat initial-policy benchmark; not complete rollout or RSS'})
        csvwrite(out/'user_planning_costs.csv',timing)
        execution=read(fb/'run/execution_summary.json');start=datetime.datetime.fromisoformat(execution['wall_started']);end=datetime.datetime.fromisoformat(execution['wall_finished'])
        timezone=datetime.timezone(datetime.timedelta(hours=8));write(out/'time_evidence.json',{'protocol_date':p['date'],'raw_start':start.isoformat(),'raw_end':end.isoformat(),
            'UTC_plus_8_start':start.astimezone(timezone).isoformat(),'UTC_plus_8_end':end.astimezone(timezone).isoformat(),
            'run_stage_seconds':execution['wall_seconds'],'scope':'timestamps as recorded; protocol label is not the runtime clock; excludes prepare/audit/export'})
        report={'decision':'ACCEPT_WITH_DOCUMENTED_NUMERIC_EQUIVALENCE','raw_mechanical_pass_preserved':original_audit['mechanical_pass'],
            'raw_reference_hash_match_preserved':original_audit['reference_science_match'],
            'input_hashes':initial,'inner_feedback_sha256':sha(inner),'archive':fi,'source_files':len(sm['files']),
            'reference_raw_hash_matches':raw_matches,'reference_raw_hash_mismatches':len(found)-raw_matches,
            'exact_operational_projection_matches':behavior_matches,'prediction_differing_leaves':len(predicted_diffs),
            'prediction_abs_error_max':max([r['abs_error'] for r in predicted_diffs],default=0),
            'prediction_ulp_error_max':max([r['ulp_units'] for r in predicted_diffs],default=0),
            'allowed_field':'records[i].predicted_task_error_after_receipts','numeric_atol':PREDICTION_ATOL,'numeric_rtol':0,
            'scalar_prediction_abs_error_max':scalar_max,'independent_task_records':len(primary),'policy_trajectories':len(found),
            'independent_base_streams':len(cases),'calibration_workflow_labels':len(split['calibration'])*320,'validation_workflow_labels':len(split['validation'])*320,
            'strict_comparison_errors':len(record_errors),'budget_errors':len(budget_errors),'original_report_unmodified':True,
            'summary_differing_float_cells':len(sd),'model_expectation_differing_float_leaves':len(modeldiff),
            'new_llm_calls':0,'new_independent_experimental_samples':0,'scientific_verdict':'same frozen data; does not establish superiority',
            'environment':{'platform':platform.platform(),'python':sys.version.split()[0],'numpy':np.__version__},
            'raw_user_environment':{k:m[k] for k in ('platform','python','numpy')},'checks':checks}
        report['input_archives_unchanged']={k:sha(v.read_bytes())==initial[k] for k,v in paths.items()}
        report['all_checks_passed']=all(c['pass'] for c in checks) and all(report['input_archives_unchanged'].values())
        if not report['all_checks_passed']:report['decision']='REVIEW_REQUIRED'
        write(out/'verification.json',report)
        print(json.dumps({k:v for k,v in report.items() if k not in ('checks',)},ensure_ascii=False,indent=2))
        return 0 if report['all_checks_passed'] else 2

if __name__=='__main__':raise SystemExit(main())
