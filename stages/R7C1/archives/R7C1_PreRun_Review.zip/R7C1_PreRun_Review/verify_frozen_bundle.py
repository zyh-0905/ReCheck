"""Research-side checks only. No provider requests and no native task execution."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import ast, collections, hashlib, importlib, json, socket, stat, sys, tempfile

EXPECTED_ZIP_SHA = '60e5e182c6f256b320cf7a2a19ce2b5c50ef690510e90765765a8e507d44fe84'
ROOT_PREFIX = 'R7C1_Research_Kit/'

def deny_network(*a, **k):
    raise RuntimeError('This verification does not permit network calls')

socket.create_connection = deny_network
socket.socket.connect = deny_network
socket.socket.connect_ex = deny_network

archive = Path(sys.argv[1])
output = Path(sys.argv[2])
archive_before = hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_before == EXPECTED_ZIP_SHA, 'Unexpected frozen archive'
with ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(names))
    assert sum(i.file_size for i in z.infolist()) < 100_000_000
    for i in z.infolist():
        p = PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
        assert not stat.S_ISLNK(i.external_attr >> 16)
        assert i.filename.startswith(ROOT_PREFIX)
        assert not i.flag_bits & 1
    manifest = json.loads(z.read(ROOT_PREFIX+'SOURCE_MANIFEST.json'))['sha256']
    assert set(names) == {ROOT_PREFIX+n for n in manifest} | {ROOT_PREFIX+'SOURCE_MANIFEST.json'}
    for name, sha in manifest.items():
        assert hashlib.sha256(z.read(ROOT_PREFIX+name)).hexdigest() == sha, name
    upstream = json.loads(z.read(ROOT_PREFIX+'UPSTREAM_MANIFEST.json'))['sha256']
    for name, sha in upstream.items():
        assert manifest['vendor/toolsandbox/'+name] == sha
    protocol = json.loads(z.read(ROOT_PREFIX+'protocol.json'))
    cfg = json.loads(z.read(ROOT_PREFIX+'config.example.json'))
    cases = json.loads(z.read(ROOT_PREFIX+'fixtures/cases.json'))
    assert protocol['task_id'] == 'R7C1_NATIVE_AGENT_DIAGNOSIS_01'
    assert protocol['version'] == 'r7c-1.0.1'
    assert len(cases) == 14 and len({c['id'] for c in cases}) == 14
    assert protocol['primary_episodes'] == 42 and protocol['repeat_episodes'] == 6
    assert protocol['max_turns_per_episode'] == 8
    assert protocol['max_main_calls'] == (42+6)*8 == 384
    assert protocol['smoke_cap'] == 1
    assert cfg['model'] == 'deepseek-v4-flash'
    family_counts = dict(collections.Counter(c['family'] for c in cases))
    syntax_count=0
    for n in names:
        if n.endswith('.py'):
            ast.parse(z.read(n).decode('utf-8'), filename=n, feature_version=(3,11))
            syntax_count += 1
    with tempfile.TemporaryDirectory(prefix='r7c1_identity_') as td:
        z.extractall(td)
        root=Path(td)/'R7C1_Research_Kit'
        sys.path.insert(0, str(root))
        identity = importlib.import_module('r7clib.identity')
        RunStopped = importlib.import_module('pilot.client').RunStopped
        recorded = json.loads((root/'docs/PAUSED_SMOKE_RESPONSE.json').read_text())
        before = json.dumps(recorded,sort_keys=True)
        ident = identity.response_identity(cfg,recorded['response'])
        assert ident['returned_model']=='deepseek-flash' and ident['weight_identity_verified'] is False
        assert json.dumps(recorded,sort_keys=True)==before
        checks=1
        for label in ('deepseek-v4-flash','deepseek-flash'):
            r=identity.response_identity(cfg,{'model':label,'system_fingerprint':'test-fp'})
            assert r['requested_model']=='deepseek-v4-flash' and r['returned_model']==label
            checks+=1
        for label,fp in [('other','fp'),('deepseek-flash-extra','fp'),('', 'fp'),(None,'fp'),
                         ('deepseek-flash',None),('deepseek-flash',''),('deepseek-flash','   '),
                         ('deepseek-flash',False)]:
            try: identity.response_identity(cfg,{'model':label,'system_fingerprint':fp})
            except RunStopped: checks+=1
            else: raise AssertionError(('rejection failed',label,fp))
        bad=dict(cfg);bad['model']='deepseek-flash'
        try: identity.response_identity(bad, recorded['response'])
        except RunStopped: checks+=1
        else: raise AssertionError('requested model change allowed')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==archive_before
result = {
    'stage':'R7C1_PRE_RUN_READINESS_RECHECK', 'protocol_date_label':'2026-09-13',
    'archive_sha256':archive_before,'archive_bytes':archive.stat().st_size,
    'registered_files_checked':len(manifest),'upstream_files_checked':len(upstream),
    'python311_syntax_files_checked':syntax_count,'identity_policy_checks':checks,
    'identity_checks_scope':'pure response_identity function; not full transport/native integration retest',
    'cases':len(cases),'family_counts':family_counts,
    'primary_episodes':42,'repeat_episodes':6,'turn_cap':8,
    'main_request_attempt_cap':384,'new_smoke_cap':1,'current_package_cap':385,
    'recorded_prior_smoke':1,'lineage_cap':386,
    'new_remote_llm_calls':0,'new_native_study_results':0,
    'original_package_modified':False,'mechanical_checks_pass':True,
    'real_R7C1_results_available_this_turn':False,
    'full_native_suite_rerun_this_turn':False,'human_independent_review':False,
    'user_action':'Run existing frozen R7C1 once, or export existing started/completed R7C1 without new requests',
    'scope':'Version/hashes/schema/syntax and archived-response identity logic only. No runtime performance or scientific superiority claims.'
}
output.parent.mkdir(parents=True,exist_ok=True)
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
