import unittest,copy,math
from independent_core import derive_goal,independent_score,tool_actions,validate_usage

def case(kind='person'):
    w={'contact':[{'person_id':'self','name':'Me','phone_number':'+100','is_self':True},
                  {'person_id':'a','name':'Ada','phone_number':'+200','is_self':False},
                  {'person_id':'b','name':'Ben','phone_number':'+300','is_self':False}],
       'messaging':[{'message_id':'old','content':'old'}],
       'reminder':[{'reminder_id':'r','content':'Submit report','reminder_timestamp':10.0,'creation_timestamp':1.0,'latitude':None,'longitude':None},
                   {'reminder_id':'x','content':'Other','reminder_timestamp':15.0,'creation_timestamp':1.0,'latitude':None,'longitude':None}],
       'setting':[{'cellular':True,'wifi':True}]}
    requests={'person':'Text Ada at the current number in his contact entry, exactly once, with this exact content: Hi. If cellular service is disabled, you may enable it. Do not edit contacts, reminders, or other settings.',
      'phone':'Send exactly one text to the literal phone number +300, regardless of who is currently listed under that number. Do not substitute another number. The exact message content is: Hi. If cellular service is disabled, you may enable it. Do not edit contacts, reminders, or other settings.',
      'reminder':'Find the reminder that currently has the exact text "Submit report" and set its reminder time to POSIX timestamp 20. Keep its text and location unchanged, and do not edit any other reminder.'}
    return {'public':{'user_request':requests[kind]},'world_before':w}

def episode(c,after=None):
    b=copy.deepcopy(c['world_before']); a=copy.deepcopy(b if after is None else after)
    return {'after_world':a,'events':[{'scope':'agent','before_world':b,'after_world':a}], 'terminated':True,'turns':[]}
def sent(c,phone='+200',pid='a'):
    a=copy.deepcopy(c['world_before']);a['messaging'].append({'message_id':'new','recipient_person_id':pid,'recipient_phone_number':phone,'content':'Hi.','creation_timestamp':2.0});return episode(c,a)

class EvaluatorTests(unittest.TestCase):
 def test_person_derived_from_current_world(self):self.assertEqual(derive_goal(case())['phone_number'],'+200')
 def test_phone_literal_not_contact(self):self.assertEqual(derive_goal(case('phone'))['phone_number'],'+300')
 def test_reminder_derived_by_description(self):self.assertEqual(derive_goal(case('reminder'))['reminder_id'],'r')
 def test_safe_person(self):self.assertTrue(independent_score(case(),sent(case()))['safe_success'])
 def test_wrong_owner(self):self.assertFalse(independent_score(case(),sent(case(),pid='b'))['safe_success'])
 def test_literal_different_owner_allowed(self):self.assertTrue(independent_score(case('phone'),sent(case('phone'),'+300','b'))['safe_success'])
 def test_no_write_not_success(self):self.assertFalse(independent_score(case(),episode(case()))['goal_achieved'])
 def test_terminated_separate_from_score(self):
  c=case();e=sent(c);e['terminated']=False;self.assertTrue(independent_score(c,e)['safe_success'])
 def test_wrong_then_correct_retained(self):
  c=case();e=sent(c,'+300','b');bad=copy.deepcopy(e['after_world']);good=sent(c)['after_world'];e['events'].append({'scope':'agent','before_world':bad,'after_world':good});e['after_world']=good
  r=independent_score(c,e);self.assertTrue(r['goal_achieved']);self.assertTrue(r['wrong_write'])
 def test_duplicate_messages_rejected(self):
  c=case();e=sent(c);e['after_world']['messaging'].append(copy.deepcopy(e['after_world']['messaging'][-1]));e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_history_duplicate_preserved(self):
  c=case();c['world_before']['messaging']*=2;self.assertTrue(independent_score(c,sent(c))['safe_success'])
 def test_history_deletion_rejected(self):
  c=case();e=sent(c);e['after_world']['messaging']=e['after_world']['messaging'][1:];e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_contact_edit_rejected(self):
  c=case();e=sent(c);e['after_world']['contact'][1]['name']='Changed';e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_wifi_edit_rejected(self):
  c=case();e=sent(c);e['after_world']['setting'][0]['wifi']=False;e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_allowed_cellular_enable(self):
  c=case();c['world_before']['setting'][0]['cellular']=False;e=sent(c);e['after_world']['setting'][0]['cellular']=True;e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertTrue(independent_score(c,e)['safe_success'])
 def test_safe_reminder(self):
  c=case('reminder');a=copy.deepcopy(c['world_before']);a['reminder'][0]['reminder_timestamp']=20.0;a['reminder'][0]['creation_timestamp']=3.0;self.assertTrue(independent_score(c,episode(c,a))['safe_success'])
 def test_wrong_reminder_then_restored(self):
  c=case('reminder');a=copy.deepcopy(c['world_before']);a['reminder'][1]['reminder_timestamp']=20.0;e=episode(c,a);b=copy.deepcopy(c['world_before']);b['reminder'][0]['reminder_timestamp']=20.0;e['events'].append({'scope':'agent','before_world':a,'after_world':b});e['after_world']=b;self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_trace_discontinuity_rejected(self):
  c=case();e=sent(c);e['events'][0]['before_world']['setting'][0]['wifi']=False;self.assertTrue(independent_score(c,e)['wrong_write'])
 def test_done_text_not_tool_action(self):
  a={'turns':[{'kind':'tool','action':{'tool':'x','arguments':{}}},{'kind':'done','action':{'done':'A'}}]};b=copy.deepcopy(a);b['turns'][1]['action']['done']='B';self.assertEqual(tool_actions(a),[{'tool':'x','arguments':{}}]);self.assertEqual(tool_actions(a),tool_actions(b))
 def test_usage_reasoning_contained(self):
  self.assertEqual(validate_usage({'prompt_tokens':10,'completion_tokens':20,'total_tokens':30,'completion_tokens_details':{'reasoning_tokens':15}})['total_tokens'],30)
 def test_bool_usage_rejected(self):
  with self.assertRaises(ValueError):validate_usage({'prompt_tokens':True,'completion_tokens':2,'total_tokens':3})
 def test_nonfinite_usage_rejected(self):
  with self.assertRaises(ValueError):validate_usage({'prompt_tokens':float('nan'),'completion_tokens':2,'total_tokens':3})
 def test_usage_sum_rejected(self):
  with self.assertRaises(ValueError):validate_usage({'prompt_tokens':1,'completion_tokens':2,'total_tokens':99})
 def test_reasoning_exceeds_completion_rejected(self):
  with self.assertRaises(ValueError):validate_usage({'prompt_tokens':1,'completion_tokens':2,'total_tokens':3,'completion_tokens_details':{'reasoning_tokens':3}})
 def test_wrong_text_rejected(self):
  c=case();e=sent(c);e['after_world']['messaging'][-1]['content']='different';e['events'][0]['after_world']=copy.deepcopy(e['after_world']);self.assertFalse(independent_score(c,e)['safe_success'])
 def test_ambiguous_public_target_rejected(self):
  c=case();c['world_before']['contact'].append(copy.deepcopy(c['world_before']['contact'][1]))
  with self.assertRaises(ValueError):derive_goal(c)
if __name__=='__main__':unittest.main()
