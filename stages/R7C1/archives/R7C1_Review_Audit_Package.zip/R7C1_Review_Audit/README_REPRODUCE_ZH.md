# R7C1审核附件：无付费调用

本包是审核证据，不是新实验运行包；用户无需执行。原始输入ZIP与执行包不在本附件中重复分发。

## 标准库独立审核

```bash
python -m unittest discover -s tests -v
python audit_feedback.py --feedback /path/125a1ad6-6919-49c8-8c07-78e488a33edb.zip --kit /path/Research_Handoff_R7C1.zip --out /path/new_audit_results
```

独立检查ZIP完整性、源码、账本、逐步消息、公开目标、全部状态、副作用和usage；不调用原生评分函数，也不联网。接受外层用户ZIP或内层自动导出ZIP。内部JSON哈希不得更改；所有结果写到新目录。

## 原版原生重放

使用具有原执行包依赖的Python3.11解释器：

```bash
python3.11 native_replay.py --feedback /path/user_feedback.zip --kit /path/Research_Handoff_R7C1.zip --out /path/new_native_audit
```

此命令在临时目录加载经过固定摘要检查的原始源代码，禁用网络，仅读取已保存的模型响应，重建168个研究请求、原生工具轨迹与48个结果。UUID/时钟来自留存轨迹，不能算新样本。

研究端采用已核验wheel模块目录时，可以加`--dependencies /path/to/validated_wheel_modules`并使用`python3.11 -S`启动。不要求用户重新下载任何材料，不调用smoke/run，不读API密钥。

`results/native_replay`为原版派生报告；`results/repeat_diagnostics.csv`是本次新增分层重复分析。两者口径区别见核查报告。报告和数据SHA见MANIFEST.json。任何运行环境错误只记录，不改变实验或原始响应。
