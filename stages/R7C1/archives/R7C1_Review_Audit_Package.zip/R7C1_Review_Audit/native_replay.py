#!/usr/bin/env python3
"""Reconstruct with the unmodified R7C1 native tools in a temporary directory.
Needs Python 3.11 and the original requirements. --dependencies optionally points
to a directory of validated unpacked wheel modules for a -S interpreter.
All network sockets are disabled before importing the execution engine.
"""
import argparse,sys,socket,tempfile,shutil,json,os
from pathlib import Path
from audit_feedback import read_zip,sha,EXPECTED_KIT

def main():
    p=argparse.ArgumentParser();p.add_argument('--feedback',required=True);p.add_argument('--kit',required=True);p.add_argument('--out',required=True);p.add_argument('--dependencies');a=p.parse_args()
    if sys.version_info[:2]!=(3,11):raise RuntimeError('Native replay requires Python 3.11')
    def deny(*a,**k):raise RuntimeError('OFFLINE REPLAY: all network connections disabled')
    socket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny
    os.environ['POLARS_MAX_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
    b=Path(a.kit).read_bytes()
    if sha(b)!=EXPECTED_KIT:raise ValueError('Original kit digest differs')
    src=read_zip(b);prefix=next(iter(src)).split('/')[0]+'/'
    dat=read_zip(Path(a.feedback).read_bytes())
    if 'BUNDLE_MANIFEST.json' not in dat:
        ins=[v for n,v in dat.items() if n.endswith('.zip') and not n.startswith('__MACOSX/')]
        if len(ins)!=1:raise ValueError('Expected one inner zip')
        dat=read_zip(ins[0])
    with tempfile.TemporaryDirectory(prefix='r7c1_native_replay_') as tmp:
        root=Path(tmp)
        for n,v in src.items():
            t=root/n[len(prefix):];t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(v)
        for n,v in dat.items():
            if n=='PREPARED.json' or n.startswith('runs/'):
                t=root/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(v)
        if a.dependencies:sys.path.insert(0,str(Path(a.dependencies).resolve()))
        sys.path[:0]=[str(root),str(root/'vendor/toolsandbox')]
        from r7clib.audit import audit
        result=audit(root)
        out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
        for f in (root/'offline_reports').iterdir():shutil.copy2(f,out/f.name)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if result['mechanical_pass'] and result['execution_complete'] else 2
if __name__=='__main__':raise SystemExit(main())
