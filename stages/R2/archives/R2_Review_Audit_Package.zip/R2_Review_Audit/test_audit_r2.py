"""Small adversarial regression tests for the independent evaluator; no network."""
import copy,unittest
from audit_r2 import valid_plan,score

def example():
    c={'cents':[100,200,300], 'tasks':[{'type':1,'cutoff':1,'modes':[0,1]}]}
    r={'step':0,'worker_view':{'memory':{'amount_divisor':1,'endpoint_inclusive':True,'checked_at':[0,0]}},'plan':{'amount_divisor':None,'time_bound':1},'answer':{'total':None,'count':2},'tool_result':{'count_before':2},'logical_calls':['p','a'],'plan_json_error':None,'answer_json_error':None}
    calls={k:{'response':{'choices':[{'finish_reason':'stop'}]}} for k in ['p','a']}
    return r,c,calls
class AuditTests(unittest.TestCase):
    def test_valid_count(self):
        r,c,b=example();self.assertTrue(score(r,c,b)['end_to_end_success'])
    def test_unused_field_rejected_even_correct_bound(self):
        r,c,b=example();r['plan']['amount_divisor']=1
        self.assertFalse(valid_plan(r['plan'],c['tasks'][0]));self.assertTrue(score(r,c,b)['interface_failure'])
    def test_both_time_bounds_inclusive(self):
        t={'type':1,'cutoff':9}
        self.assertTrue(valid_plan({'amount_divisor':None,'time_bound':8},t));self.assertTrue(valid_plan({'amount_divisor':None,'time_bound':11},t))
    def test_actual_bound_outside_rejected(self):
        self.assertFalse(valid_plan({'amount_divisor':None,'time_bound':7},{'type':1,'cutoff':9}))
    def test_valid_old_value_still_stale(self):
        r,c,b=example();r['worker_view']['memory']['endpoint_inclusive']=False;r['plan']['time_bound']=2;r['tool_result']['count_before']=3;r['answer']['count']=3
        e=score(r,c,b);self.assertTrue(e['stale_related']);self.assertTrue(e['stale_propagation_consistent']);self.assertFalse(e['end_to_end_success'])
    def test_stale_exposure_not_automatically_wrong(self):
        r,c,b=example();r['worker_view']['memory']['endpoint_inclusive']=False
        e=score(r,c,b);self.assertTrue(e['stale_related']);self.assertTrue(e['end_to_end_success']);self.assertFalse(e['stale_propagation_consistent'])
    def test_irrelevant_staleness_does_not_count(self):
        r,c,b=example();r['worker_view']['memory']['amount_divisor']=100
        e=score(r,c,b);self.assertEqual(e['amount_status'],'stale');self.assertFalse(e['stale_related']);self.assertTrue(e['end_to_end_success'])
    def test_timestamp_does_not_imply_freshness(self):
        r,c,b=example();r['worker_view']['memory']['endpoint_inclusive']=False;r['worker_view']['memory']['checked_at']=[100,100]
        self.assertEqual(score(r,c,b)['endpoint_status'],'stale')
    def test_current_evidence_but_bad_answer(self):
        r,c,b=example();r['answer']['count']=3;e=score(r,c,b)
        self.assertFalse(e['stale_related']);self.assertFalse(e['answer_follows_tool_and_plan']);self.assertFalse(e['end_to_end_success'])
    def test_truncation_not_rescored_success(self):
        r,c,b=example();b['a']['response']['choices'][0]['finish_reason']='length';self.assertFalse(score(r,c,b)['end_to_end_success'])
    def test_missing_call_invalidates(self):
        r,c,b=example();b.pop('a');self.assertEqual(score(r,c,b)['missing_call_records'],1);self.assertFalse(score(r,c,b)['end_to_end_success'])
    def test_float_count_value_correct_but_schema_wrong(self):
        r,c,b=example();r['answer']['count']=2.0;e=score(r,c,b)
        self.assertTrue(e['answer_value_correct']);self.assertFalse(e['end_to_end_success'])
    def test_bool_not_numeric_count(self):
        r,c,b=example();r['answer']['count']=True;self.assertFalse(score(r,c,b)['answer_schema_valid'])
    def test_no_input_mutation(self):
        r,c,b=example();previous=copy.deepcopy((r,c,b));score(r,c,b);self.assertEqual((r,c,b),previous)
if __name__=='__main__':unittest.main(verbosity=2)
