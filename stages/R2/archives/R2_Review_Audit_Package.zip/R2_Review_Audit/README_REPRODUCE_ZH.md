# R2审核包复核方法

本包不包含API客户端调用流程、不包含密钥、不重新采样模型。它需要用户已经持有的两个原始ZIP：Research_Handoff_R2.zip与本次6ce67d0a-9d3f-4804-8453-06a57df12a50.zip。

使用Python 3.11+、numpy==2.3.5（与研究代码一致）。无需联网执行审核；没有依赖时可使用原研究虚拟环境。

```bash
python -m unittest -v test_audit_r2
python audit_r2.py --feedback /path/to/6ce67d0a-9d3f-4804-8453-06a57df12a50.zip --original /path/to/Research_Handoff_R2.zip --out fresh_audit
```

审核器在临时目录解压，先匹配原交付包固定SHA-256，然后只导入该原版代码。socket连接在审核进程中禁用。原始输入不写入，临时副本中的汇总重建不改变上传ZIP。

per_task_independent.csv为独立评分；paired_treatment_audit.csv区分动作、请求、语义及相关语义；failure_evidence.json保留原计划与答案；AUDIT_RESULT.json为机器可读决定。

original_tests.txt是本次重新执行的原91项软件测试日志，包含本机HTTP fixture，不是模型实验。independent_tests.txt为另写的14项评分边界测试。没有Windows/macOS本次实机复核。

注意LICENSE是原版导出遗漏：审核明确记录，不补写原始run。summarize在临时副本中会发现此非运行文件缺失，这是唯一允许的既有summary结构差异。日志/哈希不是权重身份、发票或独立人类审稿认证。
