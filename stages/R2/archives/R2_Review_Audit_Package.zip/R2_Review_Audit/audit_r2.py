#!/usr/bin/env python3
"""R2 offline audit. Standard library + numpy from the original experiment.
Runs only hash-verified ORIGINAL code through a frozen-response client.
All socket connections are disabled during audit. Originals remain untouched.
"""
from __future__ import annotations
import argparse, collections, copy, csv, hashlib, io, json, math, pathlib, socket, stat, sys, tempfile, zipfile
from datetime import datetime
EXPECTED_ORIGINAL='f799eed31472fde3d426ee9ce78348d87b94595c95b3d32fa17bf4867892ab5d'
ENDPOINT='https://api.deepseek.com/v1'

def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(x): return sha(canonical(x).encode())
def read(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def write(p,x): pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def require(ok,msg):
    if not ok: raise AssertionError(msg)
def unpack(z,root):
    entries=z.infolist();names=set();size=0
    for i in entries:
        n=i.filename;p=pathlib.PurePosixPath(n)
        require(n not in names,'duplicate archive name');names.add(n)
        require(not p.is_absolute() and '..' not in p.parts and '\\' not in n and not (p.parts and ':' in p.parts[0]),'unsafe archive name')
        require(not stat.S_ISLNK(i.external_attr>>16),'archive symlink')
        require(not i.flag_bits&1,'encrypted archive')
        size+=i.file_size;require(i.file_size<=50_000_000 and size<=250_000_000,'archive size limit')
    for i in entries:
        if i.is_dir() or i.filename.startswith('__MACOSX/') or pathlib.PurePosixPath(i.filename).name=='.DS_Store':continue
        p=root/i.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(i))
    return {'entries_including_metadata':len(entries),'uncompressed_bytes':size}
def csvwrite(p,rows):
    if not rows:return
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with pathlib.Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})
def close(a,b):return isinstance(a,(int,float)) and not isinstance(a,bool) and math.isfinite(a) and abs(a-b)<=1e-6
def numeric(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def valid_plan(p,t):
    if not isinstance(p,dict) or set(p)!={'amount_divisor','time_bound'}:return False
    q=t['type'];a,b=p['amount_divisor'],p['time_bound']
    if q in (0,2):
        if not numeric(a) or a not in (1,100):return False
    elif a is not None:return False
    if q in (1,2):
        if type(b) is not int or not t['cutoff']-1<=b<=t['cutoff']+2:return False
    elif b is not None:return False
    return True
def score(r,c,byid):
    t=c['tasks'][r['step']];q=t['type'];m=r['worker_view']['memory'];p=r['plan'];a=r['answer'];tool=r['tool_result']
    ast='missing_or_invalid' if not numeric(m.get('amount_divisor')) or m['amount_divisor'] not in (1,100) else ('fresh' if m['amount_divisor']==(100 if t['modes'][0] else 1) else 'stale')
    est='missing_or_invalid' if type(m.get('endpoint_inclusive')) is not bool else ('fresh' if m['endpoint_inclusive']==bool(t['modes'][1]) else 'stale')
    relevant=([ast] if q==0 else [est] if q==1 else [ast,est] if q==2 else [])
    exp_total=sum(c['cents'])/100 if q in (0,2) else None
    exp_count=(len(c['cents']) if q==3 else sum(i<=t['cutoff'] for i in range(len(c['cents'])))) if q in (1,2,3) else None
    av=isinstance(a,dict) and set(a)=={'total','count'}
    if av:
        av=(numeric(a['total']) if q in (0,2) else a['total'] is None) and (type(a['count']) is int if q in (1,2,3) else a['count'] is None)
    value=isinstance(a,dict) and set(a)=={'total','count'}
    if value:value=(a['total'] is None if exp_total is None else close(a['total'],exp_total)) and (a['count'] is None if exp_count is None else numeric(a['count']) and a['count']==exp_count)
    pv=valid_plan(p,t)
    missing=sum(k not in byid for k in r['logical_calls'])
    truncated=any(byid[k]['response']['choices'][0]['finish_reason']=='length' for k in r['logical_calls'] if k in byid)
    parse=r.get('plan_json_error') is not None or r.get('answer_json_error') is not None
    pf=bool(pv and 'missing_or_invalid' not in relevant and (q not in (0,2) or p['amount_divisor']==m['amount_divisor']) and (q not in (1,2) or p['time_bound']==t['cutoff']+int(not m['endpoint_inclusive'])))
    af=bool(av and pv and 'error' not in tool and (q not in (0,2) or close(a['total'],tool['sum_amount_raw']/p['amount_divisor'])) and (q not in (1,2,3) or a['count']==tool.get('count_before',tool.get('count_all'))))
    ref=None
    if 'missing_or_invalid' not in relevant:
        rt=(sum(c['cents']) if t['modes'][0] else sum(c['cents'])/100)/m['amount_divisor'] if q in (0,2) else None
        bound=t['cutoff']+int(not m['endpoint_inclusive']) if q in (1,2) else None
        rc=(sum((i<=bound if t['modes'][1] else i<bound) for i in range(len(c['cents']))) if q in (1,2) else len(c['cents']) if q==3 else None)
        ref=(exp_total is None or close(rt,exp_total)) and (exp_count is None or rc==exp_count)
    ok=bool(value and av and pv and 'error' not in tool and not truncated and not parse and missing==0)
    return {'amount_status':ast,'endpoint_status':est,'stale_related':'stale' in relevant,'missing_related':'missing_or_invalid' in relevant,
      'plan_schema_valid_recomputed':pv,'answer_schema_valid':bool(av),'interface_failure':not pv or 'error' in tool,'json_parse_failure':parse,
      'truncated':truncated,'missing_call_records':missing,'answer_value_correct':bool(value),'end_to_end_success':ok,
      'reference_executor_correct':ref,'plan_follows_supplied_memory':pf,'answer_follows_tool_and_plan':af,
      'stale_propagation_consistent':bool('stale' in relevant and not value and pf and af and not parse)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--feedback',required=True);ap.add_argument('--original',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    inp=pathlib.Path(args.feedback).resolve();original=pathlib.Path(args.original).resolve();out=pathlib.Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    before={str(p):sha(p.read_bytes()) for p in (inp,original)}
    require(before[str(original)]==EXPECTED_ORIGINAL,'Original distribution hash mismatch: do not execute untrusted code')
    report={'source_inputs_sha256':before,'new_model_calls':0,'classification':'REAL_ENDPOINT_CONTROLLED_DEVELOPMENT','findings':[]}
    with tempfile.TemporaryDirectory(prefix='r2_offline_audit_') as td:
        td=pathlib.Path(td);raw=td/'feedback';orig=td/'original'
        with zipfile.ZipFile(inp) as z:
            outer=unpack(z,td/'outer');zn=[n for n in z.namelist() if n.endswith('.zip') and not n.startswith('__MACOSX/')]
            require(len(zn)==1,'Expected one canonical R2 feedback zip')
            data=z.read(zn[0]);report['inner_zip_sha256']=sha(data)
            with zipfile.ZipFile(io.BytesIO(data)) as zi:report['inner_zip_structure']=unpack(zi,raw)
        with zipfile.ZipFile(original) as z:unpack(z,orig)
        kit=orig/'R2_Research_Kit'
        manifest=read(raw/'BUNDLE_MANIFEST.json');actual={p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file()}
        require(actual==set(manifest['sha256'])|{'BUNDLE_MANIFEST.json'},'Manifest file set differs')
        for name,h in manifest['sha256'].items():require(sha((raw/name).read_bytes())==h,'Manifest hash '+name)
        report['bundle_verified_entries']=len(manifest['sha256'])
        source=read(kit/'SOURCE_MANIFEST.json')['sha256'];sources=[]
        require((raw/'kit_source/SOURCE_MANIFEST.json').read_bytes()==(kit/'SOURCE_MANIFEST.json').read_bytes(),'source manifest differs')
        for prefix in ['kit_source','runs/R2_smoke/code_snapshot','runs/R2_recheck/code_snapshot']:
            missing=[];good=0
            for rel,h in source.items():
                require(sha((kit/rel).read_bytes())==h,'original source mismatch')
                f=raw/prefix/rel
                if not f.exists():missing.append(rel);continue
                require(sha(f.read_bytes())==h,'source copy differs '+str(f));good+=1
            require(not missing or missing==['LICENSE'],'Runtime source missing')
            sources.append({'prefix':prefix,'matched_files':good,'missing_files':missing})
        report['source_copies']=sources
        report['findings'].append('Exporter omits extensionless LICENSE from both run snapshots; the identical license is available under kit_source. Non-runtime packaging issue, not a changed algorithm.')
        # Guard audit process against every network connection. Never instantiate the API client.
        def forbidden(*a,**kw):raise RuntimeError('Network disabled in offline audit')
        socket.socket.connect=forbidden;socket.socket.connect_ex=forbidden;socket.create_connection=forbidden
        sys.path.insert(0,str(kit));sys.dont_write_bytecode=True
        from r2lib import review,protocol,accounting
        from pilot.common import request_payload
        spec=read(kit/'configs/r2_protocol.json');allcalls=[];runs={};summaries={};prep=read(raw/'offline_reports/PREPARED.json')
        for name,n in [('R2_smoke',1),('R2_recheck',484)]:
            root=raw/'runs'/name;m=read(root/'manifest.json')
            require(m['source_hashes']==source,'frozen source dictionary differs')
            contract={k:m[k] for k in ('version','config','study','spec','billing_schedule','source_hashes')}
            require(digest(contract)==m['fingerprint'],'manifest fingerprint')
            require(m['config']['base_url_sha256']==digest(ENDPOINT),'endpoint binding')
            cfg=copy.deepcopy(m['config']);cfg.pop('base_url_sha256');cfg['base_url']=ENDPOINT
            require(digest(cfg)==prep['config_sha256'],'prepared config differs')
            require(digest(m['billing_schedule'])==prep['billing_sha256'],'prepared billing differs')
            if name=='R2_recheck':require(m['spec']==spec,'protocol changed')
            ss=[read(p) for p in sorted((root/'attempts').glob('*_start.json'))]
            rr=[read(p) for p in sorted((root/'attempts').glob('*_result.json'))]
            sends=[read(p) for p in sorted((root/'attempts').glob('*_send_intent.json'))]
            cp={p:read(p) for p in (root/'calls').glob('*.json')};cc={c['logical_id']:c for c in cp.values()}
            require(len(ss)==len(rr)==len(sends)==len(cc)==n,'wrong request counts')
            require(len({s['logical_id'] for s in ss})==n,'retries or duplicate logical IDs')
            require([s['attempt'] for s in ss]==list(range(1,n+1)),'non-sequential attempts')
            prev=None
            for st,res,send in zip(ss,rr,sends):
                for k,v in st.items():require(res[k]==v,'start/result mismatch '+k)
                require(res==cc[st['logical_id']],'result/call mismatch')
                require(send['attempt']==st['attempt'] and send['logical_id']==st['logical_id'],'send mismatch')
                require(digest(st['payload'])==st['payload_sha256'],'payload hash')
                require(digest({'endpoint':ENDPOINT,'payload':st['payload']})==st['request_sha256'],'request hash')
                require(request_payload(cfg,st['payload']['messages'])==st['payload'],'request settings changed')
                require(res['status']=='ok' and res['response']['choices'][0]['finish_reason']=='stop','unsuccessful response')
                require(res['text']==res['response']['choices'][0]['message']['content'],'text not raw content')
                require(isinstance(json.loads(res['text']),dict),'invalid JSON')
                a,b,c=[datetime.fromisoformat(x) for x in (st['started_utc'],send['local_send_intent_utc'],res['ended_utc'])]
                require(a<=b<=c,'timestamp order');require(prev is None or prev<=a,'overlapping serial attempts');prev=c
                u=res['response']['usage'];require(u['total_tokens']==u['prompt_tokens']+u['completion_tokens'],'usage total')
                require(u['prompt_cache_hit_tokens']+u['prompt_cache_miss_tokens']==u['prompt_tokens'],'cache total')
                require(u['prompt_tokens_details']['cached_tokens']==u['prompt_cache_hit_tokens'],'cache fields')
                require(0<=u['completion_tokens_details']['reasoning_tokens']<=u['completion_tokens'],'reasoning count')
                require(res['estimated_cost'] is None,'unexpected fee')
                require(res['response']['model']==cfg['model'],'model ID changed')
                require(not accounting.normalize_usage(u)['issues'],'usage normalization')
            for p,c in cp.items():require(p.stem==digest(c['logical_id']),'call filename')
            events=[json.loads(l) for l in (root/'run_events.jsonl').read_text().splitlines() if l]
            require(sum(e['event']=='invocation_started' for e in events)==sum(e['event']=='invocation_ended' for e in events)==1,'Unexpected invocations')
            require(read(root/'status.json')['state']=='completed','run not complete')
            runs[name]={'registered':len(ss),'send_intents':len(sends),'responses':len(rr),'calls':len(cc),'request_errors':0,'truncated':0,'invalid_json':0,'unknown_attempts':0,'created_utc':m['created_utc'],'finished_utc':read(root/'status.json')['updated_utc'],'returned_model':cfg['model'],'invocation_wall_seconds':sum(e.get('wall_seconds',0) for e in events),'sum_model_call_latency_seconds':sum(c['latency_seconds'] for c in cc.values()),'input_tokens':sum(c['response']['usage']['prompt_tokens'] for c in cc.values()),'output_tokens':sum(c['response']['usage']['completion_tokens'] for c in cc.values()),'reasoning_tokens':sum(c['response']['usage']['completion_tokens_details']['reasoning_tokens'] for c in cc.values())}
            old=read(root/'summary.json');old_tables={n:(root/n).read_bytes() for n in ('per_call.csv','per_task.csv','method_summary.csv') if (root/n).exists()};new=review.summarize(root)
            for fn,blob in old_tables.items():require((root/fn).read_bytes()==blob,'submitted table differs '+name+'/'+fn)
            # The source export bug is expected to produce a LICENSE warning only after exporting.
            require(new['source_snapshot_mismatches']==['LICENSE'],'unexpected snapshot warning')
            require({k:v for k,v in new.items() if k!='source_snapshot_mismatches'}=={k:v for k,v in old.items() if k!='source_snapshot_mismatches'},'summary differs beyond export omission')
            summaries[name]=new;allcalls+=list(cc.values())
        report['runs']=runs
        require(len({c['response']['id'] for c in allcalls})==485,'duplicate response ID')
        require(len({c['response']['system_fingerprint'] for c in allcalls})==1,'identity fingerprint changed')
        report['unique_response_ids']=485;report['model_identity_caveat']='Provider-returned label and fingerprint only; not independent weight authentication.'
        require(runs['R2_smoke']['finished_utc']<runs['R2_recheck']['created_utc'],'smoke not completed first')
        require(digest(spec)==prep['protocol_sha256'] and digest(source)==prep['source_sha256'],'prepared protocol/source hash')
        pre=protocol.preflight(spec);require(pre==read(raw/'offline_reports/PREFLIGHT.json'),'preflight differs')
        require(review.regression_checks()==read(raw/'offline_reports/REGRESSION.json'),'regression differs')
        require(review.repair_cost_diagnostic()==read(raw/'offline_reports/REPAIR_COST_DIAGNOSTIC.json'),'prior repair diagnostic differs')
        report['preflight']=pre
        run=raw/'runs/R2_recheck';old_replay=read(run/'replay_audit.json');replay=review.replay_check(run);require(replay==old_replay,'submitted replay summary differs');require(replay['pass'] and replay['request_bodies_checked']==484,'frozen replay failed');report['replay']=replay
        byid={c['logical_id']:c for c in allcalls};cases={c['stream']:c for c in read(run/'private/recheck_cases.json')}
        records=[read(p) for p in sorted((run/'records').glob('*.json'))];require(len(records)==240,'record count')
        expected_csv={(int(x['stream']),int(x['step']),x['method']):x for x in csv.DictReader((run/'per_task.csv').open(encoding='utf-8-sig'))}
        pairs=collections.defaultdict(dict);rows=[];failures=[]
        for r in records:
            sid,t,m=r['stream'],r['step'],r['method'];pairs[sid,t][m]=r;case=cases[sid];task=case['tasks'][t]
            e=score(r,case,byid)
            for k,v in e.items():require(str(v)==expected_csv[sid,t,m][k],f'independent score mismatch {sid},{t},{m},{k}')
            for i,phase in enumerate(['plan','answer']):require(json.loads(byid[r['logical_calls'][i]]['text'])==r[phase],'record parsed answer differs')
            row={'stream':sid,'step':t,'method':m,'task_type':task['type'],'cutoff':task['cutoff'] if task['type'] in (1,2) else None,'probe_count':r['probe_count'],'proxy_cost_not_currency':r['model_probe_cost'],**e}
            rows.append(row)
            if not e['end_to_end_success']:
                reason='stale_propagation_consistent' if e['stale_propagation_consistent'] else 'interface_unused_amount' if e['interface_failure'] and task['type'] not in (0,2) and r['plan']['amount_divisor'] is not None else 'answer_inconsistent_with_tool' if not e['answer_follows_tool_and_plan'] else 'other'
                f={'source_record':f'records/rc_{sid:03d}_{t:03d}_{m}.json',**row,'diagnostic_label':reason,'memory':r['worker_view']['memory'],'plan':r['plan'],'tool_result':r['tool_result'],'answer':r['answer'],'expected_count':sum(i<=task['cutoff'] for i in range(len(case['cents']))) if task['type'] in (1,2) else None,'logical_calls':r['logical_calls']}
                if e['interface_failure']:
                    fixed=copy.deepcopy(r['plan']);fixed['amount_divisor']=None
                    f['plan_valid_if_only_unused_amount_set_null']=valid_plan(fixed,task)
                    f['actual_allowed_time_range']=[task['cutoff']-1,task['cutoff']+2]
                    f['time_bound_inside_range']=task['cutoff']-1<=r['plan']['time_bound']<=task['cutoff']+2
                    f['not_rescored']='Diagnostic only; original failure is retained.'
                failures.append(f)
        report['independently_scored_records']=240
        report['distinct_stale_exposure_task_positions']=len({(r['stream'],r['step']) for r in rows if r['stale_related']})
        compare=[]
        scores={(r['stream'],r['step'],r['method']):r for r in rows}
        for (sid,t),g in sorted(pairs.items()):
            a,b=g['recheck'],g['myopic'];ma=a['worker_view']['memory'];mb=b['worker_view']['memory'];q=a['task_type']
            keys=(['amount_divisor'] if q==0 else ['endpoint_inclusive'] if q==1 else ['amount_divisor','endpoint_inclusive'] if q==2 else [])
            samefacts=all(ma[k]==mb[k] for k in ['amount_divisor','endpoint_inclusive']);samerelevant=all(ma[k]==mb[k] for k in keys)
            sameplan=byid[a['logical_calls'][0]]['payload']==byid[b['logical_calls'][0]]['payload'];sameans=byid[a['logical_calls'][1]]['payload']==byid[b['logical_calls'][1]]['payload']
            ra=scores[sid,t,'recheck'];rb=scores[sid,t,'myopic']
            compare.append({'stream':sid,'step':t,'task_type':q,'same_probe_choice':a['probed_channels']==b['probed_channels'],'same_plan_payload':sameplan,'same_answer_payload':sameans,'same_all_semantics':samefacts,'same_task_relevant_semantics':samerelevant,'only_checked_at_differs':not sameplan and samefacts,'recheck_probes':a['probed_channels'],'myopic_probes':b['probed_channels'],'recheck_checked_at':ma['checked_at'],'myopic_checked_at':mb['checked_at'],'recheck_success':ra['end_to_end_success'],'myopic_success':rb['end_to_end_success'],'recheck_reference_correct':ra['reference_executor_correct'],'myopic_reference_correct':rb['reference_executor_correct'],'recheck_answer':a['answer'],'myopic_answer':b['answer']})
        report['treatment_summary']={'task_positions':48,'probe_decision_differences':sum(not r['same_probe_choice'] for r in compare),'plan_payload_differences':sum(not r['same_plan_payload'] for r in compare),'only_checked_at_differences':sum(r['only_checked_at_differs'] for r in compare),'all_semantic_differences':sum(not r['same_all_semantics'] for r in compare),'task_relevant_semantic_differences':sum(not r['same_task_relevant_semantics'] for r in compare),'recheck_only_success':sum(r['recheck_success'] and not r['myopic_success'] for r in compare),'myopic_only_success':sum(r['myopic_success'] and not r['recheck_success'] for r in compare)}
        aggs=[];streamrows=[]
        for m in spec['methods']:
            rs=[r for r in rows if r['method']==m];cs=[c for c in allcalls if c['metadata'].get('method')==m]
            aggs.append({'method':m,'tasks':len(rs),'successes':sum(x['end_to_end_success'] for x in rs),'success_rate':sum(x['end_to_end_success'] for x in rs)/len(rs),'stale_related':sum(x['stale_related'] for x in rs),'stale_consistent_errors':sum(x['stale_propagation_consistent'] for x in rs),'interface_errors':sum(x['interface_failure'] for x in rs),'other_errors':sum(not x['end_to_end_success'] and not x['stale_propagation_consistent'] and not x['interface_failure'] for x in rs),'reference_executor_successes':sum(x['reference_executor_correct'] for x in rs),'probe_count':sum(x['probe_count'] for x in rs),'proxy_cost_NOT_CURRENCY':sum(x['proxy_cost_not_currency'] for x in rs),'input_tokens':sum(x['response']['usage']['prompt_tokens'] for x in cs),'output_tokens':sum(x['response']['usage']['completion_tokens'] for x in cs),'reasoning_tokens':sum(x['response']['usage']['completion_tokens_details']['reasoning_tokens'] for x in cs),'cached_input_tokens':sum(x['response']['usage']['prompt_cache_hit_tokens'] for x in cs),'model_call_latency_seconds':sum(x['latency_seconds'] for x in cs),'actual_money':None})
            for sid in cases:
                sr=[r for r in rs if r['stream']==sid]
                streamrows.append({'stream':sid,'method':m,'successes':sum(x['end_to_end_success'] for x in sr),'reference_successes':sum(x['reference_executor_correct'] for x in sr),'probes':sum(x['probe_count'] for x in sr),'records':len(sr)})
        report['method_results']=aggs
        report['failure_counts']=dict(collections.Counter(f['diagnostic_label'] for f in failures))
        changes=[]
        for sid,c in cases.items():
            old=c['initial_modes'];ev=[]
            for t,task in enumerate(c['tasks']):
                if old!=task['modes']:ev.append({'step':t,'type':task['type'],'before':old,'after':task['modes'],'flipped_channels':[i for i,(a,b) in enumerate(zip(old,task['modes'])) if a!=b]})
                old=task['modes']
            changes.append({'stream':sid,'regime':c['regime'],'changes':ev})
        report['world_changes']=changes
        report['freshness_note']='checked_at[j] is the 1-indexed round of the latest performed probe (0=initial calibration), not elapsed age. Current round equal to checked_at means a probe really occurred this round.'
        report['execution_verdict']='ACCEPT_CONTROLLED_DEVELOPMENT_NO_RERUN_OF_R2'
        report['science_verdict']='NO_SUPERIORITY_EVIDENCE; TRUE RELEVANT TREATMENT AT TWO POSITIONS ONLY'
        report['currency']='UNKNOWN_NO_CURRENT_PRICE_LOOKUP_NO_INVOICE'
        report['artifact_snapshot_warning']='The exported run snapshots omit LICENSE by suffix allowlist. Exact kit_source/LICENSE matches original. Original in-place summary predates export and reports no missing file. Do not blame operator or alter raw archive.'
        callrows=[]
        for c in sorted(allcalls,key=lambda x:x['started_utc']):
            u=c['response']['usage'];meta=c['metadata'];callrows.append({'logical_id':c['logical_id'],'attempt':c['attempt'],'phase':meta.get('phase'),'method':meta.get('method','shared_prefix_or_smoke'),'response_id':c['response']['id'],'started_utc':c['started_utc'],'ended_utc':c['ended_utc'],'finish_reason':c['response']['choices'][0]['finish_reason'],'input_tokens':u['prompt_tokens'],'output_tokens':u['completion_tokens'],'reasoning_tokens':u['completion_tokens_details']['reasoning_tokens'],'cached_input_tokens':u['prompt_cache_hit_tokens'],'latency_seconds':c['latency_seconds'],'price':None,'payload_sha256':c['payload_sha256']})
        csvwrite(out/'per_task_independent.csv',rows);csvwrite(out/'method_results.csv',aggs);csvwrite(out/'per_stream.csv',streamrows);csvwrite(out/'paired_treatment_audit.csv',compare);csvwrite(out/'per_call_audit.csv',callrows)
        write(out/'failure_evidence.json',failures);write(out/'paired_evidence.json',compare)
        write(out/'offline_replay_result.json',replay);write(out/'reference_preflight_recomputed.json',pre)
    after={str(p):sha(p.read_bytes()) for p in (inp,original)};require(after==before,'input files modified')
    report['original_archives_unchanged']=True
    write(out/'AUDIT_RESULT.json',report)
    print(json.dumps({'execution_verdict':report['execution_verdict'],'bundle_hashes':report['bundle_verified_entries'],'requests_replayed':484,'records_independently_scored':240,'new_model_calls':0,'treatment':report['treatment_summary'],'failure_counts':report['failure_counts']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
