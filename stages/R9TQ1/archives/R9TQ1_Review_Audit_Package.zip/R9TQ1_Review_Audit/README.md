# R9TQ1 feedback review package

This package is an offline audit, **not a paid experiment runner**. No user action is required.

- `Review_Report_ZH.md`: findings and research gate.
- `Factual_Corrections_ZH.md`: cache-count correction and interpretation limits.
- `results/`: independent qualification, request ledger, receipt links, original/native test results.
- `evidence/input_feedback.zip`: exact uploaded outer ZIP, preserved.
- `evidence/frozen_execution_kit.zip`: exact original R9TQ1 kit, for code comparison.
- `scripts/review.py`: independent standard-library ledger/history/state audit.
- `scripts/native_check.py`: separate native replay and original-software test launcher.
- `tests/`: independent scoring, token accounting, JSON and re-signed-corruption tests.
- `logs/`: commands' actual outputs, including audit-development red phase.

## Optional offline reproduction

From this directory, Python 3.11+ (standard-library audit only):

```bash
python -m unittest discover -s tests -v
python scripts/review.py --feedback evidence/input_feedback.zip --kit evidence/frozen_execution_kit.zip --output reproduced
```

These commands do not install dependencies, read credentials, or make model requests. Do not invoke the archived kit's `qualify` command. They recompute existing evidence only, not new model samples.

Native replay additionally needs the previously supplied Python 3.11/Polars0.20.31/NumPy1.26.4 environment. `scripts/native_check.py audit` runs on a copy containing the frozen kit plus the received PREPARED/runs, without the export-only BUNDLE_MANIFEST at the root. The script's --deps and --rouge are local existing module paths. Native identifiers and clocks are replayed from existing traces; no new model answers are generated. Recorded native results and environment restoration hashes are included so the large runtime archives need not be duplicated here.

The original artifacts' terms remain in their own LICENSE/ACKNOWLEDGEMENTS. This review is not a third-party peer review or provider attestation. Byte hashes authenticate consistency with supplied bytes, not remote model weights or account billing.
