"""Run frozen native tests/audit against a copy. This script never requests a remote model."""
import argparse,sys,pathlib,json,os,socket,unittest,shutil
p=argparse.ArgumentParser();p.add_argument('mode',choices=['tests','audit']);p.add_argument('--root',required=True);p.add_argument('--deps',required=True);p.add_argument('--rouge',required=True);p.add_argument('--output',required=True);a=p.parse_args()
root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(root),str(root/'vendor/toolsandbox'),a.deps,a.rouge]
os.chdir(root)
connect=socket.socket.connect;connect_ex=socket.socket.connect_ex
# Tests can use a loopback fixture; all other connections are blocked. Audit is all-offline.
def allowed(address):return a.mode=='tests' and isinstance(address,tuple) and address[0] in ('localhost','127.0.0.1','::1')
def guarded(self,address):
 if not allowed(address):raise RuntimeError('Remote network prohibited during review')
 return connect(self,address)
def guarded_ex(self,address):
 if not allowed(address):raise RuntimeError('Remote network prohibited during review')
 return connect_ex(self,address)
socket.socket.connect=guarded;socket.socket.connect_ex=guarded_ex
import numpy,polars,scipy
info={'python':sys.version.split()[0],'numpy':numpy.__version__,'polars':polars.__version__,'scipy':scipy.__version__,'remote_requests':0,'mode':a.mode}
if a.mode=='tests':
 sys.path.insert(0,str(root/'tests'))
 suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern='test*.py')
 r=unittest.TextTestRunner(verbosity=2).run(suite)
 info.update(tests_run=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped),passed=r.wasSuccessful())
else:
 from tq.audit import audit
 before=json.loads((root/'runs/AUDIT.json').read_text())
 result=audit(root);info.update(audit=result,input_audit_equal=(result==before),passed=result.get('mechanical_pass',False))
 # The completed-state branch must not create a new request or access a key.
 from tq.runtime import qualify
 def no_exchange(*args,**kwargs):raise AssertionError('Completed run tried to sample again')
 before_files={str(x.relative_to(root)):x.read_bytes() for x in (root/'runs').rglob('*') if x.is_file()}
 result2=qualify(root,12,secret='REVIEW_DUMMY_NO_REMOTE',exchange=no_exchange)
 after_files={str(x.relative_to(root)):x.read_bytes() for x in (root/'runs').rglob('*') if x.is_file()}
 info['completed_no_resampling']=before_files==after_files and result2['status']=='completed'
 info['passed']=info['passed'] and info['completed_no_resampling'] and info['input_audit_equal']
out.write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(info,ensure_ascii=False,indent=2));sys.exit(0 if info['passed'] else 1)
