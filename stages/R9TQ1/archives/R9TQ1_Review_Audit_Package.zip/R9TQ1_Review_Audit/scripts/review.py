"""Independent, standard-library audit of R9TQ1 evidence. No model/network calls.
Uses original public tasks to derive qualification targets; does not call tq/legacy scoring.
"""
from __future__ import annotations
import argparse,ast,copy,csv,hashlib,io,json,math,re,stat,sys,zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path,PurePosixPath

def require(condition,message):
    if not condition: raise ValueError(message)
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(x):return hashlib.sha256(x).hexdigest()
def dig(x):return sha(canon(x).encode())
def strict(text):
    def pairs(items):
        d={}
        for k,v in items:
            require(k not in d,'Duplicate key');d[k]=v
        return d
    def bad(v):raise ValueError('Non-finite JSON')
    obj=json.loads(text,object_pairs_hook=pairs,parse_constant=bad)
    def finite(x):
        if type(x) is float:require(math.isfinite(x),'Infinite float')
        elif type(x) is dict:
            for v in x.values():finite(v)
        elif type(x) is list:
            for v in x:finite(v)
    finite(obj);return obj

def usage(u):
    require(type(u) is dict,'Missing usage')
    def integer(x):require(type(x) is int and x>=0,'Invalid count');return x
    ni=integer(u['prompt_tokens']);no=integer(u['completion_tokens']);nt=integer(u['total_tokens'])
    require(ni+no==nt,'Token conservation failed')
    detail=u.get('completion_tokens_details',{});nr=integer(detail.get('reasoning_tokens',0));require(nr<=no,'Reasoning exceeds output')
    cached=integer(u.get('prompt_cache_hit_tokens',u.get('prompt_tokens_details',{}).get('cached_tokens',0)))
    require(cached<=ni,'Cache exceeds input')
    if 'cached_tokens' in u.get('prompt_tokens_details',{}):require(cached==integer(u['prompt_tokens_details']['cached_tokens']),'Cache mismatch')
    miss=integer(u.get('prompt_cache_miss_tokens',ni-cached));require(miss+cached==ni,'Cache conservation failed')
    return dict(prompt_tokens=ni,completion_tokens=no,total_tokens=nt,reasoning_tokens=nr,cached_input_tokens=cached,uncached_input_tokens=miss)

def bag(rows):return Counter(canon(x) for x in rows)
def normalize(world):return {k:sorted(v,key=canon) for k,v in world.items()}
def equal(a,b,label):require(canon(a)==canon(b),'Mismatch: '+label)
def worlds_equal(a,b):return canon(normalize(a))==canon(normalize(b))
def added(before,after):
    count=bag(before);rows=[]
    for r in after:
        s=canon(r)
        if count[s]:count[s]-=1
        else:rows.append(r)
    return rows

def derive(case):
    text=case['public']['user_request']
    if text.startswith('Use get_cellular_service_status'):
        return {'kind':'read'}
    if 'explicit phone number' in text:
        phone=re.search(r'explicit phone number (\+\d+)',text).group(1)
        content=text.split('The exact message is: ',1)[1].split(' You may enable cellular service',1)[0]
        return {'kind':'phone','phone':phone,'content':content}
    m=re.search(r'whose text is exactly "([^"]+)".*?POSIX timestamp (\d+)',text)
    require(m is not None,'Unrecognized public task')
    return {'kind':'reminder','title':m.group(1),'due':float(m.group(2))}

def score(case,result):
    spec=derive(case);base=copy.deepcopy(case['world_before']);current=copy.deepcopy(base);wrong=False;issues=[];ok_count=0;lookups=0
    for i,e in enumerate(result['events']):
        require(worlds_equal(current,e['before_world']),'World discontinuity')
        require(e['scope']=='agent','Unexpected external event')
        before=e['before_world'];after=e['after_world'];resp=e['response'];tool=e['tool'];args=e['arguments']
        require(type(resp['ok']) is bool,'Invalid tool status')
        ok_count+=int(resp['ok']);allowed=copy.deepcopy(before);bad=False
        if not resp['ok']:
            bad=not worlds_equal(before,after)
        elif tool.startswith('get_') or tool.startswith('search_'):
            bad=not worlds_equal(before,after)
            if tool=='get_cellular_service_status':equal(resp['value'],before['setting'][0]['cellular'],'Cellular result')
            if tool in ('search_messages','search_reminder','search_contacts'):
                ns={'search_messages':'messaging','search_reminder':'reminder','search_contacts':'contact'}[tool]
                require(type(resp['value']) is list,'Search must return rows')
                require(not (bag(resp['value'])-bag(before[ns])),'Search returned invented rows')
                key={'messaging':'message_id','reminder':'reminder_id','contact':'person_id'}[ns]
                if key in args: require(all(x[key]==args[key] for x in resp['value']),'ID search returned other object')
            if tool=='search_reminder':lookups+=1
            if spec['kind']=='read' and tool!='get_cellular_service_status':bad=True
        elif tool=='send_message_with_phone_number':
            new=added(before['messaging'],after['messaging'])
            if spec['kind']!='phone' or len(new)!=1 or (bag(before['messaging'])-bag(after['messaging'])):bad=True
            else:
                row=new[0];allowed['messaging'].append(row)
                targets=[x for x in before['contact'] if x['phone_number']==spec['phone']]
                selfrows=[x for x in before['contact'] if x.get('is_self')]
                checks=[args.get('phone_number')==spec['phone'],args.get('content')==spec['content'],
                        row.get('recipient_phone_number')==spec['phone'],row.get('content')==spec['content'],
                        row.get('message_id')==resp['value'],len(selfrows)==1,
                        row.get('recipient_person_id')==(targets[0]['person_id'] if targets else None),
                        type(row.get('creation_timestamp')) in (int,float) and math.isfinite(row['creation_timestamp'])]
                if selfrows:checks.extend([row.get('sender_person_id')==selfrows[0]['person_id'],row.get('sender_phone_number')==selfrows[0]['phone_number']])
                if any(x.get('message_id')==row.get('message_id') for x in before['messaging']):checks.append(False)
                bad=not all(checks) or not worlds_equal(allowed,after)
                if len(added(base['messaging'],after['messaging']))!=1:bad=True
        elif tool=='modify_reminder':
            matches=[x for x in before['reminder'] if x['content']==spec.get('title')]
            if spec['kind']!='reminder' or len(matches)!=1 or args.get('reminder_id')!=matches[0]['reminder_id']:bad=True
            else:
                ident=matches[0]['reminder_id'];actual=next((x for x in after['reminder'] if x['reminder_id']==ident),None)
                if actual is None:bad=True
                else:
                    wanted=next(x for x in allowed['reminder'] if x['reminder_id']==ident)
                    wanted['reminder_timestamp']=spec['due'];wanted['creation_timestamp']=actual['creation_timestamp']
                    bad=(not worlds_equal(allowed,after) or type(args.get('reminder_timestamp')) not in (int,float)
                         or args.get('reminder_timestamp')!=spec['due'] or resp['value'] is not None
                         or type(actual['creation_timestamp']) not in (int,float) or not math.isfinite(actual['creation_timestamp']))
        elif tool=='set_cellular_service_status' and spec['kind']=='phone':
            # Only enabling service if needed is authorized by the public task.
            allowed['setting'][0]['cellular']=True
            bad=args.get('on') is not True or before['setting'][0]['cellular'] is not False or not worlds_equal(allowed,after)
        else:bad=True
        if bad:wrong=True;issues.append({'event':i,'tool':tool,'issue':'Task-unauthorized transition'})
        current=copy.deepcopy(after)
    require(worlds_equal(current,result['final_world']),'Final world mismatch')
    if spec['kind']=='read':
        goal=worlds_equal(base,current);answer='CELLULAR_ON' if base['setting'][0]['cellular'] else 'CELLULAR_OFF'
        answer_ok=result['final_text'].strip()==answer
    elif spec['kind']=='phone':
        rows=added(base['messaging'],current['messaging'])
        goal=len(rows)==1 and rows[0].get('recipient_phone_number')==spec['phone'] and rows[0].get('content')==spec['content']
        answer_ok=True
    else:
        rs=[x for x in current['reminder'] if x['content']==spec['title']]
        goal=len(rs)==1 and rs[0]['reminder_timestamp']==spec['due'];answer_ok=True
    state=bool(goal and not wrong)
    qualified=state and answer_ok and result['terminated'] is True and ok_count>0 and (spec['kind']!='reminder' or lookups>0)
    return {'intent':spec,'goal_final':bool(goal),'wrong_write':wrong,'task_state_ok':state,
            'qualified':bool(qualified),'terminated':result['terminated'],'violations':issues,'tool_events':len(result['events']),
            'final_claim_automatically_semantically_scored':spec['kind']=='read'}

def read_archive(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        out={};seen=set()
        for i in z.infolist():
            p=PurePosixPath(i.filename)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16),'Unsafe ZIP path')
            require(i.filename not in seen,'Duplicate ZIP entry');seen.add(i.filename)
            if not i.is_dir():out[i.filename]=z.read(i)
        return out

def write_json(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def audit(outer_path,kit_path,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    outer_bytes=Path(outer_path).read_bytes();outer=read_archive(outer_bytes)
    inners=[n for n in outer if n.endswith('.zip') and not n.startswith('__MACOSX/')];require(len(inners)==1,'Expected one feedback ZIP')
    raw=outer[inners[0]];f=read_archive(raw);load=lambda p:strict(f[p].decode('utf-8'))
    mf=load('BUNDLE_MANIFEST.json')['files'];require(set(f)==set(mf)|{'BUNDLE_MANIFEST.json'},'Bundle file set')
    for n,v in mf.items():equal({'bytes':len(f[n]),'sha256':sha(f[n])},v,'Bundle '+n)
    kb=Path(kit_path).read_bytes();korig=read_archive(kb);prefix='R9TQ1_Research_Kit/';kit={n[len(prefix):]:v for n,v in korig.items() if n.startswith(prefix)}
    sm=load('SOURCE_MANIFEST.json');equal(f['SOURCE_MANIFEST.json'].decode(),kit['SOURCE_MANIFEST.json'].decode(),'Source manifest')
    for n,v in sm['files'].items():
        require(f[n]==kit[n],'Changed frozen source '+n);equal({'bytes':len(f[n]),'sha256':sha(f[n])},v,'Source digest '+n)
    require(set(kit)==set(sm['files'])|{'SOURCE_MANIFEST.json'},'Original kit file set')
    copies=[]
    for p,b in outer.items():
        if p.startswith('__MACOSX/') or p.endswith('.zip') or p.endswith('README.md'):continue
        name=PurePosixPath(p).name
        mapping={'RUNS_AUDIT.json':'runs/AUDIT.json','PREPARED.json':'PREPARED.json','config.json':'config.json','protocol.json':'protocol.json'}
        if name in mapping:require(b==f[mapping[name]],'Outer copy differs');copies.append(name)
    cfg=load('config.json');proto=load('protocol.json');prep=load('PREPARED.json')
    equal(prep['source_manifest_sha256'],dig(sm),'source binding')
    bind=dig({'source':dig(sm),'config':cfg,'protocol':proto});equal(prep['binding'],bind,'prepare binding')
    equal(prep['config'],cfg,'prepare config');equal(prep['protocol'],proto,'prepare protocol')
    man=load('runs/qualification/manifest.json');equal(man['binding'],bind,'run binding');equal(man['config'],cfg,'run config');equal(man['protocol'],proto,'run protocol')
    status=load('runs/qualification/status.json');require(status['status']=='completed','Run incomplete')
    reqs=sorted(n for n in f if re.fullmatch(r'runs/qualification/attempts/\d{6}_request.json',n))
    require(len(reqs)<=proto['total_request_cap'],'Budget exceeded');equal(status['recorded_attempts'],len(reqs),'Attempt count')
    prefix='runs/qualification/attempts/'
    for suffix in ('_response.json','_response.raw','_send_intent.json'):
        require({n.removesuffix(suffix) for n in f if n.startswith(prefix) and n.endswith(suffix)}=={n.removesuffix('_request.json') for n in reqs},'Incomplete ledger '+suffix)
    attempts={};callrows=[];response_ids=set();identity=None;chronology=[];batch_sizes=[]
    for i,n in enumerate(reqs,1):
        stem=n.removesuffix('_request.json');q=load(n);r=load(stem+'_response.json');send=load(stem+'_send_intent.json');body=r['response']
        equal(q['attempt'],i,'Request order');equal(send['attempt'],i,'Send order');require(q['logical_id'] not in attempts,'Duplicate logical request')
        for k,v in q.items():equal(r[k],v,'Request/response envelope '+k)
        equal(q['payload_sha256'],dig(q['payload']),'Payload hash');equal(q['request_sha256'],dig({'endpoint':cfg['endpoint'],'payload':q['payload']}),'Request hash')
        wire=f[stem+'_response.raw'];require(r['secret_redacted'] is False,'Unexpected redaction');equal(sha(wire),r['raw_stored_sha256'],'Stored raw');equal(sha(wire),r['raw_original_sha256'],'Original raw');equal(strict(wire.decode()),body,'Raw parsed object')
        require(r['status']=='received' and r['http_status']==200 and r['error_type'] is None and r['response_parse_error'] is None,'Response failure')
        require(body['id'] not in response_ids,'Response ID reused');response_ids.add(body['id'])
        ident={'requested_model':cfg['model'],'returned_model':body['model'],'system_fingerprint':body['system_fingerprint'],'weight_identity_verified':False}
        require(ident['returned_model'] in cfg['accepted_response_labels'] and isinstance(ident['system_fingerprint'],str) and bool(ident['system_fingerprint']),'Bad identity')
        if identity is None:identity=ident
        equal(identity,ident,'Batch identity')
        require(len(body['choices'])==1 and body['choices'][0]['index']==0,'Choice count');c=body['choices'][0];m=c['message']
        require(m['role']=='assistant' and 'reasoning_content' in m,'Missing native history field')
        require(type(m['reasoning_content']) is str or m['reasoning_content'] is None,'Reasoning field type')
        require(type(m['content']) is str or m['content'] is None,'Content type')
        calls=m.get('tool_calls') or [];require(type(calls) is list and len(calls)<=4,'Tool count');batch_sizes.append(len(calls))
        require((calls and c['finish_reason']=='tool_calls') or (not calls and c['finish_reason']=='stop' and bool(m['content'].strip())),'Finish reason')
        ticks=[datetime.fromisoformat(x) for x in (q['registered_utc'],send['time'],r['received_utc'])];require(ticks==sorted(ticks),'Timestamp ordering');chronology.append(ticks)
        require(type(r['latency_seconds']) in (int,float) and math.isfinite(r['latency_seconds']) and r['latency_seconds']>=0,'Invalid latency')
        row={'attempt':i,'logical_id':q['logical_id'],'finish_reason':c['finish_reason'],'native_calls':len(calls),'tools':';'.join(t['function']['name'] for t in calls),**usage(body['usage']),'latency_seconds':r['latency_seconds']}
        callrows.append(row);attempts[q['logical_id']]=(q,r)
    require(all(chronology[i][2]<=chronology[i+1][0] for i in range(len(chronology)-1)),'Overlapping attempt order')
    equal(load('runs/qualification/endpoint_identity.json'),identity,'Endpoint file')
    tree=ast.parse(kit['tq/engine.py'].decode());constants={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant):
            for t in node.targets:
                if isinstance(t,ast.Name) and t.id in ('BASE','VERIFY'):constants[t.id]=ast.literal_eval(node.value)
    cases=load('fixtures/cases.json');tools_all=load('fixtures/tools.json');caserows=[];case_detail=[];links=[];read_fields=0;reconstructed=[];turnsidecars=0
    for case in cases:
        ident=case['id'];base='runs/qualification/cases/'+ident+'/';result=load(base+'result.json')
        equal(result['case_id'],ident,'Case ID');equal(result['case_sha256'],dig(case),'Case binding');equal(result['source_case'],case['source_case'],'Source case')
        system=constants['BASE']+('\n'+constants['VERIFY'] if ident!='q0_read' else '')+'\nYou have at most '+str(case['max_requests'])+' model responses including your final response.'
        messages=[{'role':'system','content':system},{'role':'user','content':canon(case['public'])}]
        equal(result['initial_messages'],messages,'Initial messages')
        tools=tools_all if case['allowed_tools']=='all' else [t for t in tools_all if t['function']['name'] in case['allowed_tools']]
        expected_top={'model':cfg['model'],'tools':tools,'tool_choice':'auto','stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high'}
        turns=result['turns'];events=result['events'];eventi=0;seen=set();final=False
        require(len(turns)<=case['max_requests'],'Case cap')
        for j,t in enumerate(turns):
            require(not final,'Request after final');logical=ident+f'/turn_{j:02d}';q,r=attempts[logical]
            equal(t,load(base+f'turn_{j:02d}.json'),'Turn sidecar');turnsidecars+=1
            equal(q['payload'],dict(expected_top,messages=messages),'Full request reconstruction');reconstructed.append(logical)
            equal(q['metadata'],{'case_id':ident,'turn':j},'Metadata');equal(t['turn'],j,'Turn index');equal(t['logical_id'],logical,'Turn logical id');equal(t['request_sha256'],q['request_sha256'],'Turn hash')
            m=r['response']['choices'][0]['message'];msg={k:copy.deepcopy(m[k]) for k in ('role','content','reasoning_content','tool_calls') if k in m}
            equal(t['assistant_message'],msg,'Assistant message');messages.append(msg)
            calls=m.get('tool_calls') or [];decoded=[];replies=[];equal(t['event_start'],eventi,'Start offset')
            allowed={x['function']['name'] for x in tools}
            for call in calls:
                require(call['type']=='function' and call['function']['name'] in allowed,'Unexpected function')
                require(type(call['id']) is str and call['id'] and call['id'] not in seen,'Tool ID duplicate');seen.add(call['id'])
                args=strict(call['function']['arguments']);require(type(args) is dict,'Tool args not object')
                d={'id':call['id'],'name':call['function']['name'],'arguments':args};decoded.append(d)
                e=events[eventi];equal(e['tool'],d['name'],'Event tool');equal(e['arguments'],args,'Event arguments')
                reply={'role':'tool','tool_call_id':call['id'],'content':canon(e['response'])};replies.append(reply);messages.append(reply)
                links.append({'case_id':ident,'request':logical,'call_id':call['id'],'function':d['name'],'event_index':eventi,'next_request_consumes_receipt':j+1<len(turns)})
                eventi+=1
            equal(t['decoded_calls'],decoded,'Decoded calls');equal(t['tool_messages'],replies,'Real receipts');equal(t['event_end'],eventi,'End offset')
            equal(t['kind'],'tools' if calls else 'final','Kind')
            read_fields+=sum(x['role']=='assistant' and 'reasoning_content' in x for x in q['payload']['messages'])
            if not calls:final=True;equal(result['final_text'],m['content'],'Final prose')
        require(all(x['next_request_consumes_receipt'] for x in links if x['case_id']==ident),'Missing follow-up to real receipt')
        equal(eventi,len(events),'Case event count');equal(result['final_messages'],messages,'Final conversation');equal(result['model_calls'],len(turns),'Case request count');require(result['terminated'] is final,'End flag')
        require(result['environment_event_count']==0,'Unexpected injection')
        s=score(case,result);saved=result['qualification']
        equal(saved['qualified'],s['qualified'],'Independent qualification');equal(saved['task_state_ok'],s['task_state_ok'],'Independent task');equal(saved['tool_calls'],len(events),'Native call count');equal(saved['terminated'],s['terminated'],'Independent end')
        casecalls=[x for x in callrows if x['logical_id'].startswith(ident+'/')]
        totals={k:sum(x[k] for x in casecalls) for k in ('prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','uncached_input_tokens','latency_seconds')}
        caserows.append({'case_id':ident,'model_requests':len(turns),'tool_calls':len(events),'qualified':s['qualified'],'task_state_ok':s['task_state_ok'],'wrong_write':s['wrong_write'],'terminated':s['terminated'],**totals})
        case_detail.append({'case_id':ident,'independent_score':s,'final_text':result['final_text'],'tool_trace':[{'tool':e['tool'],'arguments':e['arguments'],'response':e['response']} for e in events]})
    require(set(attempts)==set(reconstructed),'Unbound requests');equal(status['case_results'],[load('runs/qualification/cases/'+c['id']+'/result.json')['qualification'] for c in cases],'Status cases')
    require(all(r['qualified'] for r in caserows),'Some qualification failed')
    totals={k:sum(x[k] for x in callrows) for k in ('prompt_tokens','completion_tokens','total_tokens','reasoning_tokens','cached_input_tokens','uncached_input_tokens','latency_seconds')}
    useraudit=load('runs/AUDIT.json')
    equal(useraudit['usage_total'],{k:totals[k] for k in ('prompt_tokens','completion_tokens','total_tokens','latency_seconds')},'Original usage totals')
    output_record={'audit':'R9TQ1_INDEPENDENT_FEEDBACK_REVIEW','outer_sha256':sha(outer_bytes),'inner_sha256':sha(raw),'kit_sha256':sha(kb),
      'bundle_files':len(mf),'zip_entries':len(f),'registered_source_files':len(sm['files']),'upstream_files_unchanged':sum(n.startswith('vendor/toolsandbox/') for n in sm['files']),
      'outer_convenience_copies_equal':copies,'recorded_requests':len(reqs),'raw_response_files_checked':len(reqs),'requests_reconstructed':len(reconstructed),
      'request_receipt_links':len(links),'history_assistant_occurrences_preserved':read_fields,'turn_sidecars':turnsidecars,
      'native_events_independently_scored':sum(x['tool_calls'] for x in caserows),'completed_qualification_cases':len(caserows),'qualification_pass':True,
      'batch_sizes':dict(Counter(batch_sizes)),'response_ids_unique':len(response_ids),'identity':identity,'usage':totals,
      'qualification_wall_seconds':status['elapsed_seconds'],'timestamps':{'started':status['started_utc'],'ended':status['ended_utc']},
      'no_remote_model_calls_in_review':True,'research_complete':False,'independent_human_review':False,
      'scope':'Canonical archives, exact ledger/history linkage, and independent task/transition scoring. Native re-execution recorded separately.'}
    write_json(output/'independent_review.json',output_record);write_json(output/'case_evidence.json',case_detail)
    write_csv(output/'calls.csv',callrows);write_csv(output/'cases.csv',caserows);write_csv(output/'receipt_links.csv',links)
    return output_record

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--feedback',required=True);ap.add_argument('--kit',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    print(json.dumps(audit(args.feedback,args.kit,args.output),ensure_ascii=False,indent=2))
