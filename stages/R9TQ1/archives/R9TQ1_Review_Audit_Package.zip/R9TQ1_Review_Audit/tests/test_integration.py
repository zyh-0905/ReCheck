import copy,io,json,sys,tempfile,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import review
BASE=Path(__file__).resolve().parents[1]

def zipped(files):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_DEFLATED) as z:
  for n,v in files.items():z.writestr(n,v)
 return b.getvalue()

class EvidenceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  o=review.read_archive((BASE/'evidence/input_feedback.zip').read_bytes())
  name=next(n for n in o if n.endswith('.zip') and not n.startswith('__MACOSX'))
  self.files=review.read_archive(o[name])
 def tearDown(self):self.tmp.cleanup()
 def load(self,n):return review.strict(self.files[n].decode())
 def put(self,n,d):self.files[n]=(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 def run_audit(self):
  mf={n:{'bytes':len(b),'sha256':review.sha(b)} for n,b in self.files.items() if n!='BUNDLE_MANIFEST.json'}
  self.put('BUNDLE_MANIFEST.json',{'files':mf})
  path=self.root/'input.zip';path.write_bytes(zipped({'feedback.zip':zipped(self.files)}))
  return review.audit(path,BASE/'evidence/frozen_execution_kit.zip',self.root/'result')
 def alter_request(self,i,fn):
  stem=f'runs/qualification/attempts/{i:06d}'
  q=self.load(stem+'_request.json');r=self.load(stem+'_response.json');fn(q['payload'])
  q['payload_sha256']=review.dig(q['payload']);q['request_sha256']=review.dig({'endpoint':self.load('config.json')['endpoint'],'payload':q['payload']})
  for k,v in q.items():r[k]=v
  self.put(stem+'_request.json',q);self.put(stem+'_response.json',r)
 def test_complete_evidence(self):self.assertEqual(self.run_audit()['request_receipt_links'],7)
 def test_forged_receipt_with_rehashed_envelopes(self):
  self.alter_request(2,lambda p:p['messages'][-1].__setitem__('content','{"ok":true,"value":false}'))
  with self.assertRaisesRegex(ValueError,'Full request reconstruction'):self.run_audit()
 def test_wrong_call_id_with_rehashed_envelopes(self):
  self.alter_request(2,lambda p:p['messages'][-1].__setitem__('tool_call_id','wrong_id'))
  with self.assertRaisesRegex(ValueError,'Full request reconstruction'):self.run_audit()
 def test_reasoning_removed_with_rehashed_envelopes(self):
  self.alter_request(4,lambda p:p['messages'][-2].pop('reasoning_content'))
  with self.assertRaisesRegex(ValueError,'Full request reconstruction'):self.run_audit()
 def test_user_material_added_with_rehashed_envelopes(self):
  self.alter_request(1,lambda p:p['messages'][1].__setitem__('content','hidden-answer'))
  with self.assertRaisesRegex(ValueError,'Full request reconstruction'):self.run_audit()
 def test_raw_bytes_differ_from_wrapper(self):
  n='runs/qualification/attempts/000001_response.raw';self.files[n]+=b' '
  with self.assertRaisesRegex(ValueError,'Stored raw'):self.run_audit()
 def test_reused_response_id_even_with_rehashed_raw(self):
  stem='runs/qualification/attempts/000002';r=self.load(stem+'_response.json');r['response']['id']=self.load('runs/qualification/attempts/000001_response.json')['response']['id']
  b=review.canon(r['response']).encode();self.files[stem+'_response.raw']=b;r['raw_original_sha256']=review.sha(b);r['raw_stored_sha256']=review.sha(b);self.put(stem+'_response.json',r)
  with self.assertRaisesRegex(ValueError,'Response ID reused'):self.run_audit()
 def test_source_change_rejected(self):
  self.files['tq/engine.py']+=b'\n# changed\n'
  with self.assertRaisesRegex(ValueError,'Changed frozen source'):self.run_audit()
if __name__=='__main__':unittest.main()
