import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import review

def world():
 return {'contact':[{'person_id':'self','phone_number':'+10000000000','is_self':True}, {'person_id':'p','phone_number':'+12453344098','is_self':False}],
 'messaging':[{'message_id':'old','content':'old'}],
 'reminder':[{'reminder_id':'r','content':'Review the indigo rehearsal plan','reminder_timestamp':1800100000.0,'creation_timestamp':1.0,'latitude':1.0,'longitude':2.0}],
 'setting':[{'device_id':'d','cellular':True,'wifi':True}]}
def sample(kind='phone'):
 w=world()
 if kind=='phone':
  public={'user_request':'Send exactly one text to the explicit phone number +12453344098, regardless of its current contact-book owner. The exact message is: Hello. You may enable cellular service if needed. Do not change contacts, reminders, or other settings.'}
  row={'message_id':'new','sender_person_id':'self','sender_phone_number':'+10000000000','recipient_person_id':'p','recipient_phone_number':'+12453344098','content':'Hello.','creation_timestamp':2.0}
  after=copy.deepcopy(w);after['messaging'].append(row)
  event={'scope':'agent','tool':'send_message_with_phone_number','arguments':{'phone_number':'+12453344098','content':'Hello.'},'before_world':copy.deepcopy(w),'after_world':after,'response':{'ok':True,'value':'new','error':None}}
 elif kind=='reminder':
  public={'user_request':'Find the reminder whose text is exactly "Review the indigo rehearsal plan" and move its reminder time to POSIX timestamp 1800118800. Preserve its text and location; do not alter other reminders or any contacts, messages, or settings.'}
  after=copy.deepcopy(w);after['reminder'][0]['reminder_timestamp']=1800118800.0;after['reminder'][0]['creation_timestamp']=2.0
  event={'scope':'agent','tool':'modify_reminder','arguments':{'reminder_id':'r','reminder_timestamp':1800118800},'before_world':copy.deepcopy(w),'after_world':after,'response':{'ok':True,'value':None,'error':None}}
 else:
  public={'user_request':'Use get_cellular_service_status to read the current simulated cellular status. Do not change anything. After receiving the actual tool reply, answer exactly CELLULAR_ON or CELLULAR_OFF as appropriate.'}
  after=copy.deepcopy(w);event={'scope':'agent','tool':'get_cellular_service_status','arguments':{},'before_world':copy.deepcopy(w),'after_world':after,'response':{'ok':True,'value':True,'error':None}}
 return {'public':public,'world_before':w},{'events':[event],'final_world':copy.deepcopy(after),'terminated':True,'final_text':'CELLULAR_ON' if kind=='read' else 'Done.'}

class StrictTests(unittest.TestCase):
 def test_valid_json(self):self.assertEqual(review.strict('{"x":1}'),{'x':1})
 def test_duplicate_key(self):
  with self.assertRaises(ValueError):review.strict('{"x":1,"x":2}')
 def test_nan(self):
  with self.assertRaises(ValueError):review.strict('{"x":NaN}')
 def test_overflow_float(self):
  with self.assertRaises(ValueError):review.strict('{"x":1e999}')
 def test_prose(self):
  with self.assertRaises(ValueError):review.strict('{}\nDone')
 def test_nonfinite_nested(self):
  with self.assertRaises(ValueError):review.strict('[{"x":[Infinity]}]')

class UsageTests(unittest.TestCase):
 def u(self):return {'prompt_tokens':10,'completion_tokens':5,'total_tokens':15,'prompt_cache_hit_tokens':4,'prompt_cache_miss_tokens':6,'prompt_tokens_details':{'cached_tokens':4},'completion_tokens_details':{'reasoning_tokens':3}}
 def test_normal(self):self.assertEqual(review.usage(self.u())['uncached_input_tokens'],6)
 def test_bool_invalid(self):
  u=self.u();u['prompt_tokens']=True
  with self.assertRaises(ValueError):review.usage(u)
 def test_total(self):
  u=self.u();u['total_tokens']=16
  with self.assertRaises(ValueError):review.usage(u)
 def test_reasoning_not_double(self):self.assertEqual(review.usage(self.u())['total_tokens'],15)
 def test_reason_exceeds(self):
  u=self.u();u['completion_tokens_details']['reasoning_tokens']=6
  with self.assertRaises(ValueError):review.usage(u)
 def test_cache_mismatch(self):
  u=self.u();u['prompt_tokens_details']['cached_tokens']=3
  with self.assertRaises(ValueError):review.usage(u)

class ScoreTests(unittest.TestCase):
 def test_phone(self):self.assertTrue(review.score(*sample())['qualified'])
 def test_reminder(self):self.assertTrue(review.score(*sample('reminder'))['task_state_ok'])
 def test_read(self):self.assertTrue(review.score(*sample('read'))['qualified'])
 def test_read_lie(self):
  c,r=sample('read');r['final_text']='CELLULAR_OFF';self.assertFalse(review.score(c,r)['qualified'])
 def test_fabricated_read(self):
  c,r=sample('read');r['events'][0]['response']['value']=False
  with self.assertRaises(ValueError):review.score(c,r)
 def test_read_mutates(self):
  c,r=sample('read');r['events'][0]['after_world']['setting'][0]['wifi']=False;r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['wrong_write'])
 def test_send_wrong_number(self):
  c,r=sample();r['events'][0]['after_world']['messaging'][-1]['recipient_phone_number']='+15551234567';r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['wrong_write'])
 def test_duplicate_send(self):
  c,r=sample();e=copy.deepcopy(r['events'][0]);e['before_world']=copy.deepcopy(r['final_world']);row=copy.deepcopy(e['after_world']['messaging'][-1]);row['message_id']='new2';e['after_world']['messaging'].append(row);e['response']['value']='new2';r['events'].append(e);r['final_world']=e['after_world'];self.assertTrue(review.score(c,r)['wrong_write'])
 def test_changed_location(self):
  c,r=sample('reminder');r['events'][0]['after_world']['reminder'][0]['latitude']=3;r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['wrong_write'])
 def test_creation_timestamp_allowed(self):
  c,r=sample('reminder');r['events'][0]['after_world']['reminder'][0]['creation_timestamp']=999.0;r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['task_state_ok'])
 def test_world_discontinuity(self):
  c,r=sample();r['events'][0]['before_world']['setting'][0]['wifi']=False
  with self.assertRaises(ValueError):review.score(c,r)
 def test_final_snapshot_disagrees(self):
  c,r=sample();r['final_world']['setting'][0]['wifi']=False
  with self.assertRaises(ValueError):review.score(c,r)
 def test_deleted_history(self):
  c,r=sample();r['events'][0]['after_world']['messaging']=r['events'][0]['after_world']['messaging'][1:];r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['wrong_write'])
 def test_original_duplicate_history_preserved(self):
  c,r=sample();old=copy.deepcopy(c['world_before']['messaging'][0]);c['world_before']['messaging'].append(old);r['events'][0]['before_world']['messaging'].append(copy.deepcopy(old));r['events'][0]['after_world']['messaging'].append(copy.deepcopy(old));r['final_world']=copy.deepcopy(r['events'][0]['after_world']);self.assertTrue(review.score(c,r)['qualified'])
 def test_goal_without_end_not_qualified(self):
  c,r=sample();r['terminated']=False;self.assertTrue(review.score(c,r)['task_state_ok']);self.assertFalse(review.score(c,r)['qualified'])
 def test_later_fix_does_not_erase(self):
  c,r=sample('reminder');e=r['events'][0];e['after_world']['reminder'][0]['content']='wrong';fix=copy.deepcopy(e);fix['before_world']=copy.deepcopy(e['after_world']);fix['after_world']['reminder'][0]['content']='Review the indigo rehearsal plan';r['events'].append(fix);r['final_world']=fix['after_world'];s=review.score(c,r);self.assertTrue(s['goal_final']);self.assertTrue(s['wrong_write']);self.assertFalse(s['task_state_ok'])
 def test_no_tool_not_qualified(self):
  c,r=sample('read');r['events']=[];self.assertFalse(review.score(c,r)['qualified'])

if __name__=='__main__':unittest.main()
