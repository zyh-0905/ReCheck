"""Run pinned kit unit tests, permitting loopback fixture connections only."""
import sys,socket,ipaddress,unittest
from pathlib import Path
original=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(original))
connect=socket.socket.connect
connect_ex=socket.socket.connect_ex
def allowed(address):
 if not isinstance(address,tuple):raise RuntimeError('Non-INET sockets disabled in test wrapper')
 if address[0]=='localhost':return
 if not ipaddress.ip_address(address[0]).is_loopback:raise RuntimeError('External test connection blocked')
def guard(self,address):allowed(address);return connect(self,address)
def guard_ex(self,address):allowed(address);return connect_ex(self,address)
socket.socket.connect=guard;socket.socket.connect_ex=guard_ex
suite=unittest.defaultTestLoader.discover(str(original/'tests'))
r=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if r.wasSuccessful() else 1)
