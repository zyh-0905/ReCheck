import unittest
import importlib.util
from pathlib import Path
from copy import deepcopy

class IndependentScoreTests(unittest.TestCase):
 def setUp(self):
  p=Path(__file__).with_name('audit_r3.py')
  self.assertTrue(p.exists(), 'Independent auditor has not been implemented')
  spec=importlib.util.spec_from_file_location('audit_r3',p);self.a=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.a)
  self.case={'stream':0,'cents':[100,200,300,400],'tasks':[{'type':1,'cutoff':1,'modes':[0,1]}]}
  self.r={'stream':0,'step':0,'method':'recheck','replicate':'primary','memory_audit':{'amount_divisor':1,'endpoint_inclusive':True},'plan':{'time_bound':1},'tool_result':{'count_before':2},'answer':{'total':None,'count':2},'probe_count':0,'model_probe_cost':0.,'task_type':1,'condition':'unit'}
  self.call={'status':'ok','response':{'choices':[{'finish_reason':'stop'}]}}
 def ev(self): return self.a.independent_score(self.r,self.case,self.call)
 def test_fresh_success(self): self.assertTrue(self.ev()['success']);self.assertFalse(self.ev()['stale'])
 def test_legal_but_stale(self):
  self.r['memory_audit']['endpoint_inclusive']=False;self.r['plan']={'time_bound':2};self.r['answer']['count']=3;self.r['tool_result']['count_before']=3
  e=self.ev();self.assertTrue(e['stale']);self.assertTrue(e['follows_evidence']);self.assertFalse(e['success'])
 def test_unused_field_is_interface_error(self): self.r['plan']['amount_divisor']=1;self.assertFalse(self.ev()['interface_valid'])
 def test_unused_stale_amount_not_relevant(self): self.r['memory_audit']['amount_divisor']=100;self.assertFalse(self.ev()['stale'])
 def test_boolean_time_rejected(self): self.r['plan']['time_bound']=True;self.assertFalse(self.ev()['interface_valid'])
 def test_missing_call_not_success(self): self.assertFalse(self.a.independent_score(self.r,self.case,None)['success'])
 def test_truncation_not_success(self): self.call['response']['choices'][0]['finish_reason']='length';self.assertFalse(self.ev()['success'])
 def test_wrong_plan_separated_from_stale(self): self.r['plan']['time_bound']=2;e=self.ev();self.assertFalse(e['follows_evidence']);self.assertFalse(e['stale']);self.assertFalse(e['tool_matches'])
 def test_count_boolean_rejected(self): self.r['answer']['count']=True;self.assertFalse(self.ev()['success'])
 def test_amount_stale(self):
  self.case['tasks'][0]['type']=0;self.r.update(task_type=0,plan={'amount_divisor':100},tool_result={'sum_amount_raw':10.},answer={'total':.1,'count':None});self.r['memory_audit']['amount_divisor']=100
  self.assertTrue(self.ev()['stale']);self.assertFalse(self.ev()['success'])
 def test_count_all_ignores_both_stale_values(self):
  self.case['tasks'][0]['type']=3;self.r.update(task_type=3,plan={},tool_result={'count_all':4},answer={'total':None,'count':4});self.r['memory_audit']={'amount_divisor':100,'endpoint_inclusive':False}
  self.assertTrue(self.ev()['success']);self.assertFalse(self.ev()['stale'])
 def test_two_stale_channels_one_failure(self):
  self.case['tasks'][0]['type']=2;self.r['memory_audit']={'amount_divisor':100,'endpoint_inclusive':False};self.r.update(task_type=2,plan={'amount_divisor':100,'time_bound':2},tool_result={'sum_amount_raw':10.,'count_before':3},answer={'total':.1,'count':3})
  e=self.ev();self.assertEqual(e['semantic_loss'],2);self.assertFalse(e['success'])
 def test_repeat_not_primary(self):
  p=deepcopy(self.r);p['replicate']='repeat';self.assertEqual(len(self.a.primary_only([self.r,p])),1)
 def test_decimal_text_not_raw_equal(self):
  a={'text':'{"amount_divisor":1}','response':{'choices':[{'message':{'content':'{"amount_divisor":1}','reasoning_content':'a'}}],'usage':{'completion_tokens':20}}};b=deepcopy(a);b['text']='{ "amount_divisor": 1 }';b['response']['choices'][0]['message']['content']=b['text'];b['response']['choices'][0]['message']['reasoning_content']='b';b['response']['usage']['completion_tokens']=30
  e=self.a.compare_repeats(a,b);self.assertTrue(e['same_parsed_plan']);self.assertFalse(e['same_raw_content']);self.assertFalse(e['same_reasoning_text']);self.assertFalse(e['same_completion_tokens'])
 def test_derived_roundoff_is_tolerated(self): self.assertTrue(self.a.equivalent({'J':44.079999999999984},{'J':44.08}))
 def test_derived_material_difference_not_tolerated(self): self.assertFalse(self.a.equivalent({'J':44.079},{'J':44.08}))
 def test_counts_must_match_exactly(self): self.assertFalse(self.a.equivalent({'n':384},{'n':385}));self.assertFalse(self.a.equivalent({'ok':True},{'ok':1}))
if __name__=='__main__':unittest.main()
