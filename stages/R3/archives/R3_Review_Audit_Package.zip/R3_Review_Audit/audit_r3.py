#!/usr/bin/env python3
"""Read-only R3 review. Reads two pinned ZIPs, writes only to --out and temp dirs.
No network/model/account access. Not independent human peer review.
Python 3.11+ and the original kit's numpy dependency are required for replay.
"""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
from datetime import datetime
import argparse, copy, csv, hashlib, json, math, re, shutil, socket, stat, sys, tempfile, zipfile

EXPECTED_ORIGINAL='be7ca78141f3b16f942ea7a271f3ff040d1e74556f031ae52cbeaabc4930a0d6'
EXPECTED_FEEDBACK='82a910958ffcfad0865e9e31d84c3d3dac47473867c3c68b570181f0a9c1bde0'
ENDPOINT='https://api.deepseek.com/v1'  # recorded request profile, not a live discovery

def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def write_csv(p,rs):
 if not rs:return
 keys=list(dict.fromkeys(k for r in rs for k in r))
 with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,keys);w.writeheader()
  for r in rs:w.writerow({k:canonical(v) if isinstance(v,(list,dict)) else v for k,v in r.items()})
def csvrows(p):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def equivalent(a,b):
 """Derived numeric summaries only: tolerate <1e-10 absolute float rounding.
 Never used for original hashes, requests, responses, configurations or record replay.
 """
 if type(a) is not type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(equivalent(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(equivalent(x,y) for x,y in zip(a,b))
 if isinstance(a,float):return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-10
 if isinstance(a,str) and re.fullmatch(r'-?\d+\.\d+(?:[eE][+-]?\d+)?',a) and re.fullmatch(r'-?\d+\.\d+(?:[eE][+-]?\d+)?',b):return abs(float(a)-float(b))<=1e-10
 return a==b

def safe_extract(src,dst):
 dst=Path(dst);dst.mkdir(exist_ok=True,parents=True);names=set();total=0
 with zipfile.ZipFile(src) as z:
  for i in z.infolist():
   p=PurePosixPath(i.filename)
   if p.is_absolute() or '..' in p.parts or '\\' in i.filename or (p.parts and ':' in p.parts[0]):raise ValueError('Unsafe path')
   if i.filename in names:raise ValueError('Duplicate path')
   names.add(i.filename)
   if stat.S_ISLNK(i.external_attr>>16):raise ValueError('Symlink')
   total+=i.file_size
   if total>250_000_000 or i.file_size>30_000_000 or len(names)>15000:raise ValueError('Archive limit')
   if i.is_dir() or '__MACOSX' in p.parts or p.name=='.DS_Store':continue
   target=dst.joinpath(*p.parts);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(i))
 return {'members_including_metadata':len(names),'expanded_bytes_including_metadata':total}
def number(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def parse_json(text):
 def unique(pairs):
  d={}
  for k,v in pairs:
   if k in d:raise ValueError('duplicate key')
   d[k]=v
  return d
 text=text.strip();m=re.fullmatch(r'```(?:json)?\s*\n?(.*?)\n?```',text,flags=re.S)
 if m:text=m[1].strip()
 def bad(x):raise ValueError('nonfinite number')
 d=json.loads(text,object_pairs_hook=unique,parse_constant=bad)
 if not isinstance(d,dict):raise ValueError('not object')
 return d

def independent_score(r,case,call):
 """No imports from the delivered scorer; plain arithmetic instead of SQL."""
 t=case['tasks'][r['step']];q=t['type'];p=r['plan'];mem=r['memory_audit'];modes=t['modes']
 use=(q in (0,2),q in (1,2));expected_keys=({'amount_divisor'} if use[0] else set())|({'time_bound'} if use[1] else set())
 valid=isinstance(p,dict) and set(p)==expected_keys
 if valid and use[0]:valid=number(p['amount_divisor']) and p['amount_divisor'] in (1,100)
 if valid and use[1]:valid=type(p['time_bound']) is int and t['cutoff']-1<=p['time_bound']<=t['cutoff']+2
 legal=[number(mem.get('amount_divisor')) and mem.get('amount_divisor') in (1,100),type(mem.get('endpoint_inclusive')) is bool]
 truth=[100 if modes[0] else 1,bool(modes[1])]
 stale=[bool(use[j] and legal[j] and [mem.get('amount_divisor'),mem.get('endpoint_inclusive')][j]!=truth[j]) for j in (0,1)]
 normative={}
 if use[0]:normative['amount_divisor']=mem.get('amount_divisor')
 if use[1]:normative['time_bound']=t['cutoff']+(0 if mem.get('endpoint_inclusive') else 1)
 gold={'total':sum(case['cents'])/100 if use[0] else None,'count':sum(i<=t['cutoff'] for i in range(len(case['cents']))) if use[1] else len(case['cents']) if q==3 else None}
 def same_value(a,b):
  if b is None:return a is None
  return number(a) and math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-6)
 ans=r['answer'];correct=isinstance(ans,dict) and set(ans)=={'total','count'}
 if correct:
  correct=same_value(ans['total'],gold['total']) and ((ans['count'] is None) if gold['count'] is None else (type(ans['count']) is int and ans['count']==gold['count']))
 tool={'error':'INVALID_TOOL_PLAN'} if not valid else {}
 if valid:
  if use[0]:tool['sum_amount_raw']=sum(float(x) if modes[0] else float(x)/100 for x in case['cents'])
  if use[1]:tool['count_before']=sum(i<=p['time_bound'] if modes[1] else i<p['time_bound'] for i in range(len(case['cents'])))
  if q==3:tool['count_all']=len(case['cents'])
 tool_matches=set(tool)==set(r['tool_result']) and all((same_value(r['tool_result'].get(k),v) if number(v) else r['tool_result'].get(k)==v) for k,v in tool.items())
 rendered={'total':None,'count':None}
 if valid:
  if use[0]:rendered['total']=tool['sum_amount_raw']/p['amount_divisor']
  if use[1]:rendered['count']=tool['count_before']
  if q==3:rendered['count']=tool['count_all']
 renderer_matches=isinstance(ans,dict) and set(ans)==set(rendered) and all(same_value(ans[k],v) for k,v in rendered.items())
 finished=bool(call and call.get('status')=='ok' and call['response']['choices'][0].get('finish_reason')=='stop')
 return {'interface_valid':bool(valid),'memory_relevant_legal':all(legal[j] for j in (0,1) if use[j]),'stale':any(stale),'channel_stale':stale,'semantic_loss':sum(stale),'follows_evidence':bool(valid and p==normative),'answer_correct':bool(correct),'success':bool(correct and valid and finished),'tool_matches':bool(tool_matches),'renderer_matches':bool(renderer_matches),'gold':gold,'normative_plan':normative}

def primary_only(rows):return [r for r in rows if r['replicate']=='primary']
def compare_repeats(a,b):
 ma=a['response']['choices'][0]['message'];mb=b['response']['choices'][0]['message']
 return {'same_raw_content':ma.get('content')==mb.get('content'),'same_parsed_plan':parse_json(a['text'])==parse_json(b['text']),'same_reasoning_text':ma.get('reasoning_content')==mb.get('reasoning_content'),'same_completion_tokens':a['response']['usage']['completion_tokens']==b['response']['usage']['completion_tokens']}

def audit(feedback_zip,original_zip,out):
 out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
 before={str(p):sha(p) for p in (feedback_zip,original_zip)}
 if sha(original_zip)!=EXPECTED_ORIGINAL:raise ValueError('Unrecognized original kit; no source execution')
 if sha(feedback_zip)!=EXPECTED_FEEDBACK:raise ValueError('This review targets the specified R3 feedback, not arbitrary uploads')
 checks=[]
 def ck(name,ok,detail=None):
  checks.append({'check':name,'pass':bool(ok),'detail':detail})
  if not ok:raise AssertionError(name+': '+str(detail))
 with tempfile.TemporaryDirectory(prefix='r3_readonly_review_') as temp:
  base=Path(temp);ar={}
  ar['outer']=safe_extract(feedback_zip,base/'outer');ar['original']=safe_extract(original_zip,base/'original')
  inners=list((base/'outer').rglob('*.zip'));ck('one feedback archive',len(inners)==1)
  ar['inner']=safe_extract(inners[0],base/'feedback');f=base/'feedback';o=base/'original/R3_Research_Kit'
  bm=load(f/'BUNDLE_MANIFEST.json')['sha256'];actual={p.relative_to(f).as_posix() for p in f.rglob('*') if p.is_file()}
  ck('bundle exact entry set',actual==set(bm)|{'BUNDLE_MANIFEST.json'},len(bm))
  ck('bundle every hash',all(sha(f/n)==h for n,h in bm.items()),len(bm))
  sm=load(o/'SOURCE_MANIFEST.json')['sha256'];ck('original source hashes',all(sha(o/n)==h for n,h in sm.items()),len(sm))
  ck('returned source matches original',all((o/n).read_bytes()==(f/'kit_source'/n).read_bytes() for n in sm),len(sm))
  manifests={};rawcalls=[];ledgers={};events={}
  prepared=load(f/'offline_reports/PREPARED.json');spec=load(o/'configs/r3_protocol.json')
  ck('protocol prepared binding',prepared['protocol_sha256']==digest(spec))
  ck('source prepared binding',prepared['source_sha256']==digest(sm))
  for runname in ('R3_smoke','R3_recheck'):
   root=f/'runs'/runname;m=load(root/'manifest.json');manifests[runname]=m
   ck(runname+' complete status',load(root/'status.json')['state']=='completed')
   ck(runname+' code snapshot',m['source_hashes']==sm and all((root/'code_snapshot'/n).read_bytes()==(o/n).read_bytes() for n in sm),len(sm))
   contract={k:m[k] for k in ('version','config','study','spec','billing_schedule','source_hashes')}
   ck(runname+' fingerprint',digest(contract)==m['fingerprint'])
   cfg=copy.deepcopy(m['config']);cfg['base_url']=ENDPOINT;del cfg['base_url_sha256']
   ck(runname+' endpoint digest',m['config']['base_url_sha256']==digest(ENDPOINT))
   ck(runname+' config prepared binding',digest(cfg)==prepared['config_sha256'])
   ck(runname+' billing prepared binding',digest(m['billing_schedule'])==prepared['billing_sha256'])
   profile={k:cfg[k] for k in ('base_url','model','max_tokens_field','max_output_tokens','temperature','extra_body','instruction_role','backend_kind')};profile['base_url_sha256']=digest(profile.pop('base_url'))
   ck(runname+' model profile',profile==prepared['model_profile'] and digest(profile)==m['profile_sha256'])
   if runname=='R3_recheck':ck('main frozen spec',m['spec']==spec)
   starts={load(p)['attempt']:load(p) for p in (root/'attempts').glob('*_start.json')}
   results={load(p)['attempt']:load(p) for p in (root/'attempts').glob('*_result.json')}
   sends={load(p)['attempt']:load(p) for p in (root/'attempts').glob('*_send_intent.json')}
   cc=[(p,load(p)) for p in (root/'calls').glob('*.json')];n=1 if runname=='R3_smoke' else 416
   ck(runname+' complete ledger',set(starts)==set(results)==set(sends)==set(range(1,n+1)) and len(cc)==n)
   identity=load(root/'endpoint_identity.json');expected_order=[]
   for path,c in sorted(cc,key=lambda t:t[1]['attempt']):
    idx=c['attempt'];st=starts[idx];res=results[idx];send=sends[idx]
    ck(runname+f' call {idx}',res==c and all(st.get(k)==c.get(k) for k in st) and path.stem==digest(c['logical_id']))
    ck(runname+f' hashes {idx}',c['payload_sha256']==digest(c['payload']) and c['request_sha256']==digest({'endpoint':ENDPOINT,'payload':c['payload']}))
    ck(runname+f' send {idx}',send['logical_id']==c['logical_id'] and c['started_utc']<=send['local_send_intent_utc']<=c['ended_utc'])
    resp=c['response'];ch=resp['choices'][0];ck(runname+f' response {idx}',c['status']=='ok' and ch['finish_reason']=='stop' and ch['message']['content']==c['text'] and {'returned_model':resp['model'],'system_fingerprint':resp.get('system_fingerprint')}==identity)
    ck(runname+f' request params {idx}',c['payload']['model']==cfg['model'] and c['payload']['max_tokens']==16384 and c['payload']['thinking']=={'type':'enabled'} and c['payload']['reasoning_effort']=='high' and c['payload']['stream'] is False and 'temperature' not in c['payload'])
    obj=parse_json(c['text']);u=resp['usage'];hit=u['prompt_cache_hit_tokens'];miss=u['prompt_cache_miss_tokens'];reason=u['completion_tokens_details']['reasoning_tokens']
    ck(runname+f' usage {idx}',all(type(x) is int and x>=0 for x in [hit,miss,u['prompt_tokens'],u['completion_tokens'],reason]) and hit+miss==u['prompt_tokens'] and u['total_tokens']==u['prompt_tokens']+u['completion_tokens'] and reason<=u['completion_tokens'] and u['prompt_tokens_details']['cached_tokens']==hit)
    rawcalls.append({**c,'run':runname});expected_order.append(c['logical_id'])
   ev=[json.loads(s) for s in (root/'run_events.jsonl').read_text().splitlines()];events[runname]=ev
   ck(runname+' one invocation',len(ev)==2 and ev[0]['event']=='invocation_started' and ev[1]['event']=='invocation_ended' and ev[0]['prior_budget']['attempts']==0 and ev[1]['budget']['attempts']==n)
   ledgers[runname]={'starts':n,'send_intents':n,'responses':n,'calls':n,'unfinished':0,'order':expected_order}
  ck('response IDs unique',len({c['response']['id'] for c in rawcalls})==417)
  ck('smoke before main',events['R3_smoke'][1]['utc']<events['R3_recheck'][0]['utc'])
  # All original code is matched to the pinned distribution before importing.
  sys.path.insert(0,str(o))
  from r3lib import review, protocol, offline, repair_guard
  for runname in ('R3_smoke','R3_recheck'):
   root=f/'runs'/runname;saved_summary=load(root/'summary.json');names=['per_task.csv','per_call.csv','method_summary.csv','paired.csv'];saved={n:csvrows(root/n) for n in names if (root/n).exists()}
   new=review.summarize(root);ck(runname+' reconstructed summary',equivalent(new,saved_summary), 'derived floats only: absolute tolerance 1e-10')
   for n,rows in saved.items():ck(runname+' reconstructed '+n,equivalent(csvrows(root/n),rows), 'derived float strings only: absolute tolerance 1e-10')
  replay=review.replay_check(f/'runs/R3_recheck');ck('original request and SQL replay',replay['pass'] and replay['request_bodies_checked']==416,replay)
  main=f/'runs/R3_recheck';cases={c['stream']:c for c in load(main/'private/recheck_cases.json')};calls={c['logical_id']:c for c in rawcalls};rs=[load(p) for p in sorted((main/'records').glob('*.json'))]
  ck('generated worlds and tasks match',list(cases.values())==protocol.make_cases(spec))
  ck('planned logical IDs',set(protocol.logical_ids(spec))==set(ledgers['R3_recheck']['order']) and len(ledgers['R3_recheck']['order'])==416)
  import numpy as np
  expected_execution_order=[]
  for cell in spec['streams']:
   sid=cell['stream'];perm=np.random.default_rng(spec['order_seed']+sid).permutation(spec['methods']).tolist()
   for t in range(spec['steps']):
    order=perm[t%2:]+perm[:t%2]
    for method in order:
     for rep in (['primary','repeat'] if t==spec['repeat_step'] else ['primary']):expected_execution_order.append(f'r3/rc/{sid}/{t}/{method}/{rep}')
  ck('frozen chronological method order',expected_execution_order==ledgers['R3_recheck']['order'])
  rows=[];field_errors=[]
  submitted={(int(x['stream']),int(x['step']),x['method'],x['replicate']):x for x in csvrows(main/'per_task.csv')}
  by={(r['stream'],r['step'],r['method'],r['replicate']):r for r in rs}
  for r in rs:
   c=calls[r['logical_calls'][0]];e=independent_score(r,cases[r['stream']],c)
   ck('raw plan '+c['logical_id'],parse_json(c['text'])==r['plan'])
   ck('arithmetic tool and renderer '+c['logical_id'],e['tool_matches'] and e['renderer_matches'])
   u=c['response']['usage'];row={k:r[k] for k in ('stream','condition','step','task_type','method','replicate','probe_count','model_probe_cost','planning_seconds','probe_seconds','tool_seconds')}
   row.update(e);row.update(primary_J=e['semantic_loss']+r['model_probe_cost'],prompt_tokens=u['prompt_tokens'],cached_input_tokens=u['prompt_cache_hit_tokens'],uncached_input_tokens=u['prompt_cache_miss_tokens'],completion_tokens=u['completion_tokens'],reasoning_tokens=u['completion_tokens_details']['reasoning_tokens'],model_latency_seconds=c['latency_seconds'],logical_id=c['logical_id']);rows.append(row)
   old=submitted[(r['stream'],r['step'],r['method'],r['replicate'])]
   mapping={'interface_failure':not e['interface_valid'],'relevant_stale':e['stale'],'semantic_mismatches':e['semantic_loss'],'plan_follows_evidence':e['follows_evidence'],'success':e['success'],'answer_value_correct':e['answer_correct'],'stale_propagation_consistent':e['stale'] and e['follows_evidence'] and not e['answer_correct']}
   for k,v in mapping.items():
    if old[k]!=str(v):field_errors.append((c['logical_id'],k,old[k],v))
  ck('independent score vs submitted',not field_errors,field_errors)
  primary=primary_only(rows);reprows=[r for r in rows if r['replicate']=='repeat'];ck('primary repeat counts',len(primary)==384 and len(reprows)==32)
  rowmap={(r['stream'],r['step'],r['method'],r['replicate']):r for r in rows};pairs=[]
  for sid,t,rep in sorted({(r['stream'],r['step'],r['replicate']) for r in rs}):
   a=by[(sid,t,'recheck',rep)];b=by[(sid,t,'myopic',rep)];ea=rowmap[(sid,t,'recheck',rep)];eb=rowmap[(sid,t,'myopic',rep)];ca=calls[a['logical_calls'][0]];cb=calls[b['logical_calls'][0]]
   pairs.append({'stream':sid,'condition':a['condition'],'step':t,'replicate':rep,'probe_actions_differ':a['probed_channels']!=b['probed_channels'],'actual_new_probe_action_diff':rep=='primary' and a['probed_channels']!=b['probed_channels'],'relevant_evidence_differ':a['worker_view']['evidence']!=b['worker_view']['evidence'],'request_body_differ':ca['payload']!=cb['payload'],'recheck_success':ea['success'],'myopic_success':eb['success'],'recheck_plan':a['plan'],'myopic_plan':b['plan'],'recheck_evidence':a['worker_view']['evidence'],'myopic_evidence':b['worker_view']['evidence'],'gold':ea['gold'],'recheck_answer':a['answer'],'myopic_answer':b['answer'],'J_delta':ea['primary_J']-eb['primary_J']})
  repeats=[]
  for r in reprows:
   key=(r['stream'],r['step'],r['method']);a=by[(*key,'primary')];b=by[(*key,'repeat')];ca=calls[a['logical_calls'][0]];cb=calls[b['logical_calls'][0]]
   repeats.append({k:r[k] for k in ('stream','condition','step','method')}|{'same_request_body':ca['payload']==cb['payload'],'same_answer':a['answer']==b['answer'],'primary_success':rowmap[(*key,'primary')]['success'],'repeat_success':r['success'],**compare_repeats(ca,cb),'primary_output_tokens':ca['response']['usage']['completion_tokens'],'repeat_output_tokens':cb['response']['usage']['completion_tokens'],'primary_latency_s':ca['latency_seconds'],'repeat_latency_s':cb['latency_seconds']})
  aggregates=[]
  for cond in ['ALL_DESCRIPTIVE_ONLY']+list(dict.fromkeys(c['condition'] for c in cases.values())):
   for m in spec['methods']:
    x=[r for r in primary if r['method']==m and (cond=='ALL_DESCRIPTIVE_ONLY' or r['condition']==cond)]
    aggregates.append({'condition':cond,'method':m,'streams':len({r['stream'] for r in x}),'tasks':len(x),'successes':sum(r['success'] for r in x),'probes':sum(r['probe_count'] for r in x),'stale_tasks':sum(r['stale'] for r in x),'semantic_loss':sum(r['semantic_loss'] for r in x),'proxy_J':sum(r['primary_J'] for r in x),'probe_charge':sum(r['model_probe_cost'] for r in x),**{k:sum(r[k] for r in x) for k in ('prompt_tokens','cached_input_tokens','uncached_input_tokens','completion_tokens','reasoning_tokens','model_latency_seconds','planning_seconds','probe_seconds','tool_seconds')}})
  streams=[]
  for sid in sorted(cases):
   item={'stream':sid,'condition':cases[sid]['condition'],'task_types':[t['type'] for t in cases[sid]['tasks']]}
   for m in spec['methods']:
    x=[r for r in primary if r['stream']==sid and r['method']==m]
    for key,field in [('successes','success'),('J','primary_J'),('probes','probe_count'),('semantic_loss','semantic_loss')]:item[m+'_'+key]=sum(r[field] for r in x)
   item['J_delta']=item['recheck_J']-item['myopic_J'];item['success_delta']=item['recheck_successes']-item['myopic_successes'];streams.append(item)
  ck('offline preflight regenerated',equivalent(offline.preflight(),load(f/'offline_reports/PREFLIGHT.json')))
  ck('regression regenerated',review.regression_checks()==load(f/'offline_reports/REGRESSION.json'))
  ck('historical repair cost regenerated',equivalent(repair_guard.prior_diagnostic(),load(f/'offline_reports/REPAIR_COST_DIAGNOSTIC.json')))
  print('Replaying 288 finite model cells (no remote calls)...',flush=True)
  grid=offline.factorial_report();ck('offline grid regenerated',equivalent(grid,load(f/'offline_reports/EXACT_GRID.json')))
  signs=Counter('recheck_lower' if x['recheck_minus_myopic']<-1e-10 else 'myopic_lower' if x['recheck_minus_myopic']>1e-10 else 'tie' for x in grid['rows'])
  # Check the manuscript's matched-model optimal value equals evaluation of that policy.
  bellman=[]
  for cell in spec['streams'][::4]:
   s=protocol.policy_spec(cell,spec);dp=protocol.solve(s);optimal=float(dp.value[spec['steps'],1].sum(axis=1).mean());eval_=offline.expected_policy('recheck',s,.12)['objective'];bellman.append({'condition':cell['condition'],'bellman_value':optimal,'own_model_policy_value':eval_,'match':math.isclose(optimal,eval_,abs_tol=1e-10)})
  ck('Bellman vs own-model forward expectation',all(x['match'] for x in bellman),bellman)
  credential_patterns=[r'sk-[A-Za-z0-9_-]{20,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'(?i)bearer\s+[A-Za-z0-9_.-]{20,}']
  sensitive=[]
  for runname in ('R3_smoke','R3_recheck'):
   for p in (f/'runs'/runname).rglob('*'):
    if p.is_file() and 'code_snapshot' not in p.parts and p.suffix in ('.json','.jsonl'):
     if any(re.search(rx,p.read_text(errors='replace')) for rx in credential_patterns):sensitive.append(p.relative_to(f).as_posix())
  ck('three common credential patterns absent in run data',not sensitive,sensitive)
  # Outer loose summaries are evidence copies; compare their bytes to the indexed inner archive.
  copies=[]
  for q in (base/'outer').rglob('*'):
   if not q.is_file() or q.suffix=='.zip' or q.name=='README.md':continue
   candidates=list((f/'offline_reports').rglob(q.name))+list(main.glob(q.name))+list((f/'runs/R3_smoke').glob(q.name))
   copies.append({'basename':q.name,'matching_inner_file':next((p.relative_to(f).as_posix() for p in candidates if bm.get(p.relative_to(f).as_posix())==sha(q)),None)})
  ck('loose summaries match at least one indexed original',all(c['matching_inner_file'] for c in copies),copies)
  write_csv(out/'per_record.csv',rows);write_csv(out/'method_summary.csv',aggregates);write_csv(out/'per_stream.csv',streams);write_csv(out/'paired_treatments.csv',pairs);write_csv(out/'repeat_diagnostics.csv',repeats)
  callrows=[]
  for c in sorted(rawcalls,key=lambda c:(c['run'],c['attempt'])):
   u=c['response']['usage'];callrows.append({'run':c['run'],'attempt':c['attempt'],'logical_id':c['logical_id'],'replicate':c['metadata'].get('replicate','smoke'),'method':c['metadata'].get('method'),'started_utc':c['started_utc'],'ended_utc':c['ended_utc'],'response_id':c['response']['id'],'request_sha256':c['request_sha256'],'finish_reason':c['response']['choices'][0]['finish_reason'],'prompt_tokens':u['prompt_tokens'],'cache_hit':u['prompt_cache_hit_tokens'],'cache_miss':u['prompt_cache_miss_tokens'],'completion_tokens':u['completion_tokens'],'reasoning_tokens':u['completion_tokens_details']['reasoning_tokens'],'latency_seconds':c['latency_seconds'],'estimated_currency_cost':None})
  write_csv(out/'call_ledger.csv',callrows)
  ps=primary_only(pairs);pps=[p for p in pairs if p['replicate']=='repeat'];diffs=[p for p in ps if p['relevant_evidence_differ']]
  totals={}
  for group in ('primary','repeat','smoke','all'):
   x=[c for c in callrows if group=='all' or c['replicate']==group];totals[group]={'calls':len(x),**{k:sum(c[k] for c in x) for k in ('prompt_tokens','cache_hit','cache_miss','completion_tokens','reasoning_tokens','latency_seconds')}}
  stats={'input_hashes':before,'archive':ar,'inner_sha256':sha(inners[0]),'integrity':{'listed_files':len(bm),'source_files':len(sm),'snapshots_per_run':len(sm)},'new_remote_calls':0,'network_access':False,'replay':replay,'ledger':{k:{x:v for x,v in z.items() if x!='order'} for k,z in ledgers.items()},'primary_records':len(primary),'repeat_records':len(reprows),'methods':aggregates,'streams':streams,
   'primary_pair_counts':{'pairs':len(ps),'action_differences':sum(p['probe_actions_differ'] for p in ps),'request_differences':sum(p['request_body_differ'] for p in ps),'relevant_evidence_differences':len(diffs),'only_recheck_correct':sum(p['recheck_success'] and not p['myopic_success'] for p in ps),'only_myopic_correct':sum(p['myopic_success'] and not p['recheck_success'] for p in ps),'different_evidence_both_wrong':sum(not p['recheck_success'] and not p['myopic_success'] for p in diffs),'same_request_success_disagreements':sum(not p['request_body_differ'] and p['recheck_success']!=p['myopic_success'] for p in ps),'both_action_and_evidence_differ':sum(p['probe_actions_differ'] and p['relevant_evidence_differ'] for p in ps),'action_only_differ':sum(p['probe_actions_differ'] and not p['relevant_evidence_differ'] for p in ps),'evidence_only_differ':sum(not p['probe_actions_differ'] and p['relevant_evidence_differ'] for p in ps)},
   'repeat_cross_method_counts':{'pairs':len(pps),'inherited_action_differences':sum(p['probe_actions_differ'] for p in pps),'new_probe_actions':0,'request_differences':sum(p['request_body_differ'] for p in pps),'only_recheck_correct':sum(p['recheck_success'] and not p['myopic_success'] for p in pps),'only_myopic_correct':sum(p['myopic_success'] and not p['recheck_success'] for p in pps)},
   'repeat_within_method':{'comparisons':len(repeats),**{k:sum(x[k] for x in repeats) for k in ('same_request_body','same_raw_content','same_parsed_plan','same_answer','same_reasoning_text','same_completion_tokens','primary_success','repeat_success')}},
   'fidelity':{'all_plan_follows_evidence':sum(r['follows_evidence'] for r in rows),'primary_plan_follows_evidence':sum(r['follows_evidence'] for r in primary),'primary_stale_failures':sum(r['stale'] and not r['success'] for r in primary),'primary_fresh_success':sum(not r['stale'] and r['success'] for r in primary),'primary_interfaces_failed':sum(not r['interface_valid'] for r in primary),'count_all_trivial_primary':sum(r['task_type']==3 for r in primary),'nontrivial_fresh_success':sum(r['task_type']!=3 and not r['stale'] and r['success'] for r in primary)},
   'task_type_counts_primary':dict(Counter(r['task_type'] for r in primary)),'totals':totals,'main_wall_seconds':events['R3_recheck'][1]['wall_seconds'],'main_recorded_start':events['R3_recheck'][0]['utc'],'main_recorded_end':events['R3_recheck'][1]['utc'],'grid':{'cells':len(grid['rows']),'signs':dict(signs),'label':grid['label']},'bellman_checks':bellman,
   'conclusions_scope':'Accepted as internally consistent development logs; neither provider weight attestation nor invoice nor independent human review.'}
  save(out/'independent_results.json',stats);save(out/'checks.json',checks)
  # Only primary examples; no reasoning transcript is needed as purported causal evidence.
  save(out/'evidence_examples.json',{'different_relevant_evidence_primary':diffs,'repeat_visible_format_examples':[{'logical_id':b['logical_id'],'primary_text':calls[b['logical_id'].replace('/repeat','/primary')]['text'],'repeat_text':b['text']} for b in rawcalls if b['metadata'].get('replicate')=='repeat' and b['text']!=calls[b['logical_id'].replace('/repeat','/primary')]['text']][:6]})
 ck('input archives unchanged',before=={str(p):sha(p) for p in (feedback_zip,original_zip)})
 save(out/'checks.json',checks)
 print(json.dumps({'all_checks_pass':all(c['pass'] for c in checks),'checks':len(checks),'primary_pairs':stats['primary_pair_counts'],'repeat':stats['repeat_within_method'],'outputs':str(out)},ensure_ascii=False,indent=2))
 return stats

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--feedback',type=Path,required=True);p.add_argument('--original',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 def blocked(*args,**kwargs):raise RuntimeError('All network connections disabled for offline review')
 socket.socket.connect=blocked;socket.socket.connect_ex=blocked;socket.create_connection=blocked
 audit(a.feedback.resolve(),a.original.resolve(),a.out.resolve())
