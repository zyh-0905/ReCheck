# R3 审核附件：如何离线复核

本包只审核已回传的固定R3数据，不是R4实验包。不要为此调用任何远端模型，不修改旧运行，不把模拟测试输出当成研究结果。

## 文件
- `audit_r3.py`：独立哈希、账本、固定协议、算术评测、主/重复分组和重放审核。
- `test_audit_r3.py`：17项审核器测试。
- `run_original_tests.py`：运行原交付包77项测试，仅允许回环HTTP测试服务。
- `results/`：机器可读结果、逐调用、逐结果、逐流、处理差异与重复诊断。
- `R3_Review_Report_ZH.md`、`R3_Factual_Corrections_ZH.md`：判断和更正；不是改写原README。
- `R3_Paper_Insert_EN.md`：可作为论文开发实验附录的谨慎表述，不是直接提交版。
- `R4_Research_Gates_ZH.md`：下一阶段的研究门槛，不授权新付费批次。

## 复核
使用Python 3.11+，numpy采用原包版本2.3.5。两个ZIP分别是本次原反馈和先前分发的R3执行包。

```bash
python -m unittest discover -s . -p test_audit_r3.py -v
python audit_r3.py --feedback /path/a46910a7-8636-4bf3-a2c2-c5ccb28c8fe0.zip --original /path/Research_Handoff_R3.zip --out review_results
```

审核脚本固定原包哈希，拒绝自动执行未知代码。原始ZIP只读，在临时目录重建；程序禁止socket连接，不创建真实模型客户端。原始请求、响应、代码、配置和重建任务记录保持严格一致性检查；重建记录仅排除原协议明确的3个计时字段。派生汇总中的浮点数允许1e-10绝对误差，以兼容此次运行环境之间约1e-14的求和表示差，不放宽原始证据检查。

如需运行原包测试，先将原始执行包解压到独立目录：

```bash
python run_original_tests.py /path/R3_Research_Kit
```

审核原环境Linux/CPython3.13.5/numpy2.3.5；用户运行记录Darwin/Python3.11.15/numpy2.3.5。这里的复核不是独立人类同行评审，不认证服务商真实权重、账单或操作者全部历史活动。不需要用户重复执行此审核来推进研究。
