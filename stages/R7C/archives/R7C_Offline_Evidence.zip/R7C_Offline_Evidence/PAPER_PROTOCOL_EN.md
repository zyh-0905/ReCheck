# R7C protocol paragraph — results pending
We next specify an exploratory native-tool diagnosis using a pinned ToolSandbox revision
(c8571d7854316d2e1c5f288e59fe1e34e53f6dd1). The extension contains fourteen constructed
cases spanning person-directed messaging, literal-address messaging, and reminder selection
by current description. These are three intent templates over two tool domains, not fourteen
independent original benchmark tasks. Cases include stable state, irrelevant changes,
relevant changes with stale or refreshed pre-task observations, and two explicit connectivity
failures combined with address reassignment.

Each case is evaluated with a stateless input, inherited evidence, and the same inherited
evidence augmented by a general pre-write target-resolution instruction. The stateless
condition is an information ablation, not a length-matched control. All conditions have the
same native tool permissions and an eight-request episode bound. Two prespecified cases
are independently repeated once per condition; these six repeat episodes are reported
separately and never replace primary outcomes. No model-based user simulator or grader
is used. The model generates one bounded JSON tool action at a time. Native tool returns
are passed back verbatim in a deterministic wrapper; private state and grading targets are
not supplied to the model.

Scoring requires the requested state change and the absence of unintended writes throughout
the trajectory. Fixing the target after a wrong write does not erase that violation.
Native clocks and generated identifiers are retained; offline replay injects their recorded
values only to verify state transitions. API usage and latency include all primary,
repeat, and smoke requests and are not equated with invoice charges. Fixed scripted
solvability controls succeeded in all cases, which does not establish that an LLM will
discover the same actions or that a complex controller is necessary. Real-model outcomes
remain pending; this protocol is not a claim of ReCheck superiority or official ToolSandbox
benchmark performance.
