import sys,os,shutil,json,time,tempfile
from pathlib import Path
source=Path(os.environ.get('VALIDATION_SOURCE','/mnt/data/r7c_work/R7C_Research_Kit'));sys.path[:0]=[str(source),str(source/'tests')]
from r7c.core import read,write,file_sha,source_manifest,verify_sources,digest
from r7c.journal import Journal,Paused
from r7c.actor import SMOKE_MESSAGES
from r7c.experiment import episode,schedule
from r7c.review import audit
from r7c.storage import export,verify_bundle
import http_fixture

def one(label,loop=False):
 root=Path('/mnt/data/r7c_work')/label
 if root.exists():raise RuntimeError('Fresh validation dir required')
 root.mkdir()
 files=read(source/'SOURCE_MANIFEST.json')['files']
 for rel in files:
  dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/rel,dest)
 shutil.copyfile(source/'SOURCE_MANIFEST.json',root/'SOURCE_MANIFEST.json')
 prep={'source_manifest_sha256':file_sha(root/'SOURCE_MANIFEST.json'),'cases_sha256':file_sha(root/'fixtures/cases.json'),'protocol_sha256':file_sha(root/'configs/protocol.json')}
 write(root/'PREPARED.json',prep);run=root/'runs/R7C';run.mkdir(parents=True)
 write(run/'manifest.json',{'prepared':prep,'evidence_kind':'SOFTWARE_TEST_NOT_RESEARCH'})
 for rel in files:
  p=run/'code_snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
 proto=read(root/'configs/protocol.json');cases=read(root/'fixtures/cases.json');byid={c['id']:c for c in cases}
 original=http_fixture.decide
 if loop:
  def decide(p):
   if p['messages'][-1]['content']=='Return {"ok":true} exactly.':return {'ok':True}
   q=json.loads(p['messages'][-1]['content']);t=q['task']
   if 'Send exactly' in t:n='search_contacts';a={'name':'Mira Chen'}
   elif 'reminder' in t:n='search_reminder';a={'content':'Submit the orange folder'}
   else:n='get_wifi_status';a={}
   return {'action':'tool','name':n,'arguments':a}
  http_fixture.decide=decide
 try:
  with http_fixture.server() as (url,state):
   j=Journal(run,proto,endpoint=url,fixture=True)
   obj,_=j.complete('smoke',SMOKE_MESSAGES,{'phase':'smoke'});assert obj=={'ok':True}
   for cid,m in schedule(cases,proto['schedule_seed']):episode(byid[cid],m,j,run/'episodes'/f'{cid}__{m}.json')
   write(run/'status.json',{'state':'completed'})
   n=len(state['requests'])
   try:j.complete('smoke',SMOKE_MESSAGES,{'phase':'smoke'})
   except Paused:pass
   else:raise AssertionError('resample allowed')
   assert len(state['requests'])==n
   if loop:
    assert n==433
    try:j.complete('extra',SMOKE_MESSAGES,{})
    except Paused:pass
    else:raise AssertionError('cap not enforced')
    assert len(state['requests'])==n
  result=audit(root);assert result['mechanical_pass'],result
  bundle=export(root);bv=verify_bundle(bundle)
  write(Path('/mnt/data/r7c_work/verification')/(label+'.json'),{'network_fixture_calls':n,'remote_calls':0,'audit':result,'export':bv,'no_resampling':True,'cap_test':loop})
 finally:http_fixture.decide=original
 print('COMPLETE',label,n,result['method_summary'],flush=True)
 return root
one(sys.argv[1],loop='loop' in sys.argv[1])
