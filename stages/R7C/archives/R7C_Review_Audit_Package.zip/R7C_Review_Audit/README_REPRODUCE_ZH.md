# R7C接口暂停审核的复核

此包是审计材料，不是付费运行包。真实模型继续执行请使用另行交付Research_Handoff_R7C1.zip。

核心独立审核只使用Python标准库，输入为用户原反馈ZIP和旧R7C分发ZIP：
```bash
python -m unittest discover -s tests -v
python audit_feedback.py --feedback /path/13081fe6-3570-4a9a-a0d3-abb338e58feb.zip --original /path/Research_Handoff_R7C.zip --out reproduced
```
脚本只读输入，不联网，不执行ZIP中的代码，不写回原文件。应产生121项清单验证、111个登记源码匹配、1个smoke请求重建和0个研究回合。

results目录同时保存：原始smoke与paused记录、独立账本、元数据修订diff、两个软件fixture结果及其完整反馈。软件fixture绝非真实模型数据。partial_software_fixture.zip保留首次命令执行时限中断的部分软件测试记录，不并入科学样本。

验证新包的完整模拟链需要Python3.11.x和分发包固定依赖。validate_full_fixture.py使用本机HTTP服务，禁止远端网络。示例：
```bash
python3.11 validate_full_fixture.py /path/R7C1_Research_Kit /new/temp_fixture rule
```
极限cap模式每回合8次、共385次本机请求。原验证在完成main后分开audit/export，以避免工具命令时限。此包日志披露首次中断，不将其隐藏。run_local_verification.py是研究端启动记录，original_pause模式含当前工作区路径，仅用于追溯，不是用户必须执行的命令。

无新增真实模型调用。不会修改旧论文主结果。研究助手的离线复核不是独立人类同行审查。
