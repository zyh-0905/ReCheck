
import sys,os,json,threading,shutil,time
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
os.environ['POLARS_MAX_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
import socket
_original_connect=socket.socket.connect
def _only_loopback(self,address):
 if not isinstance(address,tuple) or address[0] not in ('127.0.0.1','::1','localhost'):raise RuntimeError('Remote network prohibited in verification')
 return _original_connect(self,address)
socket.socket.connect=_only_loopback
src=Path(sys.argv[1]);dest=Path(sys.argv[2]);mode=sys.argv[3]
sys.path[:0]=[str(src),str(src/'vendor/toolsandbox')]
from r7clib.artifacts import source_hashes,export_bundle,verify_bundle
from r7clib.runtime import prepare,smoke,run
from r7clib.audit import audit
from r7clib.cases import rule_action
from pilot.common import write_json,read_json
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('runs','uploads','PREPARED.json','offline_reports','__pycache__','.pytest_cache','verification'))
cfg=read_json(dest/'config.example.json')
counter={'n':0}
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  q=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  counter['n']+=1
  if counter['n']==1:obj={'done':'ready'}
  elif mode=='cap':obj={'tool':'get_cellular_service_status','arguments':{}}
  else:
   msgs=q['messages'];pub=json.loads(msgs[1]['content']);history=[]
   for a,b in zip(msgs[2::2],msgs[3::2]):
    action=json.loads(a['content'])
    if 'tool' in action:history.append({**action,'response':json.loads(b['content'].removeprefix('TOOL_RESULT '))})
   obj=rule_action(pub,history,'resolve')
  raw=json.dumps({'id':f'local-only-{counter["n"]}','model':'fixture','system_fingerprint':'local-v1',
    'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':json.dumps(obj)}}],
    'usage':{'prompt_tokens':10,'completion_tokens':5,'total_tokens':15}}).encode()
  self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
httpd=ThreadingHTTPServer(('127.0.0.1',0),Handler)
t=threading.Thread(target=httpd.serve_forever,daemon=True);t.start()
cfg.update(backend_kind='test_fixture',model='fixture',base_url=f'http://127.0.0.1:{httpd.server_port}',min_interval_seconds=0)
p=prepare(dest,cfg)
try:
 try:run(dest,384,secret='local-only-credential');blocked=False
 except ValueError:blocked=True
 sm=smoke(dest,1,secret='local-only-credential')
 st=run(dest,384,secret='local-only-credential')
 n=counter['n'];again=run(dest,384,secret='local-only-credential');no_retry=counter['n']==n
 a=audit(dest);bundle=export_bundle(dest);vb=verify_bundle(bundle)
 result={'label':'SOFTWARE_TEST_NOT_RESEARCH','mode':mode,'smoke_required':blocked,
  'smoke':sm,'main':st,'requests_seen':counter['n'],'no_resampling':no_retry,
  'audit':a,'bundle':vb,'new_remote_model_calls':0}
 write_json(dest/'VALIDATION.json',result)
 print('FINAL',json.dumps(result))
 if not (blocked and sm['status']=='completed' and st['status']=='completed' and no_retry and a['mechanical_pass']):raise SystemExit(2)
 if mode=='cap' and counter['n']!=385:raise SystemExit(3)
finally:
 httpd.shutdown();httpd.server_close();t.join()
