import unittest, copy
from audit_feedback import validate_smoke, compare_source, canonical_hash

class SmokeTests(unittest.TestCase):
 def fixture(self):
  p={'model':'deepseek-v4-flash','messages':[{'role':'system','content':'Return exactly one JSON object: {"done":"ready"}.'},{'role':'user','content':'Check the JSON-only interface.'}],'stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high'}
  return {'status':'ok','logical_id':'smoke','attempt':1,'metadata':{'phase':'smoke'},'payload':p,'payload_sha256':canonical_hash(p),'request_sha256':canonical_hash({'endpoint':'https://api.deepseek.com/v1','payload':p}),'text':'{"done":"ready"}', 'response':{'model':'deepseek-flash','system_fingerprint':'recorded-fixture','choices':[{'finish_reason':'stop','message':{'content':'{"done":"ready"}'}}],'usage':{'prompt_tokens':48,'completion_tokens':21,'total_tokens':69,'prompt_cache_hit_tokens':0,'prompt_cache_miss_tokens':48,'prompt_tokens_details':{'cached_tokens':0},'completion_tokens_details':{'reasoning_tokens':15}}}}
 def test_original_mismatch_is_recorded_not_task_failure(self):
  x=validate_smoke(self.fixture());self.assertTrue(x['payload_valid']);self.assertFalse(x['exact_label_match']);self.assertEqual(x['completed_task_episodes'],0)
 def test_no_mismatch_if_equal(self):
  f=self.fixture();f['response']['model']=f['payload']['model'];self.assertTrue(validate_smoke(f)['exact_label_match'])
 def test_request_corruption(self):
  f=self.fixture();f['payload']['model']='other'
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_wrong_metadata(self):
  f=self.fixture();f['metadata']['phase']='primary'
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_wrong_output(self):
  f=self.fixture();f['text']='{"done":"not ready"}';f['response']['choices'][0]['message']['content']=f['text']
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_bad_total(self):
  f=self.fixture();f['response']['usage']['total_tokens']=1
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_bool_usage(self):
  f=self.fixture();f['response']['usage']['completion_tokens']=True
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_cache_total(self):
  f=self.fixture();f['response']['usage']['prompt_cache_miss_tokens']=49
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_truncation(self):
  f=self.fixture();f['response']['choices'][0]['finish_reason']='length'
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_reasoning_bound(self):
  f=self.fixture();f['response']['usage']['completion_tokens_details']['reasoning_tokens']=22
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_content_mismatch(self):
  f=self.fixture();f['text']='{}'
  with self.assertRaises(ValueError):validate_smoke(f)
 def test_source_rejects_changes(self):
  with self.assertRaises(ValueError):compare_source({'a':b'a'},{'a':b'b'})
 def test_source_rejects_missing(self):
  with self.assertRaises(ValueError):compare_source({'a':b'a'},{})
 def test_source_accepts(self):self.assertEqual(compare_source({'a':b'a'},{'a':b'a'}),1)
