import sys,os,socket,unittest,json,tempfile,shutil
from pathlib import Path
root=Path(sys.argv[1]).resolve();mode=sys.argv[2]
sys.path[:0]=[str(root),str(root/'vendor/toolsandbox')]
os.environ['POLARS_MAX_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
old=socket.socket.connect
allowed=0
blocked=0
def only_local(self,address):
 global allowed,blocked
 if isinstance(address,tuple) and address[0] in ('localhost','127.0.0.1','::1'):
  allowed+=1;return old(self,address)
 blocked+=1;raise RuntimeError('Review process prohibits remote network')
socket.socket.connect=only_local
if mode=='tests':
 suite=unittest.TestLoader().discover(str(root/'tests'));r=unittest.TextTestRunner(verbosity=2).run(suite)
 print(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'local_connections':allowed,'remote_attempts_blocked':blocked}))
 sys.exit(not r.wasSuccessful())
elif mode=='original_pause':
 from r7clib.transport import Client
 from pilot.client import RunStopped
 from pilot.common import read_json
 from r7clib.runtime import run
 from r7clib.audit import audit
 source=Path('/mnt/data/r7c_review_work/submitted')
 observed=read_json(source/'runs/R7C_smoke/attempts/000001_result.json')
 cfg=read_json(source/'PREPARED.json')['config']
 with tempfile.TemporaryDirectory() as d:
  c=Client(cfg,d,secret='',cap=1)
  try:c._validate_saved(observed);raise AssertionError('must pause')
  except RunStopped as e:print('ORIGINAL_PAUSE_REPRODUCED:',e)
 with tempfile.TemporaryDirectory() as d:
  p=Path(d);shutil.copytree(root,p,dirs_exist_ok=True)
  for n in ('PREPARED.json','runs'):
   if (source/n).is_dir():shutil.copytree(source/n,p/n)
   else:shutil.copy2(source/n,p/n)
  a=audit(p);print('ORIGINAL_AUDIT:',json.dumps(a))
  try:run(p,384,secret='NOT_SENT');raise AssertionError('must block before request')
  except ValueError as e:print('MAIN_BLOCK_REPRODUCED:',e)
 print('NETWORK',allowed,blocked)
