"""Offline evidence audit for the submitted R7C smoke-only bundle. No network calls."""
from pathlib import Path, PurePosixPath
import json, hashlib, zipfile, io, stat, argparse, csv

def canonical_hash(x):
 return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def require(test,msg):
 if not test:raise ValueError(msg)
def archive_members(source):
 with zipfile.ZipFile(source) as z:
  infos=z.infolist();names=[i.filename for i in infos]
  require(len(names)==len(set(names)),'duplicate members')
  require(sum(i.file_size for i in infos)<800_000_000,'oversized archive')
  for i in infos:
   p=PurePosixPath(i.filename)
   require(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename,'unsafe path')
   require(not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1,'link/encryption')
  return {i.filename:z.read(i.filename) for i in infos if not i.is_dir()}
def compare_source(a,b):
 require(set(a)==set(b),'source file set changed')
 for n in a:require(a[n]==b[n],'source bytes changed: '+n)
 return len(a)
def validate_smoke(r):
 require(r['status']=='ok','transport failed')
 p=r['payload']; endpoint='https://api.deepseek.com/v1'
 expected={'model':'deepseek-v4-flash','messages':[{'role':'system','content':'Return exactly one JSON object: {"done":"ready"}.'},{'role':'user','content':'Check the JSON-only interface.'}],'stream':False,'max_tokens':16384,'thinking':{'type':'enabled'},'reasoning_effort':'high'}
 require(p==expected,'smoke payload differs from original frozen request')
 require(r['payload_sha256']==canonical_hash(p),'payload hash')
 require(r['request_sha256']==canonical_hash({'endpoint':endpoint,'payload':p}),'request hash')
 require(r['logical_id']=='smoke' and type(r['attempt']) is int and r['attempt']==1 and r['metadata']=={'phase':'smoke'},'logical metadata')
 b=r['response'];require(len(b['choices'])==1,'choice count')
 require(b['choices'][0]['finish_reason']=='stop','completion not stopped')
 require(r['text']==b['choices'][0]['message']['content'],'raw content mismatch')
 require(json.loads(r['text'])=={'done':'ready'},'smoke object not ready')
 u=b['usage']
 for k in ('prompt_tokens','completion_tokens','total_tokens'):require(type(u[k]) is int and u[k]>=0,'usage type/range')
 require(u['total_tokens']==u['prompt_tokens']+u['completion_tokens'],'usage sum')
 rt=u['completion_tokens_details']['reasoning_tokens'];require(type(rt)is int and 0<=rt<=u['completion_tokens'],'reasoning bounds')
 hit=u['prompt_cache_hit_tokens'];miss=u['prompt_cache_miss_tokens']
 require(type(hit)is int and type(miss)is int and hit>=0 and miss>=0 and hit+miss==u['prompt_tokens'],'cache sum')
 require(u['prompt_tokens_details']['cached_tokens']==hit,'cached details')
 return {'payload_valid':True,'smoke_json_valid':True,'usage_valid':True,'requested_model':p['model'],'returned_model':b['model'],'system_fingerprint':b['system_fingerprint'],'exact_label_match':p['model']==b['model'],'prompt_tokens':u['prompt_tokens'],'completion_tokens':u['completion_tokens'],'reasoning_tokens':rt,'total_tokens':u['total_tokens'],'completed_task_episodes':0}
def audit(feedback,original,out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 outer=archive_members(feedback);inners=[n for n in outer if n.endswith('.zip') and not n.startswith('__MACOSX/')]
 require(len(inners)==1,'expected one feedback ZIP')
 data=archive_members(io.BytesIO(outer[inners[0]]));manifest=json.loads(data['BUNDLE_MANIFEST.json'])
 require(set(data)==set(manifest['sha256'])|{'BUNDLE_MANIFEST.json'},'bundle member set')
 for n,h in manifest['sha256'].items():require(hashlib.sha256(data[n]).hexdigest()==h,'bundle hash '+n)
 orig=archive_members(original);prefix='R7C_Research_Kit/'
 orig={n[len(prefix):]:v for n,v in orig.items() if n.startswith(prefix)}
 src={n.removeprefix('kit_source/'):v for n,v in data.items() if n.startswith('kit_source/')}
 source_count=compare_source(orig,src)
 sm=json.loads(src['SOURCE_MANIFEST.json']);require(set(sm['sha256'])==set(src)-{'SOURCE_MANIFEST.json'},'source manifest keys')
 for n,h in sm['sha256'].items():require(hashlib.sha256(src[n]).hexdigest()==h,'source manifest hash')
 p=json.loads(data['PREPARED.json']);contract={k:p[k] for k in ('config','protocol','source')}
 require(canonical_hash(contract)==p['fingerprint'],'prepared fingerprint')
 require(p['config']==json.loads(src['config.example.json']),'frozen config')
 require(p['protocol']==json.loads(src['protocol.json']),'frozen protocol')
 require(p['source']==sm['sha256'],'prepared source')
 run='runs/R7C_smoke/';m=json.loads(data[run+'manifest.json'])
 require(m['prepared_fingerprint']==p['fingerprint'],'manifest prepared hash')
 for k in contract:require(m[k]==p[k],'manifest '+k)
 starts=[n for n in data if n.endswith('_start.json')];results=[n for n in data if n.endswith('_result.json') and '/attempts/' in n];calls=[n for n in data if '/calls/' in n]
 require(len(starts)==len(results)==len(calls)==1,'not smoke-only ledger')
 st=json.loads(data[starts[0]]);r=json.loads(data[results[0]]);c=json.loads(data[calls[0]])
 require(c==r,'call vs result');require(calls[0]==run+'calls/'+canonical_hash('smoke')+'.json','call filename')
 for k,v in st.items():require(r[k]==v,'start vs result')
 si=json.loads(data[run+'attempts/000001_send_intent.json'])
 require(si['attempt']==1 and si['logical_id']=='smoke' and si['proves_remote_receipt']is False,'send intent')
 require(st['started_utc']<=si['local_send_intent_utc']<=r['ended_utc'],'event chronology')
 status=json.loads(data[run+'status.json']);require(status['status']=='paused','paused marker')
 require('Returned model differs' in status['error'],'expected pause reason')
 validated=validate_smoke(r)
 ep=[n for n in data if '/episodes/' in n or n.startswith('runs/R7C_main/')]
 require(not ep,'unexpected main artifacts')
 convenience=[]
 for n,v in outer.items():
  if n.startswith('__MACOSX/') or n.endswith(('.zip','.md')):continue
  bn=n.rsplit('/',1)[-1]
  targets=[t for t in data if t.endswith('/'+bn)]
  require(len(targets)==1 and data[targets[0]]==v,'convenience copy '+bn);convenience.append(bn)
 a=json.loads(data['offline_reports/AUDIT.json'])
 require(a['completed_primary']==a['completed_repeat']==a['reconstructed_requests']==0 and a['requests_registered']==1,'original audit scope')
 require(a['mechanical_pass']is True and a['issues']==[],'unexpected original audit')
 v={'audit_phase':'R7C_SMOKE_ONLY_REVIEW','input_sha256':hashlib.sha256(Path(feedback).read_bytes()).hexdigest(),'original_kit_sha256':hashlib.sha256(Path(original).read_bytes()).hexdigest(),'inner_sha256':hashlib.sha256(outer[inners[0]]).hexdigest(),'bundle_data_files_verified':len(manifest['sha256']),'archive_files_including_manifest':len(data),'source_registered_files':len(sm['sha256']),'source_files_including_manifest':source_count,'convenience_copies_verified':len(convenience),'frozen_config_and_bindings_match':True,'recorded_generation_starts':1,'recorded_generation_responses':1,'smoke_requests_independently_reconstructed':1,'main_calls':0,'primary_episodes':0,'repeat_episodes':0,'raw_status':status,'smoke_checks':validated,'latency_seconds':r['latency_seconds'],'end_utc':r['ended_utc'],'old_audit_mechanical_pass_is_not_scientific_completion':True,'provider_weight_identity_verified':False,'billing':'UNKNOWN','out_of_band_models_probe':'README claim; no raw GET /models response included; cannot audit total external requests','researcher_remote_calls':0,'evidence_acceptance':'ACCEPT_SMOKE_FAILURE_EVIDENCE; TASK_EXPERIMENT_NOT_STARTED'}
 for name,obj in [('verification.json',v),('observed_smoke.json',r),('original_status.json',status),('original_automated_audit.json',a)]:
  (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 with (out/'call_ledger.csv').open('w',newline='') as f:
  row={k:v['smoke_checks'][k] for k in ('requested_model','returned_model','prompt_tokens','completion_tokens','reasoning_tokens','total_tokens')};row.update(logical_id='smoke',status='paused_label_mismatch',task_episodes=0,latency_seconds=r['latency_seconds'],billing='UNKNOWN');w=csv.DictWriter(f,fieldnames=row.keys());w.writeheader();w.writerow(row)
 return v
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--feedback',required=True);ap.add_argument('--original',required=True);ap.add_argument('--out',required=True);args=ap.parse_args();print(json.dumps(audit(args.feedback,args.original,args.out),ensure_ascii=False,indent=2))
