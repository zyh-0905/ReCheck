# R1 复核附件使用说明

当前附件是审计交付，不是新的实验运行包。用户不必再次执行；下面仅用于复现核查。

所需输入（保持原文件名）：
- 本轮反馈`09af9535-f0df-4db5-a4a9-60a6b8f1b839.zip`
- 原始收集工具`Research_Handoff_R1.zip`
- 原LLM预实验包`LLM_Pilot_Kit_v0.1.zip`
- 上次反馈`8a80ceb7-3588-4ffe-a4b2-4d6c9943b2d5.zip`

Python 3.10+、numpy（原实验锁定2.3.5；本轮核查的实际版本见DELIVERY_VERIFICATION.json）。在上述输入所在目录执行：

```bash
python audit_r1.py --feedback 09af9535-f0df-4db5-a4a9-60a6b8f1b839.zip --handoff Research_Handoff_R1.zip --pilot LLM_Pilot_Kit_v0.1.zip --previous 8a80ceb7-3588-4ffe-a4b2-4d6c9943b2d5.zip --out reproduced_audit
```

脚本不需要密钥，不实例化网络客户端，不调用模型，不改原始ZIP。只在临时目录用原版代码重放已有响应；新输出写入`reproduced_audit/`。本次验证环境为Linux，不宣称Windows/macOS实机复验。

`R1_Review_Result.json`为独立计算结果；`R1_Call_Ledger.csv`中的空值代表没有原始记录，不代表0。
`conditional_previous_tariff_cny`仅沿用上轮费率做条件计算，不是当前价格认证或服务商账单。

摘要、更正说明与原始反馈应并存，禁止用更正文件覆盖旧日志或伪装为操作者亲历陈述。
