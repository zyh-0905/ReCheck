#!/usr/bin/env python3
"""Read-only R1 evidence audit. No model/client/network calls.

Usage: python audit_r1.py --feedback INPUT.zip --handoff Research_Handoff_R1.zip
    --pilot LLM_Pilot_Kit_v0.1.zip --previous PREVIOUS.zip --out audit_output
Archives are treated as data; offline replay imports ONLY byte-matched original
pilot source, redirects its outputs to a temporary directory, and replaces its
model client with recorded responses. Missing responses stop, never resample.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, re, stat, sys, tempfile, zipfile
from collections import Counter
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path, PurePosixPath


def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(x): return sha(canonical(x))
def jload(b):
    def pairs(ps):
        d={}
        for k,v in ps:
            if k in d: raise ValueError('duplicate JSON key')
            d[k]=v
        return d
    def bad(s): raise ValueError('nonfinite number')
    return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def archive(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos=z.infolist()
        assert len(infos)<10000 and sum(i.file_size for i in infos)<128_000_000
        names=set(); out={}
        for i in infos:
            p=PurePosixPath(i.filename)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
            assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits & 1
            assert i.filename not in names; names.add(i.filename)
            if not i.is_dir(): out[i.filename]=z.read(i)
        return out

def drop_root(files):
    return {n.split('/',1)[1]:b for n,b in files.items() if '/' in n}
def write_json(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def iso(t): return datetime.fromisoformat(t)
def cost(u, prices):
    ni=Decimal(u['prompt_tokens']); no=Decimal(u['completion_tokens'])
    cached=Decimal((u.get('prompt_tokens_details') or {}).get('cached_tokens',0))
    return ((ni-cached)*Decimal(str(prices[0]))+cached*Decimal(str(prices[1]))+no*Decimal(str(prices[2])))/Decimal(1_000_000)


def main():
    ap=argparse.ArgumentParser();
    for a in ['feedback','handoff','pilot','previous','out']: ap.add_argument('--'+a,required=True,type=Path)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    input_paths=[args.feedback,args.handoff,args.pilot,args.previous]
    before={p.name:sha(p.read_bytes()) for p in input_paths}
    outer=archive(args.feedback.read_bytes())
    nested_candidates=[(n,b) for n,b in outer.items() if n.endswith('.zip') and not n.startswith('__MACOSX/')]
    assert len(nested_candidates)==1
    nested_name,nested_data=nested_candidates[0]; bundle=archive(nested_data)
    bm=jload(bundle['BUNDLE_MANIFEST.json']); index=bm['sha256']
    assert set(index)==set(bundle)-{'BUNDLE_MANIFEST.json'}
    assert all(sha(bundle[n])==h for n,h in index.items())
    for n,b in bundle.items():
        if n.endswith('.json'): jload(b)
    original_handoff=drop_root(archive(args.handoff.read_bytes()))
    assert bundle['TASK_CONTRACT.json']==original_handoff['TASK_CONTRACT.json']
    contract=jload(bundle['TASK_CONTRACT.json']); local=jload(bundle['LOCAL_CHECKS.json'])
    run={n.removeprefix('evidence/run/'):b for n,b in bundle.items() if n.startswith('evidence/run/')}
    manifest=jload(run['manifest.json']);cfg=manifest['config']
    assert manifest['study']==contract['expected_study'] and cfg['max_output_tokens']==4096
    assert manifest['fingerprint']==contract['expected_fingerprint']
    assert sha(run['manifest.json'])==contract['prior_manifest_sha256']
    frozen={k:manifest[k] for k in ('version','config','study','spec','source_hashes')}
    assert digest(frozen)==manifest['fingerprint']
    previous=archive(args.previous.read_bytes())
    old_candidates=[(n,b) for n,b in previous.items() if '4096' in n and n.endswith('/manifest.json')]
    assert len(old_candidates)==1 and run['manifest.json']==old_candidates[0][1]
    previous_summaries={}
    for suffix in ('status.json','controller_metadata.json'):
        matches=[(n,b) for n,b in previous.items() if '4096' in n and n.endswith('/'+suffix)]
        assert len(matches)==1
        previous_summaries[suffix]={'same_bytes':run[suffix]==matches[0][1]}
        assert previous_summaries[suffix]['same_bytes']
    pilot=drop_root(archive(args.pilot.read_bytes()))
    source_check={}
    for rel,h in manifest['source_hashes'].items():
        b=run['code_snapshot/'+rel]
        source_check[rel]={'matches_manifest':sha(b)==h,'matches_original':b==pilot[rel]}
        assert all(source_check[rel].values())
    actual_snapshot={n.removeprefix('code_snapshot/') for n in run if n.startswith('code_snapshot/')}
    assert actual_snapshot==set(manifest['source_hashes'])
    starts={int(PurePosixPath(n).name[:6]):jload(b) for n,b in run.items() if n.startswith('attempts/') and n.endswith('_start.json')}
    results={int(PurePosixPath(n).name[:6]):jload(b) for n,b in run.items() if n.startswith('attempts/') and n.endswith('_result.json')}
    calls={jload(b)['logical_id']:(n,b,jload(b)) for n,b in run.items() if n.startswith('calls/')}
    assert list(sorted(starts))==list(range(1,len(starts)+1))
    assert set(results)<=set(starts)
    assert len(calls)==sum(n.startswith('calls/') for n in run)==len(results)
    assert len({s['logical_id'] for s in starts.values()})==len(starts)
    endpoint=contract['request_endpoint_for_hash_check'];assert digest(endpoint)==cfg['base_url_sha256']
    ledger=[];response_ids=[]
    for i,s in sorted(starts.items()):
        assert i==s['attempt']
        assert s['request_sha256']==digest({'endpoint':endpoint,'payload':s['payload']})
        assert s['payload']['model']==cfg['model'] and s['payload']['max_tokens']==4096
        assert set(s['payload'])=={'model','messages','stream','max_tokens'}
        row={'attempt':i,'logical_id':s['logical_id'],'started_utc':s['started_utc'],
             'status':'no_result_record','finish_reason':'','ended_utc':'','prompt_tokens':None,
             'cached_input_tokens':None,'completion_tokens':None,'reasoning_tokens':None,
             'visible_chars':None,'estimated_cost_config_usd':None,
             'conditional_previous_tariff_cny':None,'response_id':''}
        if i in results:
            r=results[i]; assert all(r[k]==v for k,v in s.items())
            callname,callbytes,call=calls[s['logical_id']]
            assert callname=='calls/'+digest(s['logical_id'])+'.json'
            assert run[f'attempts/{i:06d}_result.json']==callbytes
            assert r['status']=='ok' and iso(r['ended_utc'])>=iso(s['started_utc'])
            resp=r['response'];choice=resp['choices'][0];u=resp['usage'];response_ids.append(resp['id'])
            assert resp['model']==cfg['model']; assert len(resp['choices'])==1
            assert u['prompt_tokens']+u['completion_tokens']==u['total_tokens']
            cached=u['prompt_tokens_details']['cached_tokens']; assert cached==u['prompt_cache_hit_tokens']
            assert cached+u['prompt_cache_miss_tokens']==u['prompt_tokens']
            assert u['completion_tokens_details']['reasoning_tokens']<=u['completion_tokens']<=4096
            assert r['text']==choice['message']['content']
            c=cost(u,(cfg['prices']['input_per_million'],cfg['prices']['cached_input_per_million'],cfg['prices']['output_per_million']))
            assert abs(float(c)-r['estimated_cost'])<1e-14
            assert datetime.fromtimestamp(resp['created'],tz=iso(s['started_utc']).tzinfo)<=iso(r['ended_utc'])
            row.update(status='response_recorded',finish_reason=choice['finish_reason'],ended_utc=r['ended_utc'],
                       prompt_tokens=u['prompt_tokens'],cached_input_tokens=cached,completion_tokens=u['completion_tokens'],
                       reasoning_tokens=u['completion_tokens_details']['reasoning_tokens'],visible_chars=len(r['text']),
                       estimated_cost_config_usd=str(c),conditional_previous_tariff_cny=str(cost(u,(1,.02,4))),response_id=resp['id'])
        ledger.append(row)
    assert len(set(response_ids))==len(response_ids)
    recorded=[x for x in ledger if x['status']=='response_recorded']
    assert all(iso(starts[i+1]['started_utc'])>=iso(results[i]['ended_utc']) for i in results if i+1 in starts)
    pending=[x for x in ledger if x['status']=='no_result_record'];truncated=[x for x in recorded if x['finish_reason']=='length']
    assert len(pending)==1 and pending[0]['attempt']==9
    assert len(truncated)==1 and truncated[0]['attempt']==5
    totals={k:sum(x[k] for x in recorded) for k in ('prompt_tokens','completion_tokens','reasoning_tokens','cached_input_tokens')}
    totals['uncached_input_tokens']=totals['prompt_tokens']-totals['cached_input_tokens']
    totals['config_usd_estimate']=str(sum(Decimal(x['estimated_cost_config_usd']) for x in recorded))
    totals['conditional_previous_tariff_cny']=str(sum(Decimal(x['conditional_previous_tariff_cny']) for x in recorded))
    # Cross-check old report, old full-run response IDs, and preserved complete runs.
    previous_complete={};previous_ids=set();previous_all_calls=[]
    for n,b in previous.items():
        if n.endswith('.zip'):
            q=archive(b)
            ms=[(nn,bb) for nn,bb in q.items() if nn.endswith('manifest.json') and not nn.endswith('EXPORT_MANIFEST.json')]
            # Previous exports have files directly at the root.
            m=jload(q['manifest.json'])
            cs=[jload(bb) for nn,bb in q.items() if nn.startswith('calls/') and nn.endswith('.json')]
            previous_complete[m['study']]={'calls':len(cs),'output_cap':m['config']['max_output_tokens'],
                                          'created_utc':m['created_utc'],'fingerprint':m['fingerprint']}
            previous_ids.update(c['response']['id'] for c in cs);previous_all_calls.extend(cs)
    assert not previous_ids.intersection(response_ids)
    assert len(previous_ids)==295
    total_observed_attempts=sum(previous_complete[x]['calls'] for x in previous_complete)+len(starts)
    prior_known_cost=sum(cost(c['response']['usage'],(1,.02,4)) for c in previous_all_calls)
    # Exact offline replay in a temporary directory. Never instantiate JournalClient.
    with tempfile.TemporaryDirectory(prefix='r1_offline_replay_') as td:
        code=Path(td)/'original';code.mkdir()
        for n,b in pilot.items():
            if n.startswith(('pilot/','vendor/')) and n.endswith('.py'):
                dest=code/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        sys.path.insert(0,str(code))
        from pilot import recheck
        from pilot.common import request_payload
        replay_root=Path(td)/'reconstructed';seen=[]
        class StopOnUnrecorded(Exception): pass
        class LoggedClient:
            def complete(self,logical_id,messages,meta=None):
                i=len(seen)+1;s=starts[i]
                assert s['logical_id']==logical_id
                assert s['payload']==request_payload(cfg,messages)
                assert s['metadata']==(meta or {})
                seen.append(logical_id)
                if i not in results: raise StopOnUnrecorded(logical_id)
                return results[i]
        try: recheck.run(LoggedClient(),cfg,replay_root,manifest['spec'])
        except StopOnUnrecorded as exc: stop_id=str(exc)
        else: raise AssertionError('Replay must stop on missing response, not invent a completion')
        assert stop_id==pending[0]['logical_id'] and len(seen)==9
        rebuilt_records=[]
        for p in sorted((replay_root/'records').glob('*.json')):
            rel=p.relative_to(replay_root).as_posix();a=jload(p.read_bytes());b=jload(run[rel])
            for k in ('planning_seconds','probe_seconds','tool_seconds'):a.pop(k);b.pop(k)
            assert a==b;rebuilt_records.append(rel)
        assert len(rebuilt_records)==3
        assert jload((replay_root/'private/recheck_cases.json').read_bytes())==jload(run['private/recheck_cases.json'])
        assert jload((replay_root/'prefixes/rc_0.json').read_bytes())==jload(run['prefixes/rc_0.json'])
        sys.path.pop(0)
    # Independent task scoring (do not rely on submitted summary or collector).
    cases=jload(run['private/recheck_cases.json']);task_rows=[]
    for n,b in sorted(run.items()):
        if not n.startswith('records/'): continue
        r=jload(b);case=cases[r['stream']];task=case['tasks'][r['step']]
        q=task['type'];count=sum(t<=task['cutoff'] for t in range(len(case['cents']))) if q in (1,2) else len(case['cents']) if q==3 else None
        expected={'total':sum(case['cents'])/100 if q in (0,2) else None,'count':count}
        ans=r['answer'];good=isinstance(ans,dict) and set(ans)==set(expected)
        if good:
            good=all((ans[k] is None if v is None else isinstance(ans[k],(int,float)) and not isinstance(ans[k],bool) and math.isfinite(ans[k]) and abs(ans[k]-v)<1e-6) for k,v in expected.items())
        task_rows.append({'record':n,'method':r['method'],'stream':r['stream'],'step':r['step'],
                          'correct':bool(good),'expected':expected,'observed':ans,'answer_json_error':r['answer_json_error'],
                          'memory_amount_divisor':r['worker_view']['memory']['amount_divisor'],
                          'true_amount_divisor':100 if task['modes'][0] else 1})
    # Identical inputs but different stopping behavior: a stochastic/token-budget diagnostic.
    payload_equal=starts[3]['payload']==starts[5]['payload']
    assert payload_equal and starts[3]['request_sha256']==starts[5]['request_sha256']
    outer_statement=next(b for n,b in outer.items() if not n.startswith('__MACOSX/') and n.endswith('/operator_statement.json'))
    outer_billing=next(b for n,b in outer.items() if not n.startswith('__MACOSX/') and n.endswith('/billing_note_sanitized.md'))
    assert outer_statement==bundle['operator/statement.json'] and outer_billing==bundle['operator/billing_note.md']
    # Source-order evidence: start file is written BEFORE HTTP open. No proof request 9 reached provider.
    src=pilot['pilot/client.py'].decode().splitlines()
    start_line=next(i+1 for i,l in enumerate(src) if 'write_json(self.attempts/' in l and '_start.json' in l)
    http_line=next(i+1 for i,l in enumerate(src) if 'self.opener.open' in l)
    assert start_line<http_line
    hashes_after={p.name:sha(p.read_bytes()) for p in input_paths};assert before==hashes_after
    assertion_issues=[
        {'code':'WRONG_TRUNCATION_ATTEMPT','claim':'call 3 truncated','observed':'attempt 5: rc/0/0/myopic/answer; attempt 3 stopped normally','severity':'annotation_error'},
        {'code':'WRONG_PENDING_LOGICAL_ID','claim':'rc/0/1/myopic/plan','observed':pending[0]['logical_id'],'severity':'annotation_error'},
        {'code':'WRONG_WEEKDAY','claim':'Friday / 周五','observed':date(2026,9,12).strftime('%A'),'severity':'annotation_error'},
        {'code':'STOP_CAUSE_NOT_ESTABLISHED','claim':'operator killed process because truncation, excluding crash/network/outage','observed':'No result for attempt 9, status remains running; cause not inferable. Statement explicitly agent-drafted.','severity':'unverified_statement'},
        {'code':'SEND_OR_BILLING_NOT_ESTABLISHED','claim':'attempt 9 had been sent','observed':f'start journal written at client.py:{start_line}, before HTTP open at line {http_line}','severity':'unverified_statement'},
        {'code':'NO_PROVIDER_INVOICE','claim':'actual settlement reconciliation','observed':'only agent-drafted/self-reported billing note; no provider transaction detail','severity':'scope_limitation'}]
    report={
        'audit_version':'r1-independent-review-1.0','audit_date':'2026-09-12','scope':'R1 evidence completion; no new experiments',
        'decision':'R1_CLOSED_RAW_EVIDENCE_ACCEPTED_ANNOTATIONS_CORRECTED',
        'allow_offline_R2_design':True,'allow_paid_new_experiment':False,'need_rerun_old_experiment':False,
        'input_sha256':before,'nested_evidence_sha256':sha(nested_data),
        'integrity':{'outer_entries':len(outer),'nested_entries':len(bundle),'indexed_files':len(index),'hash_mismatches':0,
                     'evidence_files':len(run),'original_source_files_matched':len(source_check),'contract_matches_original':True,
                     'prior_manifest_identical':True,'prior_summary_files':previous_summaries,'input_archives_unchanged':before==hashes_after,
                     'json_duplicate_keys_or_nonfinite':False},
        'ledger':{'started':len(starts),'responses_recorded':len(results),'pending':pending,'truncated':truncated,
                  'records':3,'prefixes':1,'usage_totals':totals},
        'offline_replay':{'request_bodies_reconstructed':len(seen),'response_records_consumed':8,'records_reconstructed':3,
                          'request_metadata_matches':True,'tool_results_match':True,'private_cases_match':True,
                          'shared_prefix_matches':True,'stop_logical_id':stop_id,'ignored_comparison_fields':['planning_seconds','probe_seconds','tool_seconds'],
                          'real_endpoint_calls':0},
        'same_payload_example':{'attempts':[3,5],'payload_equal':payload_equal,'request_hash':starts[3]['request_sha256'],
                                'outcomes':['stop with valid answer','length with empty visible answer'],'not_an_algorithm_treatment_effect':True},
        'previous_complete_runs':previous_complete,'combined_evidence':{
            'recorded_unique_responses':len(previous_ids)+len(response_ids),'journaled_attempts_at_least':total_observed_attempts,
            'overlapping_response_ids':0,'conditional_known_cost_cny':str(prior_known_cost+Decimal(totals['conditional_previous_tariff_cny'])),
            'conditional_tariff_only':{'input_uncached_per_million':1,'input_cached_per_million':.02,'output_per_million':4,
                                      'source':'previous audit tariff assumption, not a fresh invoice or guaranteed current rate'},
            'unrecorded_attempt_9_cost':None,'other_unsubmitted_calls_cost':None,'invoice_reconciled':False},
        'assertion_issues':assertion_issues,
        'task_scores':task_rows,
        'limits':['Content hashes are not provider signatures or proof of complete historical disclosure.',
                  'No proof of operator kill motive or successful transmission of a start-only request.',
                  'Successful HTTP response is not task success: one length result has empty content.',
                  'Runtime running status is an old file value, not evidence that a process is still live.',
                  'Interrupted development observations must not be combined with cap16384 to select best answers.',
                  'No causal efficacy, significance, model-weight identity, or paper-readiness claim.']}
    write_json(args.out/'R1_Review_Result.json',report)
    with (args.out/'R1_Call_Ledger.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(ledger[0]));w.writeheader();w.writerows(ledger)
    write_json(args.out/'R1_Task_Scores.json',task_rows)
    print(json.dumps({'decision':report['decision'],'integrity':report['integrity'],
                     'counts':{'started':len(starts),'responses':len(results),'pending_id':pending[0]['logical_id'],'trunc_attempt':truncated[0]['attempt']},
                     'totals':totals,'combined_evidence':report['combined_evidence'],'offline_replay':report['offline_replay']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
